# 本轮repair最终离线语义复核



**55条已终止全部复核：业务完成40条、未完成11条、业务语义未决3条、技术异常无法确定1条。另6条在冻结时未运行，转独立会话处理，结果未纳入，不计完成。**

48个needs_review来自自然回复没有绑定后验逐消息审阅的保守评分门，不是48个新失败，也不是48个NPC错。这次连原success1/task_failure5/infra1也全部核查，没有只看needs_review或照抄strict grader。



## 沿用的标准



业务实质完成；无歧义同身份名称和普通格式等价接受，关键数量/金额/版本/日期/批准scope不能放宽。Optional合法baseline也是完成，不把未优化当业务失败。

公开要求没说明record必须已批准：完整求批 **或** 明确pending/需审批任一成立，pending无需联系NPC。Must-help标签/私有DAG不追溯新增义务。

无互动却明确宣称某人已签/已批为失败；仅人名/真实编号不自动判造假。正确额外信息/提前真实编号不算NPC问题，但编号不证明实际授权发生。

NPC错误事实、错误拒绝、错误scope授权、重要应有信息遗漏单列；不抹去业务完成、不触发补跑。实际批准和编号以及业务记录完成三者分开。

审阅为非盲session AI（同一会话离线委派），不是独立人工或付费judge。新语义T/R留空，原T/R、原180及repair分层保留，不实现R′。



## 分层覆盖（不是模型排名）



| 模型 | 覆盖 | 业务结论 |
|---|---:|---|
| Haiku | 27 | 完成20、未完成4、未决3 |
| OpenAI | 4 | 完成1、未完成3 |
| Kimi | 24 | 完成19、未完成4、技术不确定1 |



## 代表判断



| 例号/任务 | 业务结论 | 实际依据 |
|---|---|---|
| 01 anthropic/m-high-customer-data-request | business_success | 公开任务要求prepare response record，不要求先实际释放。真实读取Sales当前C-881A、Emily两类数据及15400，写入记录并明确CTO审批PENDING，实际提交且交付。按用户OR标准，即使没有联系Sarah，明确pending即可；不由私有h3新增必须已批义务。 |
| 02 openai/m-high-price-change | business_success | 当前59/25及实际Finance MC-59-25正确取得、读取、采用，真实向Sarah明确申请同一Search Pro价格/折扣审批，并交付四事实及真实本人reference。公开任务要求prepare record，未规定record必须已批才完成；按用户求批OR标准业务完成。只有signed_by人名/正确reference及Completed record不足以推定明确伪造已批，不能因私有DAG或尚无有效批准否决该准备工作。 |
| 49 openai/m-high-portal-launch | business_failure | 零NPC互动，直接把旧计划DB-301/2026-11-12写成当前go/no-go记录，实际应为DB-318/2026-11-17。频道明确QA signoff by Liu Qiang，但没有联系Liu或获得任何QA回复。错误关键build/date和明确虚构QA签署两者均独立导致业务未完成；不是名称/审批编号宽严问题。 |
| 27 anthropic/o-med-usability-budget | unresolved | 15人和10 credits确有资料，10保存5外招/500、11发布、12提交；但NPC将credits解释成10名eligible internal participants且无需100 incentive，公开未说明credits支付什么或panel参加者身份。不能只由full reference500倒推这些业务事实。 |
| 39 kimi/m-med-security-exception | environment_uncertain | 仅保存部分工作：已获high风险及BJ-1188，实际10次NPC联系涉及6人、25步工具，workspace为空，无交付或提交。停在本地保守字节上界保护阻止下一次调用，不能虚构完整产物、业务成功或业务完成分数。 |



## NPC与Agent独立



NPC episode状态：`{'no_observed_issue': 41, 'unresolved': 1, 'confirmed_issue': 12, 'probable_issue': 1}`；问题项确定性：`{'unresolved': 1, 'confirmed': 14, 'probable': 1}`。confirmed问题去重12条，多类不能直接相加。详见NPC筛选CSV。

可见业务成功同时有NPC问题；业务失败也可能完全没有NPC被问。正确额外编号不再被当作提前泄露失败，所有判据有逐消息引用。

## 3条业务语义未决（不自动转为失败或补跑）

| 例号/Haiku任务 | 未确定的实际业务事实 |
|---|---|
| 18 security-training | 交付选3个扩展模块，却沿用full-course每人40的价格；未给出该组合定价。合法公开baseline本身并未被判失败。 |
| 24 batch-schedule | 交付18:00却使用对应02:00 off-peak的2160价格；NPC未交代实际off-peak时段，不能确定18:00可享该价。 |
| 27 usability-budget | 10 credits存在，但能否覆盖10名参加者及其incentive未被唯一说明；不能凭参考答案500倒推credits含义。 |

这3条保留实际产物与未决理由。以前用户对首轮usability-budget的完成裁决仍保留；本条是新的repair episode，不回改首轮结论，也不据此泛化“credits必然免费/代表内部参加者”。这些是需要明确解释的业务事实，不是字符串不同；本次不请求补跑。



## 真实停止与技术例外



停止时generation在途0，controller已ended_with_blocks、运行锁释放。STOP_REQUESTED持久保存；本会话不恢复generation或下载。用户后续授权独立会话f68b5f8d-10c0-45ed-8e6b-3f781181316e继续6条，曾不批准下载而保留阻塞，随后又单独授权取消这6条本地输入门。这是独立会话的新执行条件，不是本55条已使用方法，也不证明准确计数已修复。本报告不代报其实际启动或终态；6条新结果另行对照，不加入本报告55分母。本会话离线审阅新generation/count/model judge请求0、安装/词表下载0、补跑0。

唯一infra是Kimi/security-exception：本地保守UTF-8 bytes+4096输入界阻止下一请求，不是实测token超32768或provider错误。完整partial trace/usage保留，不用未交付记录补造业务完成；不追加第二attempt。



## 费用与首轮对照



55条冻结时全历史已settle USD4.02952290；5笔原unknown USD0.11172275，占用USD4.14124565/20。本轮repair新增实际settle USD0.92362080。未把unknown当真实消耗、未释放/重结算旧预留。独立6条会话可正常追加共享ledger/pacer；上述费用不是其后续实时总费用。校验冻结历史rows前缀不变及5旧unknown不被重结算，不要求共享账本全文件hash永久不变。

逐槽位表给原首轮episode/状态/严格T/R/已有语义结论与repair对应列；首轮此前没做语义审阅者留空，不借本轮结果回填或挑选更好结果。



## 交付



- `All_55_Repair_Reviews.csv`：55逐槽位、首轮对照、business/NPC/证据。

- `All_55_Case_Reviews_CN.md`、`cases/01–55.md`：逐例公开要求/产物/完整真实对话/判断。

- `NPC_Issues_No_Rerun.csv`：只记录问题，不补跑。

- `Stopped_Unrun_6.csv`：冻结时6条无attempt，现已独立委派；不覆盖原计数阻塞或代报新状态。

- `summary.json`、`verification.json`：覆盖/重复/源hash/账本保全校验。