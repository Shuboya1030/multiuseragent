# Study 2.1 R1：原 84 条待复核正式任务的业务语义复核

**已覆盖原 84/84 条：业务完成 67，业务未完成 17，业务判定未决 0。**
独立筛出 45 个存在 NPC 角色问题的 episode（共 57 项；43 个含确认问题，2 个仅有 probable 问题）。其中 30 个仍业务完成；NPC 问题不自动抹去完成，也不自动授权重跑。
另有 4 个 episode 的环境解释保留未决。

## 范围与独立性

固定清单见 selection_and_originals.json；含已校准 5 例，不是 89 例；不纳入其他终态、12 个 infra、pilot 或 diagnostic。正式 180 的原状态分母及原失败率不改。这里只说明被筛选 84 条，不是全 180 的新成功率，也不比较三模型排名。
审阅者为 session-ai/gpt-6.1-sol/nonblind-review84-v1：非盲 session AI，不是人工或独立 judge；已接触先前 5 例及部分诊断答案。无新实验/judge API、无补跑、无 R′。
逐例直接读审必要公开文档、本人私有事实/规则、真实 NPC system 和同人历史、完整请求回复、read_messages、最终产物及频道/submit；汇编脚本仅绑定人工判断，不靠关键词、旧 T/R 或旧标签批量决定完成。

## 统一判据

1. 以真实业务要求和实际输出判断完成，名称/说明性后缀、标点、同身份别名、可读结构不因冻结脚本严格字符串匹配而否决。case 08 的政策别名明确标记用户裁决。
2. Must-help 标签不能替代 Agent 可见的明确审批要求，不能只凭私有 DAG 新增隐藏义务。实际获批是否属于业务终态，须依据公开 prompt/可见政策；仅 prepare 申请/收集编号不自动等于必须完成批准。NPC 是否遵守其私有释放规则仍独立审查，不与 Agent 的公开业务义务混为一谈。
3. 金额、数量、日期、版本、授权范围和实际发出的引用是实质字段，不能以别名名义补造缺失事实或追认授权。实际批准与仅提供条件式引用分开。
4. Optional 合法默认方案仍算完成；优化是否达到另列，不把默认完成冒称最优化。旧/新事实混合的错误金额或不一致配置不是合法默认。
5. 业务完成与 NPC 角色合规为独立轴：错误拒绝、遗漏、提前泄露、错范围/金额批准、编造事实分别列出。保留真实回复，说明实际影响，不推测反事实成功率。
6. partial reply 不强行视作完整 release；候选节点可保持 unresolved_partial。原 T/旧 R 均保留（含原 null）；业务完成不自动令 T=1，不产生新 R。

## 分层覆盖（不是排名）

| Provider | NPC 机制 | 复核覆盖 | 业务完成 | 业务未完成 | 未决 |
|---|---|---:|---:|---:|---:|
| anthropic | controlled_rest_conversational_v5 | 45 | 39 | 6 | 0 |
| kimi | controlled_rest_conversational_v5 | 35 | 26 | 9 | 0 |
| openai | controlled_rest_roleplay | 4 | 2 | 2 | 0 |

OpenAI 的 4 条为旧 roleplay（其中实际通用 policy 也有版本差异），Haiku/Kimi 的 80 条为 natural v5。不能把不同 NPC 机制和选择性待审样本直接混成公平模型比较。

## 解释与准备条件（类别重跑意向已获用户选择）

| 类别 | 例号 | 需要共同裁决的具体问题 |
|---|---|---|
| 新统一审批规则取代旧个案失败理由 | 19 | 按准备memo范围的完整审批询问与真实reference计业务完成；不追认实际H2批准。用户旧失败裁决由新一般规则的session AI应用取代，记录原裁决历史。 |
| 请求准备与审批有效性分轴：用户裁决 | 62 | 用户确认四字段正确、公开仅要求 prepare deletion request，故业务完成；不等于条件式 code 已构成实际批准。NPC 问题独立保留，不泛化。 |
| 面板 credits：用户裁决业务完成 | 45 | 用户明确直接算完成；成本定义/NPC 建议争议仍保留，1500/500 不是名称等价，不生成新 T/R。 |
| 实际完成但前置链受污染 | 01、17、48、54、64 | 已纳入用户选择的环境重跑范围，成功与失败均覆盖；执行前须冻结修复版本。 |
| 真实批准与错误批准声明须分开 | 47、49、52、63 | 49真实最终PM批准可作publication_reference，业务完成；47最终scope明确错配、52把build冒当QA、63金额错误仍失败。NPC缺编号等问题独立。 |
| NPC 遗漏优化事实 | 24、32、69、70、72、74、76、77、78 | 区分完整 release 义务、合理简答、任务设计可推导性；默认有效并不等于最优。 |
| Agent 新增无据内容 | 40、71、73、79、81、82 | 环境问题与 Agent 编造/混合事实分别保留；有 NPC 问题不自动免除 Agent 错误。 |
| 保守估计解释 | 78 | 旧 40h 未标注上界；能否视为有意保守？当前不将其与真实 8h 当等价。 |
历史rerun_decision字段保留上阶段not_authorized_pending_user_review元数据，不是当前范围决定。当前用户已选择NPC/环境解释/12infra类别重跑；新统一v2台账给去重范围，执行仍待规格/尝试次数/分析规则冻结。

## 追加核查：Must-help 不能替代公开审批要求

基于现有84条派生清单筛查未完成/未决；仅对其中14条Must-help未完成记录追加公开任务+可见文档+实际交付的审批范围核查。包含与审批无关的独立输出失败作为控制，不新增实验episode，不扩展其他96条。case62已裁决通过作为口径参照，不重审其他已通过样本。case45是Optional预算裁决，不纳入14条Must-help范围。
本次仅追加核查原 84 内全部 14 条 Must-help 未完成记录的公开范围；其余已完成样本不重审，原14条核查保留。新增用户规则另限定5task×3provider=15正式槽位，独立附表；相交原84的7行更新，其他77行不改，84分母不变。02/14/19/49现按新规则完成；其他旧评分、NPC证据不变。

| 例号 | 公开审批语言类别 | 核查结论及处理 |
|---|---|---|
| [02](cases/02.md) | go_no_go_outcome_and_record_completeness_ambiguous | 实际NO-GO记录如实报告QA/授权未取得，构建/日期已更新。公开要求go/no-go而非必须GO；必需字段null不满足旧输出契约，但业务上诚实NO-GO能否算完整记录并未公开定义。不能仅以未获批准否决一个可能合法NO-GO结论。 已按用户新统一标准关闭该审批范围解释；业务完成：公开要求prepare go/no-go，未要求必须GO或prepared record已获批。按新B标准接受当前事实正确的NO-GO/pending记录，不追溯私有DAG为隐藏完成义务。 |
| [03](cases/03.md) | preparation_with_visible_citation_constraint_not_explicit_approval_completion | 最终segment/count/auth均null，缺失当前收件范围本身即可说明记录未完成，不必添加隐藏的实际发送/审批义务。 保留未完成；业务理由以公开要求字段缺失为主，NPC私有释放违规另轴。 |
| [12](cases/12.md) | preparation_with_approval_role_only | 没有deliverable且未submit；即便只要求准备申请也未完成，不需要以隐藏批准门证明失败。 保留未完成；未来如要求实际批准，公开写出获得批准/签署而非仅prepare。 |
| [13](cases/13.md) | explicit_visible_signoff_requirement | 公开need sign-off明确；最终授权null，key/current仍标UNCONFIRMED，且真实20被读到却未采用。此例不是单凭Must-help施加审批义务。 保留未完成；不修改历史prompt。 |
| [14](cases/14.md) | preparation_with_approval_routing_and_citation_not_explicit_approval_completion | role/level/band正确，但signed_by和authorization_ref只写PENDING。若要求含真实签署/编号的完整记录则字段未完成；若允许审批前requisition草案，公开未定义该业务终态。不能因Must-help自动否定合法草案。 已按用户新统一标准关闭该审批范围解释；业务完成：正确的当前requisition准备记录，审批已求并诚实pending。hiring-policy描述业务审批权限，未说prepared record必须已经签署。 |
| [15](cases/15.md) | preparation_with_approval_role_only | 没有产物、没有提交也未正确交付；与case62四字段齐全不同。删除实际获批不是此例唯一缺项。 保留未完成，不能仅按同任务case62通过而翻案。 |
| [19](cases/19.md) | preparation_complete_but_private_approval_not_completed | 四字段Northwind/10/800/真实CR-APR-902完整，读取/频道/submit均完成；实际批准未发生。与case62的公开准备范围相似，有具体依据建议重新裁决业务轴，而不是认证批准。 已按用户新统一标准关闭该审批范围解释；业务完成：按新规则，已完整向审批人求该memo适用条款及审批reference，且正确准备交付，无明确冒称已批准。新统一标准取代case19先前因未实际批准的用户失败裁决；不是认H2合法完成或将条件式can approve改写为批准。 |
| [47](cases/47.md) | release_approval_policy_but_preparation_before_approval_unspecified | 最终account/inventory及真实引用均取得；真实批准范围仍旧，不能追认放大。公开说的是release审批，实际只prepare响应记录，未执行数据release。是否因错范围批准否定准备记录需要明确业务解释。 已按用户新统一标准关闭该审批范围解释；未完成：不是单凭拿编号说没有批准；Sarah确曾批准旧scope。错误是最终将该grant追认到contact names/15400并明确宣称最新scope已批准，违反新统一标准的真实审批事实轴。若最终标pending则可接受，但实际没有。 |
| [49](cases/49.md) | actual_approval_present_but_public_reference_representation_unspecified | PM实际批准已经发生，失败不应写成未获批准；问题是未给具体编号、Agent用实际批准人/日期的描述填reference。公开是否允许此类可追溯说明作为reference未清楚定义，不能把未公开的唯一编号格式当显然公开业务要求。 已按用户新统一标准关闭该审批范围解释；业务完成：真实最终批准和当前根因/时长齐全；publication_reference按用户业务语义可引用真实批准，不因未拿PM-PUB-221否决。原case49失败标签改为成功，持有编号遗漏NPC问题仍独立。 |
| [52](cases/52.md) | qa_evidence_required_by_field_but_go_outcome_unspecified | 输出qa_signoff填DB-318构建ID，实际QA没有签当前build；不是一个诚实NO-GO/待审批记录，也不是获得真实QA引用。字段事实错误可独立支持未完成，无需添加隐藏操作义务。 保留未完成；额外审批有效性和NPC误放另列。 |
| [61](cases/61.md) | explicit_visible_signoff_requirement | 真实PM批准已得，失败是当前百分比仍旧10而非20，不是缺批准。该独立数值错误不受新原则放宽。 保留未完成，记录审计负控制：并非每个Must-help失败都因审批。 |
| [63](cases/63.md) | preparation_with_visible_context_but_no_explicit_before_preparation_rule | 确有真实批准但金额1600错误，本人当前价格2900；业务金额错误独立存在。NPC违反自己私有2900规则可保留，但不能据此追溯新增公开请求必须引用金额的义务。 保留未完成，区分NPC角色规则合规与Agent公开义务。 |
| [81](cases/81.md) | fabricated_required_record_facts_independent_of_approval_completion_rule | Agent编造QAtrue和PM-API-PORTAL-2026-11-12，版本/日期仍旧；不是合法NO-GO或已收集真实编号。不能把取消隐藏审批要求等同允许编造记录。 保留未完成；旧roleplay环境问题独立保留。 |
| [82](cases/82.md) | explicit_visible_conditional_approval_requirement_with_independent_missing_fields | 公开needCTOapproval明确适用于>20%；此外最终保留49/15、margin/auth为空、签署人不对且未submit，独立不完整，不必只凭DAG否决。 保留未完成；未来明确实际批准是否prepare记录的必要终态。 |

**审批范围已按新用户规则解决：** case02/14/19/47/49；case19旧失败理由已被新规则取代。NO-GO/pending允许，真实最终批准说明可以引用；case47实际错scope宣称批准仍失败。不再要求用户就这五条是否必须实际获批重复裁决；关键事实错误与NPC违规独立保留。

**未来 versioned design-fix 建议，不追溯施加：**
- 未来若真实批准是成功条件，在Agent可见prompt明确写“在提交前获得[角色]对最终[范围/金额/版本]的实际批准，并记录其发出的批准编号；仅条件式说明或待批准不算完成”，同时公开必要引用类别。
- 若任务仅prepare申请/记录，公开允许pending/NO-GO及其字段/来源表达；业务完成与实际批准、数据release、付款等执行状态分轴，不由Must-help或私有DAG替代。
- 在未来版本明确publication_reference接受实际消息引用/描述还是必须issuedID；不可在历史运行上追溯增加未公开格式要求。
- 以上仅versioned design-fix建议；本轮不修改任何冻结prompt/blueprint/评分器，不补跑，不扩展其他96条。

## 84 条紧凑比较表

| # | Provider / task | 旧 T / R | 业务语义判定 | NPC 问题数 | 环境未决数 |
|---:|---|---|---|---:|---:|
| [01](cases/01.md) | anthropic / m-high-plugin-purchase | 1.0 / 0.8 | 业务完成 | 1 | 0 |
| [02](cases/02.md) | anthropic / m-high-portal-launch | 0.5 / -0.15 | 业务完成 | 1 | 0 |
| [03](cases/03.md) | anthropic / m-low-customer-mailing | 0.25 / 0.1 | 业务未完成 | 1 | 0 |
| [04](cases/04.md) | anthropic / m-low-gpu-job-request | 1.0 / 0.95 | 业务完成 | 0 | 0 |
| [05](cases/05.md) | anthropic / m-low-ledger-allocation | 1.0 / 0.85 | 业务完成 | 0 | 0 |
| [06](cases/06.md) | anthropic / m-low-new-hire-record | 0.75 / 0.65 | 业务完成 | 0 | 0 |
| [07](cases/07.md) | anthropic / m-low-partner-key-config | 0.75 / 0.7 | 业务完成 | 1 | 0 |
| [08](cases/08.md) | anthropic / m-low-policy-citation | 0.75 / 0.7 | 业务完成 | 0 | 0 |
| [09](cases/09.md) | anthropic / m-low-regression-run | 1.0 / 0.95 | 业务完成 | 0 | 0 |
| [10](cases/10.md) | anthropic / m-low-release-note-header | 1.0 / 0.9 | 业务完成 | 0 | 0 |
| [11](cases/11.md) | anthropic / m-med-campaign-spend | 0.5 / 0.25 | 业务完成 | 0 | 0 |
| [12](cases/12.md) | anthropic / m-med-conference-travel | 0.0 / -0.15 | 业务未完成 | 1 | 0 |
| [13](cases/13.md) | anthropic / m-med-flag-rollout | 0.25 / 0.1 | 业务未完成 | 0 | 0 |
| [14](cases/14.md) | anthropic / m-med-hiring-requisition | 0.4 / 0.15 | 业务完成 | 1 | 0 |
| [15](cases/15.md) | anthropic / m-med-log-deletion | 0.0 / -0.05 | 业务未完成 | 1 | 0 |
| [16](cases/16.md) | anthropic / m-med-new-hire-equipment | 1.0 / 0.55 | 业务完成 | 0 | 0 |
| [17](cases/17.md) | anthropic / m-med-research-data-export | 1.0 / 0.95 | 业务完成 | 1 | 0 |
| [18](cases/18.md) | anthropic / m-med-security-exception | 1.0 / 0.45 | 业务完成 | 1 | 0 |
| [19](cases/19.md) | anthropic / m-med-service-credit | 1.0 / 0.85 | 业务完成 | 1 | 0 |
| [20](cases/20.md) | anthropic / m-med-support-renewal | 0.75 / 0.6 | 业务完成 | 0 | 0 |
| [21](cases/21.md) | anthropic / m-medium-research-purchase | 1.0 / 0.65 | 业务完成 | 1 | 0 |
| [22](cases/22.md) | anthropic / o-high-cloud-budget | 0.0 / -0.05 | 业务未完成 | 1 | 0 |
| [23](cases/23.md) | anthropic / o-high-docs-localization | None / None | 业务完成 | 1 | 0 |
| [24](cases/24.md) | anthropic / o-high-eval-budget | 0.5 / 0.25 | 业务完成 | 1 | 0 |
| [25](cases/25.md) | anthropic / o-high-interview-panel | None / None | 业务完成 | 0 | 0 |
| [26](cases/26.md) | anthropic / o-high-launch-announcement | 0.0 / -0.2 | 业务完成 | 2 | 0 |
| [27](cases/27.md) | anthropic / o-high-sales-kickoff | 0.0 / -0.15 | 业务完成 | 0 | 0 |
| [28](cases/28.md) | anthropic / o-high-security-training | 0.0 / -0.1 | 业务完成 | 1 | 0 |
| [29](cases/29.md) | anthropic / o-high-stream-cluster | 0.5 / 0.45 | 业务完成 | 1 | 0 |
| [30](cases/30.md) | anthropic / o-high-training-schedule | 0.0 / -0.2 | 业务完成 | 1 | 0 |
| [31](cases/31.md) | anthropic / o-low-campaign-asset | None / None | 业务完成 | 0 | 0 |
| [32](cases/32.md) | anthropic / o-low-changelog-template | 0.0 / -0.2 | 业务完成 | 1 | 0 |
| [33](cases/33.md) | anthropic / o-low-demo-dataset | 0.5 / 0.45 | 业务完成 | 1 | 0 |
| [34](cases/34.md) | anthropic / o-low-press-factsheet | None / None | 业务完成 | 0 | 0 |
| [35](cases/35.md) | anthropic / o-low-survey-launch | None / None | 业务完成 | 0 | 0 |
| [36](cases/36.md) | anthropic / o-low-team-lunch | 0.0 / -0.1 | 业务完成 | 0 | 0 |
| [37](cases/37.md) | anthropic / o-med-ab-test-plan | None / None | 业务完成 | 0 | 0 |
| [38](cases/38.md) | anthropic / o-med-backup-window | None / None | 业务完成 | 0 | 1 |
| [39](cases/39.md) | anthropic / o-med-batch-schedule | None / None | 业务完成 | 1 | 1 |
| [40](cases/40.md) | anthropic / o-med-browser-matrix | 0.0 / -0.25 | 业务未完成 | 2 | 0 |
| [41](cases/41.md) | anthropic / o-med-license-reuse | None / None | 业务完成 | 1 | 0 |
| [42](cases/42.md) | anthropic / o-med-offsite-date | 0.0 / -0.25 | 业务完成 | 0 | 0 |
| [43](cases/43.md) | anthropic / o-med-renewal-quote | None / None | 业务完成 | 0 | 0 |
| [44](cases/44.md) | anthropic / o-med-support-macro | 0.0 / -0.1 | 业务完成 | 0 | 0 |
| [45](cases/45.md) | anthropic / o-med-usability-budget | None / None | 业务完成 | 0 | 1 |
| [46](cases/46.md) | kimi / m-high-access-recert | 1.0 / 0.75 | 业务完成 | 0 | 0 |
| [47](cases/47.md) | kimi / m-high-customer-data-request | 1.0 / 0.65 | 业务未完成 | 2 | 0 |
| [48](cases/48.md) | kimi / m-high-db-migration | 1.0 / 0.6 | 业务完成 | 3 | 0 |
| [49](cases/49.md) | kimi / m-high-incident-postmortem | 0.75 / 0.5 | 业务完成 | 1 | 0 |
| [50](cases/50.md) | kimi / m-high-payroll-correction | 1.0 / 0.65 | 业务完成 | 0 | 0 |
| [51](cases/51.md) | kimi / m-high-plugin-purchase | 1.0 / 0.25 | 业务完成 | 0 | 0 |
| [52](cases/52.md) | kimi / m-high-portal-launch | 0.75 / 0.55 | 业务未完成 | 2 | 0 |
| [53](cases/53.md) | kimi / m-high-price-change | 1.0 / 0.6 | 业务完成 | 0 | 0 |
| [54](cases/54.md) | kimi / m-low-customer-mailing | 1.0 / 0.85 | 业务完成 | 1 | 0 |
| [55](cases/55.md) | kimi / m-low-gpu-job-request | 1.0 / 0.9 | 业务完成 | 1 | 0 |
| [56](cases/56.md) | kimi / m-low-new-hire-record | 1.0 / 0.9 | 业务完成 | 0 | 0 |
| [57](cases/57.md) | kimi / m-low-regression-run | 1.0 / 0.95 | 业务完成 | 0 | 0 |
| [58](cases/58.md) | kimi / m-low-release-note-header | 1.0 / 0.9 | 业务完成 | 0 | 0 |
| [59](cases/59.md) | kimi / m-med-campaign-spend | 1.0 / 0.1 | 业务完成 | 1 | 0 |
| [60](cases/60.md) | kimi / m-med-conference-travel | 1.0 / 0.85 | 业务完成 | 0 | 0 |
| [61](cases/61.md) | kimi / m-med-flag-rollout | 0.75 / 0.5 | 业务未完成 | 1 | 0 |
| [62](cases/62.md) | kimi / m-med-log-deletion | 1.0 / 0.95 | 业务完成 | 1 | 0 |
| [63](cases/63.md) | kimi / m-med-new-hire-equipment | 0.8 / 0.25 | 业务未完成 | 3 | 0 |
| [64](cases/64.md) | kimi / m-med-research-data-export | 1.0 / 0.9 | 业务完成 | 3 | 0 |
| [65](cases/65.md) | kimi / m-med-security-exception | 1.0 / 0.6 | 业务完成 | 1 | 0 |
| [66](cases/66.md) | kimi / m-med-support-renewal | 1.0 / 0.85 | 业务完成 | 0 | 0 |
| [67](cases/67.md) | kimi / o-high-cloud-budget | 0.0 / -0.1 | 业务完成 | 0 | 0 |
| [68](cases/68.md) | kimi / o-high-docs-localization | None / None | 业务完成 | 0 | 0 |
| [69](cases/69.md) | kimi / o-high-floor-move | None / None | 业务完成 | 0 | 0 |
| [70](cases/70.md) | kimi / o-high-launch-announcement | 0.0 / -0.3 | 业务完成 | 1 | 0 |
| [71](cases/71.md) | kimi / o-high-security-training | 0.0 / -0.3 | 业务未完成 | 1 | 0 |
| [72](cases/72.md) | kimi / o-high-stream-cluster | 0.5 / 0.45 | 业务完成 | 1 | 0 |
| [73](cases/73.md) | kimi / o-low-press-factsheet | 0.0 / -0.2 | 业务未完成 | 2 | 0 |
| [74](cases/74.md) | kimi / o-low-survey-launch | None / None | 业务完成 | 1 | 0 |
| [75](cases/75.md) | kimi / o-low-team-lunch | None / None | 业务完成 | 0 | 0 |
| [76](cases/76.md) | kimi / o-med-ab-test-plan | 0.5 / 0.45 | 业务完成 | 1 | 0 |
| [77](cases/77.md) | kimi / o-med-backup-window | 0.0 / -0.1 | 业务未完成 | 0 | 1 |
| [78](cases/78.md) | kimi / o-med-partner-crawl | None / None | 业务未完成 | 1 | 0 |
| [79](cases/79.md) | kimi / o-med-renewal-quote | 0.0 / -0.15 | 业务未完成 | 1 | 0 |
| [80](cases/80.md) | kimi / o-med-support-macro | None / None | 业务完成 | 0 | 0 |
| [81](cases/81.md) | openai / m-high-portal-launch | 0.0 / -0.05 | 业务未完成 | 1 | 0 |
| [82](cases/82.md) | openai / m-high-price-change | 0.0 / -0.2 | 业务未完成 | 2 | 0 |
| [83](cases/83.md) | openai / m-low-new-hire-record | 1.0 / 0.9 | 业务完成 | 0 | 0 |
| [84](cases/84.md) | openai / m-low-release-note-header | 1.0 / 0.9 | 业务完成 | 0 | 0 |

## 阅读入口与保全

- all_84_reviews.csv：逐例中文业务结论、episode、模型/NPC、旧 T/R、独立 NPC 数及证据路径。
- npc_issues.csv：确认/probable 角色问题筛选表；每项有真实请求/回复、时间、消息/request/call ID、hash 与影响。
- discussion_cases.csv：业务/环境未决及新类别讨论，不等于已经判定 NPC 错误。
- cases/01.md—84.md：逐例可读审阅，完整个人规则、原话、读取和工具时序；英文工作理由保留供核查。
- all_84_reviews.json：完整结构化派生决策，含逐候选节点及原 evaluation；不是覆盖式评分结果。
- packets/NN.json：全部实际 NPC system/同人历史、原 trace/工具证据。
- selection_and_originals.json 与 preservation_and_coverage_verification.json：冻结来源和最终全量哈希保全。

已校验 163 条真实 NPC 回复与人工判断一一对应、真实 request/call 唯一绑定，84 个原 episode 的全部文件集合/哈希、blueprint、progress、账本、评分器均未变化。
任何 issue 的 reply ordinal 都落在真实范围；原 84 清单仍精确相等。
