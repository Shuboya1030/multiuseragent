As of 2026-11-05: Configure the crawl of partner site docs.partner.example. Save /workspace/deliverable.json with rate_limit_rps, user_agent, est_hours. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/o-med-partner-crawl.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000
