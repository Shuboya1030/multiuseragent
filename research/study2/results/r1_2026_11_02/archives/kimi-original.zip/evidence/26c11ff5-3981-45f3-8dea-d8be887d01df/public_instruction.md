As of 2026-11-05: Plan desk allocation for the Floor 4 move. Save /workspace/deliverable.json with desks, accessible_desks, move_date. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/o-high-floor-move.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000
