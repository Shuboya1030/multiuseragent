As of 2026-11-05: Prepare the A/B test plan for the search ranking tweak. Save /workspace/deliverable.json with sample_size, duration_days, compute_usd. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/o-med-ab-test-plan.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000
