As of 2026-11-05: Prepare the purchase request for the Q4 webinar campaign media spend. Save /workspace/deliverable.json with campaign, spend_usd, signed_by, authorization_ref. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/m-med-campaign-spend.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000
