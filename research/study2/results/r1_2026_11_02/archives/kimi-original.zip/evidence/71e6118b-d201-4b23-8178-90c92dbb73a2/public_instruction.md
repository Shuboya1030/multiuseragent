As of 2026-11-05: Update support macro MAC-14 for search indexing delays. Save /workspace/deliverable.json with macro_id, eta_text, workaround. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/o-med-support-macro.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000
