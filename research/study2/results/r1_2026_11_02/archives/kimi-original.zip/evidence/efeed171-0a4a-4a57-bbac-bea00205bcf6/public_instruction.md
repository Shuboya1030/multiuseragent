As of 2026-11-05: Prepare the shipping order for demo hardware to customer Fabrikam. Save /workspace/deliverable.json with customer, carrier, ship_date, delivery_days. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/o-low-demo-shipment.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000
