As of 2026-11-05: Prepare the interview panel plan for six backend candidates. Save /workspace/deliverable.json with panel_size, certified_interviewers, training_cost_usd. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/o-high-interview-panel.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000
