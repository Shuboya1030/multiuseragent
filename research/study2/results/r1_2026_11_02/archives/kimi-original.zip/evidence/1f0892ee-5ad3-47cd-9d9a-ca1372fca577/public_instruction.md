As of 2026-11-05: Prepare the Q4 production access recertification for the API server. Save /workspace/deliverable.json with accounts_to_keep, accounts_to_remove, hr_status_ref, authorization_ref. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/m-high-access-recert.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000
