As of 2026-11-05: Plan the AI team offsite in Toronto. Save /workspace/deliverable.json with date, venue, attendees, calendar_conflicts. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/o-med-offsite-date.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000
