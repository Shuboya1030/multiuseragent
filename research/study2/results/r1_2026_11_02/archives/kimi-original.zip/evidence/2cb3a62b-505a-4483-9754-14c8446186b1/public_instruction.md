As of 2026-11-05: Prepare the security exception record for giving partner Orbit access to the /v2/test-search endpoint. Save /workspace/deliverable.json with endpoint, risk_rating, business_justification_id, authorization_ref. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/m-med-security-exception.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000
