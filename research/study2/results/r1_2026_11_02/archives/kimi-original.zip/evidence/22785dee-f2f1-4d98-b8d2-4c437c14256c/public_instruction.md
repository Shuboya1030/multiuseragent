As of 2026-11-05: Prepare the onboarding record for new hire R. Patel (offer O-317). Save /workspace/deliverable.json with offer_id, employee_id, start_date, department. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/m-low-new-hire-record.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000
