As of 2026-11-05: Prepare the customer mailing request for the Q4 upgrade notice to enterprise accounts. Save /workspace/deliverable.json with segment_id, recipient_count, send_date, authorization_ref. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/m-low-customer-mailing.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000
