As of 2026-11-05: Prepare the service credit memo for customer Northwind after the October outage (monthly fee USD 8000). Save /workspace/deliverable.json with customer, credit_percent, credit_usd, authorization_ref. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/m-med-service-credit.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000
