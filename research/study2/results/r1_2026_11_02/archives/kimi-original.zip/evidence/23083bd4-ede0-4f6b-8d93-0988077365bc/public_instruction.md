As of 2026-11-05: Prepare the press fact sheet for the OpenSearch 2.12 launch. Save /workspace/deliverable.json with headline, exec_quote_id, boilerplate_version. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/o-low-press-factsheet.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000
