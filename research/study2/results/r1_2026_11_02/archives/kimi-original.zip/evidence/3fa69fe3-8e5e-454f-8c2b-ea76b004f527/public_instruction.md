As of 2026-11-05: Prepare the integration config for partner Orbit. Save /workspace/deliverable.json with partner, key_alias, scope, expires_on. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/m-low-partner-key-config.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000
