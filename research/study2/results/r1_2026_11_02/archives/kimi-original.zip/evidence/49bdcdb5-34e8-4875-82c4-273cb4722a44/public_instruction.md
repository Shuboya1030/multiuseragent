As of 2026-11-05: Prepare the renewal quote for customer Litware. Save /workspace/deliverable.json with term_years, annual_usd, total_usd. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/o-med-renewal-quote.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000
