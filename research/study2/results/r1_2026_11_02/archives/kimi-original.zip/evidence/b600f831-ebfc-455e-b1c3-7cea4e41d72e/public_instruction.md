Prepare the cost sheet for the Harbor customer workshop. Save /workspace/deliverable.json with attendees, package_code and total_usd. Post the file path and total in #engineering.

Work packet: OwnCloud Documents/Study21V2/o-medium-event-package.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000
