Prepare the twelve-month VectorBench order for project Pine as of 2026-11-02. Save /workspace/deliverable.json with seats, total_usd, allocation_revision, budget_code and release_reference. Post its path and a brief order summary in #engineering.

Work packet: OwnCloud Documents/Study21V2/m-medium-research-purchase.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000
