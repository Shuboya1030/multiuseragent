# Study 2.1 first formal R1 block — frozen protocol 2026-10-25

> Historical three-class suite only. This frozen block and its USD 10 authorization
> do not apply to the new two-class 60 tasks. The current new-suite REST method is
> `task_generation_v2\R1_REST_Protocol.md`; do not pool these data or reuse this budget.

## Authorization and scope

After reviewing the six supplemental episodes, the user explicitly instructed: “不改了挺好的，跑study 2.1的第一个正式实验（R1正式）吧” and selected a USD 10 API budget. Preserve task texts, gold, NPC behavior, evaluator v3 and provider generation settings. This instruction supersedes earlier recommendations to revise tasks or finish the old 27-episode pilot before proceeding. Independent task review and optional semantic-quality validation are NOT claimed complete. No-help output-contract ambiguity and Optional lexical-proxy limitations remain explicit qualifications on interpretation.

Collect exactly 60 frozen templates × 3 configurations × R1 × replicate 1 = 180 planned episodes, separately from all pilots. Must uses separated only; each class contributes 20 templates per model. R0 and additional replicates are not authorized in this block. `run_type=confirmatory` identifies the planned collection stage, not satisfaction of all originally proposed scientific review gates. Tasks remain development drafts; reports must disclose the user's as-is collection decision and limit confirmatory claims accordingly.

## Pairing, order and stopping

Randomization seed 2026102501. Shuffle the 20 templates within each class; create 20 rounds containing one template from each class in shuffled class order. For each template run all three providers, with the six provider-order permutations each used exactly ten times, shuffled before collection. This balances provider position (20 times in each position), interleaves providers and classes, and avoids running one provider's entire block first. Instance seeds 202610250100 + sorted-template index; identical template seeds across models, reserved for later paired R0. Save the full schedule, not just the seed. No model-level random seed is available; sampling stays at previously tested provider defaults.

One attempt per planned episode; no automatic API retry or outcome-based replacement. API, parse, refusal, truncation and max-turn failures remain in the ledger. A process interruption may resume only unstarted cells after hash and manifest verification; never repeat a started cell. Three consecutive API failures for any provider, or three parser failures within its most recent ten episodes, stop the collection for investigation. Also stop for model-ID drift, evidence isolation/replay failure, changed source hashes, budget guard violation or evaluator exception. Failed model choices/task outputs alone do not trigger stopping. Inspect runtime status/cost only during collection; freeze raw data and checksums before comparing behavior/outcomes.

## Runtime and budget

Use the tested shared episode engine via a dedicated formal entry point; unchanged system/task/tool semantics, isolated inbox, max 8 turns and 1600 output tokens/request, native provider serialization, 21-second minimum Moonshot interval. OpenAI requests `gpt-5.4-mini` and must return `gpt-5.4-mini-2026-03-17`; Moonshot requests/returns `kimi-k2.6`; Anthropic requests/returns `claude-haiku-5-5`. Alias drift causes a stop, not substitution. Same reasoning/settings as pilots; this is not a comparison at equal reasoning budget. Private reasoning is not persisted or sent back by the tested adapters; this is a known implementation constraint, especially for Kimi multi-step continuity.

List prices checked 2026-10-25, USD per million tokens: OpenAI input 0.75 / cached 0.075 / output 4.50; Kimi input 0.95 / cached 0.16 / output 4.00; Haiku (prompts ≤100k) input 0.10 / cached 0.01 / output 0.50. No cache creation is requested. Haiku cache writes, if returned unexpectedly, use 1h price 0.20 conservatively. Store usage-derived estimated cost separately from actual provider billing, which is unavailable. No paid server tools are used.

The user budget is USD 10. Use USD 9 as the operating ceiling, reserving USD 1 for billing/tax variance; this is a local list-price guard, not a provider-enforced account spending limit. Before every episode reserve eight worst-case requests, with 32768 input tokens and 1600 output tokens each at uncached prices. Before each request reject inputs whose conservative serialized message/tool UTF-8 byte bound plus 4096 overhead exceeds 32768; stop if reported usage violates the bound. Unknown usage on failed requests is charged the full reserved call amount in the safety ledger. Report actual estimated usage separately from reserved/unknown charges. Freeze pricing and run order before API calls. Do not request automatic repeats or consume R0 budget.

Sources: [OpenAI model pricing]([REDACTED_RUNTIME_ENDPOINT]/api/docs/models/gpt-5.4-mini), [Kimi pricing]([REDACTED_RUNTIME_ENDPOINT]/docs/pricing/chat), [Haiku pricing]([REDACTED_RUNTIME_ENDPOINT]/docs/en/models/haiku-5-5/overview). Kimi's rendered HTML explicitly lists K2.6's 0.95/4.00/0.16 rates; text extraction omits that table.

## Analysis plan and limits

Fixed sample for this first R1 block: no adaptive extension. A descriptive 95% interval half-width of 0.10 is a reporting target, not a stopping or extra-call trigger. Report precision shortfalls as such. Any future precision-driven extension requires a separately frozen R0/R1 protocol before further data; the earlier unspecified repeat rule is not activated here.

Template is the analysis unit (20 per class, 60 total), with three models paired. Primary R1 descriptive outcomes: Must underhelp, class-specific calibration, No-help overhelp; Optional contact without verified lexical gain reported separately. Task success and checkpoint scores remain separate. Report denominators/missingness, first-contact and path errors, contacts, turns, input/output tokens, estimated costs and latency. Do not pool checkpoint denominators. For binary class rates use Wilson 95% intervals; for paired model differences use template bootstrap (10000 resamples, seed 2026102502); for binary contrasts use exact paired McNemar tests and Holm correction across the nine predeclared comparisons (three model pairs × Must underhelp / No-help overhelp / Optional ineffective-contact incidence). These R1-only contrasts are supplemental; they cannot establish R1−R0 effects. No association is causal. Additional task-success comparisons are descriptive.

All planned failures remain visible. Task-success failure counts include non-submissions. Missing/incomplete process traces are unknown rather than silently filled as zero; provide observed-trace denominators and sensitivity bounds. Freeze data before outcome inspection. Archive full sanitized traces/requests, metadata, versions, schedule, prices, cost ledger, source snapshots, API errors, validation reports and file hashes. Retain all pilot files unchanged.

Workflow guidance: local `experimental-design`, `statistical-experimental-evaluation`, and `results-analysis` skills. Design uses standard-library seeded randomization and explicit saved schedules, without installing DOE libraries.
