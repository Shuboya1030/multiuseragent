"""Two explicitly authorized technical reruns; financial safeguards unchanged."""
import copy
import json
from pathlib import Path
import sys
import uuid

ROOT = Path(__file__).resolve().parent
ISOLATION = ROOT.parents[1]
SOURCE_BASE = Path(
    r"provenance/primary")
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT.parent))
import frozen_repair as frozen

rest, batch = frozen.rest, frozen.batch
AUTH = "assignment:741f367f-a37b-48de-a57d-1e7bbe84ade4:call_a55dCqcpq06h7L22McCu4QVG"
USER_QUOTE = "技术异常，未完成交付的这俩重新跑。"
BACKEND = frozen.BACKEND
MODEL_ID = "kimi-k2.6"
VERSION = "kimi-two-authorized-technical-reruns-v1"
FINANCIAL_INPUT_ENVELOPE = 262144
CONTEXT_SOURCE = "[REDACTED_RUNTIME_ENDPOINT]/docs/guide/kimi-k2-6-quickstart"
SLOTS = {"m-med-security-exception", "m-medium-research-purchase"}
PREVIOUS_ROOT = ISOLATION.parent / "r1_six_input_waiver" / "frozen_stage" / "six_runner"
SOURCE_CURSOR = PREVIOUS_ROOT / "stage" / "service_cursor.json"

# Only the frozen batch's read-only source references and shared pacer are redirected.
batch.BASE = SOURCE_BASE
batch.OLD = SOURCE_BASE.parent / "r1_local_services" / "deployment_20261027"
batch.STAGE = ROOT / "stage"
frozen.pacing.BASE = SOURCE_BASE
frozen.AUTH = AUTH
stop_check = frozen.stop_check
Http = frozen.Http
Services = frozen.Services


def waiver_metadata():
    return {
        "version": VERSION, "authorization": AUTH, "user_quote": USER_QUOTE,
        "Kimi_local_input_gate_waived": True, "accurate_token_counting_verified": False,
        "study_input_cap_tokens": 32768, "study_input_cap_prevalidated": False,
        "full_messages_and_tools_preserved": True, "history_truncated_or_summarized": False,
        "provider_context_limits_still_apply": True,
        "financial_input_envelope_tokens": FINANCIAL_INPUT_ENVELOPE,
        "financial_envelope_not_a_prompt_count": True,
        "financial_envelope_basis": "Official Kimi K2.6 256K context window; reserve full window",
        "financial_envelope_source": CONTEXT_SOURCE,
        "NPC_backend": BACKEND, "NPC_truthful_extra_policy": "NPC-truthful-extra-v3",
        "attempts_per_slot": 1, "no_automatic_retry": True,
        "additional_attempt_explicitly_authorized": True,
        "business_review_policy": "content-correct-format-only-differences-pass; pending-or-complete-request-allowed-unless-grant-required",
    }


class Ledger(frozen.Ledger):
    def reserve(self, role, request):
        stop_check()
        if role != "agent" or request["model"] != MODEL_ID:
            return super().reserve(role, request)
        rest.require(self.config.get("task_id") in SLOTS
                     and self.config.get("Kimi_input_gate_waiver") == waiver_metadata(),
                     "Kimi waiver is authorized only for the two newly authorized technical reruns")
        rest.require(self.config["max_input_token_bound"] == 32768
                     and self.config["max_agent_steps"] == 64
                     and self.config["max_npc_calls"] == 64
                     and self.config["max_npc_output_tokens"] == 1024,
                     "Unapproved study-limit change")
        rest.require(request["max_tokens"] == self.config["max_agent_output_tokens"] == 2048
                     and request.get("thinking") == {"type": "disabled"},
                     "Kimi output or thinking policy changed")
        prices = self.config["role_prices_per_million"]["agent"]
        rest.require(prices == rest.PRICE_BOOK[MODEL_ID] and self.cap == rest.Decimal(20),
                     "Shared budget or approved price drift")
        # Full provider context is a monetary envelope, never an input admission test.
        bound = FINANCIAL_INPUT_ENVELOPE
        amount = (bound * rest.positive(prices["input"])
                  + request["max_tokens"] * rest.positive(prices["output"])) / 1_000_000
        if sum(self.charges.values(), rest.Decimal(0)) + amount > self.cap:
            raise frozen.RepairError("Batch safety budget exhausted", "shared_budget_exhausted")
        call = str(uuid.uuid4())
        rest.append(self.path, {
            "event": "reserve", "id": call, "role": role, "model": MODEL_ID,
            "amount_usd": str(amount), "input_bound": bound,
            "input_bound_kind": "full-provider-context-financial-envelope-only",
            "prices_per_million": prices, "input_price_multiplier": 1,
            "timestamp": rest.timestamp(), "waiver_version": VERSION,
            "study_input_cap_prevalidated": False,
        })
        self.charges[call] = amount
        return call, bound

    def settle(self, call, role, usage, bound, maximum):
        if role == "agent" and self.config["agent_model"] == MODEL_ID:
            rest.append(Path(self.config["token_count_receipts_dir"]) / "actual_usage.jsonl", {
                "call_id": call, "timestamp": rest.timestamp(), "usage": copy.deepcopy(usage),
                "actual_input_tokens": usage["prompt_tokens"],
                "actual_output_tokens": usage["completion_tokens"],
                "exceeds_original_study_input_cap": usage["prompt_tokens"] > 32768,
                "financial_envelope_tokens": bound, "input_count_prevalidated": False,
                "waiver_version": VERSION,
            })
        return super().settle(call, role, usage, bound, maximum)


class Model(frozen.Model):
    pass


def install():
    frozen.install()
    rest.Ledger = Ledger


def budget():
    rows = frozen.batch_lines(SOURCE_BASE / "shared_budget" / "cost_ledger.jsonl")
    reserves = {x["id"]: x for x in rows if x["event"] == "reserve"}
    settled = {x["id"]: x for x in rows if x["event"] == "settle"}
    unknown = {k: v for k, v in reserves.items() if k not in settled}
    used = sum((rest.Decimal(x["amount_usd"]) for x in settled.values()), rest.Decimal(0))
    held = sum((rest.Decimal(x["amount_usd"]) for x in unknown.values()), rest.Decimal(0))
    return {"settled_usd": str(used), "unknown_reserved_usd": str(held),
            "occupied_usd": str(used + held), "cap_usd": "20", "unknown": unknown,
            "ledger_events": len(rows)}
