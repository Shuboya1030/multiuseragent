"""Run local waiver checks with network disabled and persist pinned evidence."""
import unittest
from unittest.mock import patch

import controller as c
import runtime as r
import test_waiver


if __name__ == "__main__":
    before = r.rest.digest(r.SOURCE_BASE / "shared_budget" / "cost_ledger.jsonl")
    suite = unittest.defaultTestLoader.loadTestsFromModule(test_waiver)
    with patch("urllib.request.OpenerDirector.open", side_effect=AssertionError("Offline network forbidden")):
        result = unittest.TextTestRunner(verbosity=2).run(suite)
    unchanged = before == r.rest.digest(r.SOURCE_BASE / "shared_budget" / "cost_ledger.jsonl")
    passed = result.wasSuccessful() and unchanged
    r.rest.save(r.ROOT / "offline_validation.json", {
        "passed": passed, "tests_run": result.testsRun,
        "failures": len(result.failures), "errors": len(result.errors),
        "network_disabled": True, "paid_calls": 0, "source_ledger_unchanged": unchanged,
        "runtime_sha256": r.rest.digest(r.ROOT / "runtime.py"),
        "controller_sha256": r.rest.digest(r.ROOT / "controller.py"),
        "implementation_hashes": c.implementation_hashes(),
        "source_manifest_sha256": r.rest.digest(r.rest.ROOT / "artifact_manifest.json"),
        "condition_change": r.waiver_metadata(), "timestamp": r.rest.timestamp(),
    })
    raise SystemExit(0 if passed else 1)
