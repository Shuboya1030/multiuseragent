# R1 两条技术异常授权追加重跑

2个追加attempt均已终止；业务/NPC后验审读待完成

**这2条取消本地输入门；32768研究输入上限未事前验收，非准确计数修复。**
原55和前次6条结果独立保留；每槽位本授权至多一次新attempt，无pilot或自动重放。
共享预算占用 USD 4.93428760/20。
controller: ended / PID 31408。
STOP入口：[停止文件](provenance/independent/r1_two_technical_reruns/frozen_stage/two_runner/STOP_REQUESTED)（创建此文件阻止下一请求）。

| task | 原episode | 新episode | 状态 |
|---|---|---|---|
| m-med-security-exception | fe712c19-7a72-4815-9897-adb7cca81544 | 79ead09d-c4d2-47d0-853a-dc3da3fd013a | needs_review |
| m-medium-research-purchase | 34b6011c-bfb8-4e42-a9ee-876e32a8c1cb | 4291bf13-0f3b-472d-ade9-0b9ad900cdf5 | needs_review |
