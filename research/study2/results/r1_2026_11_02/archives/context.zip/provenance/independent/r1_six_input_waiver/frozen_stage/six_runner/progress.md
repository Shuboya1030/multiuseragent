# R1 六条 Kimi 输入门豁免进度

6个repair均已终止；业务/NPC后验审读待完成

**这6条取消本地输入门；32768研究输入上限未事前验收，非准确计数修复。**
原55结果独立保留；每槽位至多一次新repair，无额外pilot或自动重放。
共享预算占用 USD 4.87247390/20。
controller: ended / PID 50716。
STOP入口：[停止文件](provenance/independent/r1_six_input_waiver/frozen_stage/six_runner/STOP_REQUESTED)（创建此文件阻止下一请求）。

| task | 原episode | 新episode | 状态 |
|---|---|---|---|
| m-medium-research-purchase | 94ae0a89-f86a-445f-8aca-77489fd98a0d | 34b6011c-bfb8-4e42-a9ee-876e32a8c1cb | infrastructure_error |
| m-high-model-release | 55e928c9-8ccd-4126-a981-2bb34eed5ecb | 22b29f03-76ff-443e-8755-d2c2e7cc6480 | needs_review |
| o-high-training-schedule | 47cb0ba8-77e1-4c07-828f-2daadafc6983 | f125f8e5-09ae-479c-81dc-e34605d5c4cf | needs_review |
| o-low-staging-region | ae37143b-9874-4078-ae52-060ca4bf67e1 | 5b984c39-bce0-486b-85d3-f040180aa1b1 | success |
| o-med-browser-matrix | 9bbdf5ac-19bd-424e-aa01-488e0c7b0fc0 | c4a3287e-4b42-4373-8054-0c31873d45c5 | needs_review |
| o-med-offsite-date | 6b1e8acc-c33d-48e7-83a5-e139406bc370 | f095daae-4414-4c0e-8992-80b4475ca1d3 | needs_review |
