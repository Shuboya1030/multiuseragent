"""Offline checks only: no HTTP, real account mutation, or paid calls."""
import copy
import csv
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import runtime as r
import controller


class WaiverTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=r.ROOT)
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name)
        self.ledger_path = self.directory / "cost_ledger.jsonl"
        self.config = r.rest.load(
            r.SOURCE_BASE / "execution_stage_v3" / "m-high-service-cutover" / "config.json")
        self.config.update(
            agent_model=r.MODEL_ID, task_id="m-high-model-release",
            role_prices_per_million={"agent": r.rest.PRICE_BOOK[r.MODEL_ID],
                                    "npc": r.rest.PRICE_BOOK[r.rest.MODEL]},
            token_count_receipts_dir=str(self.directory), Kimi_input_gate_waiver=r.waiver_metadata())
        self.request = r.rest.provider_adapters.build_request(
            r.MODEL_ID, [{"role": "user", "content": "x" * 100000}], r.rest.TOOLS).body

    def ledger(self):
        return r.Ledger(self.ledger_path, self.config)

    def rows(self):
        return r.frozen.batch_lines(self.ledger_path)

    def test_large_history_is_not_blocked_or_mutated(self):
        original = copy.deepcopy(self.request)
        call, bound = self.ledger().reserve("agent", self.request)
        self.assertEqual(self.request, original)
        self.assertGreater(len(json.dumps(self.request).encode()), 32768)
        self.assertEqual(bound, 262144)
        self.assertEqual(self.rows()[0]["id"], call)
        self.assertEqual(self.rows()[0]["amount_usd"], "0.2572288")
        self.assertFalse(self.rows()[0]["study_input_cap_prevalidated"])

    def test_actual_over_study_cap_is_recorded_and_legally_settled(self):
        ledger = self.ledger()
        call, bound = ledger.reserve("agent", self.request)
        usage = {"prompt_tokens": 40000, "completion_tokens": 100}
        ledger.settle(call, "agent", usage, bound, 2048)
        self.assertEqual(self.rows()[-1]["event"], "settle")
        self.assertEqual(self.rows()[-1]["amount_usd"], "0.0384")
        observed = r.frozen.batch_lines(self.directory / "actual_usage.jsonl")[0]
        self.assertTrue(observed["exceeds_original_study_input_cap"])
        self.assertEqual(observed["actual_input_tokens"], 40000)

    def test_financial_and_output_bounds_still_enforced(self):
        for usage in ({"prompt_tokens": 262145, "completion_tokens": 1},
                      {"prompt_tokens": 1, "completion_tokens": 2049}):
            ledger = self.ledger()
            call, bound = ledger.reserve("agent", self.request)
            with self.assertRaises(r.rest.RestError):
                ledger.settle(call, "agent", usage, bound, 2048)
            self.assertFalse(any(x["event"] == "settle" and x["id"] == call for x in self.rows()))

    def test_insufficient_budget_does_not_reserve_or_send(self):
        r.rest.append(self.ledger_path, {
            "event": "reserve", "id": "existing", "amount_usd": "19.9", "role": "agent"})
        with self.assertRaises(r.frozen.RepairError) as error:
            self.ledger().reserve("agent", self.request)
        self.assertEqual(error.exception.failure_kind, "shared_budget_exhausted")
        self.assertEqual(len(self.rows()), 1)

    def test_original_five_unknowns_remain_occupied(self):
        self.ledger_path.write_bytes(
            (r.SOURCE_BASE / "shared_budget" / "cost_ledger.jsonl").read_bytes())
        prefix = self.ledger_path.read_bytes()
        ledger = self.ledger()
        old_ids = set(ledger.charges)
        before = sum(ledger.charges.values(), r.rest.Decimal(0))
        self.assertEqual(before, r.rest.Decimal("4.14124565"))
        call, bound = ledger.reserve("agent", self.request)
        ledger.settle(call, "agent", {"prompt_tokens": 100, "completion_tokens": 10}, bound, 2048)
        self.assertTrue(self.ledger_path.read_bytes().startswith(prefix))
        self.assertTrue(old_ids <= ledger.charges.keys())
        self.assertEqual(sum(ledger.charges.values(), r.rest.Decimal(0)),
                         before + r.rest.Decimal("0.000135"))

    def test_waiver_scope_output_and_thinking_cannot_expand(self):
        for change in (
            {"task_id": "o-high-interview-panel"}, {"Kimi_input_gate_waiver": None},
            {"max_input_token_bound": 65536}, {"max_agent_steps": 65}, {"max_npc_calls": 65},
            {"max_npc_output_tokens": 2048}, {"max_agent_output_tokens": 4096},
        ):
            prior = copy.deepcopy(self.config)
            self.config.update(change)
            with self.assertRaises(r.rest.RestError):
                self.ledger().reserve("agent", self.request)
            self.config = prior
        self.request["thinking"] = {"type": "enabled"}
        with self.assertRaises(r.rest.RestError):
            self.ledger().reserve("agent", self.request)
        self.assertEqual(self.rows(), [])

    def test_npc_limit_and_original_input_guard_remain(self):
        npc = {"model": r.rest.MODEL, "messages": [{"role": "user", "content": "hello"}],
               "max_completion_tokens": 1024}
        ledger = self.ledger()
        ledger.npc_calls = 64
        with self.assertRaises(r.rest.RestError):
            ledger.reserve("npc", npc)
        ledger.npc_calls = 0
        npc["messages"][0]["content"] = "x" * 100000
        with self.assertRaises(r.frozen.RepairError):
            ledger.reserve("npc", npc)
        self.assertEqual(self.rows(), [])

    def test_stop_uses_own_directory_and_blocks_next_request(self):
        with patch.object(r.frozen, "ROOT", self.directory):
            (self.directory / "STOP_REQUESTED").touch()
            with self.assertRaises(r.frozen.RepairError) as error:
                self.ledger().reserve("agent", self.request)
        self.assertEqual(error.exception.failure_kind, "user_stop")
        self.assertEqual(self.rows(), [])

    def test_native_wire_is_unchanged_and_has_no_counter_call(self):
        seen = []

        class FakeHttp:
            def json(self, method, endpoint, headers, value):
                seen.append((method, endpoint, copy.deepcopy(value)))
                return {
                    "model": r.MODEL_ID, "usage": {
                        "prompt_tokens": 40000, "completion_tokens": 10, "total_tokens": 40010},
                    "choices": [{"finish_reason": "stop", "message":
                                 {"role": "assistant", "content": "Done."}}],
                }

        model = r.Model(self.config, FakeHttp(), self.ledger(), self.directory)
        with patch.dict("os.environ", {"MOONSHOT_API_KEY": "offline-test-only"}):
            reply = model.complete_native(self.request["messages"], r.rest.TOOLS)
        self.assertEqual(reply["content"], "Done.")
        self.assertEqual(len(seen), 1)
        self.assertEqual(seen[0], ("POST", r.frozen.pacing.ENDPOINT, self.request))
        self.assertEqual([x["event"] for x in self.rows()], ["reserve", "settle"])

    def test_persistent_account_pacer_keeps_21_seconds(self):
        original = r.frozen.pacing
        r.rest.append(self.directory / "kimi_account_pacing_v1.jsonl",
                      {"event": "send", "sent_at_epoch": 100.0})
        now = [101.0]

        def sleep(value):
            self.assertGreaterEqual(value, 0)
            now[0] += value

        pacer = r.frozen.fixed.Pacer(self.directory, clock=lambda: now[0], sleep=sleep)
        with pacer.slot():
            self.assertEqual(now[0], 121.0)
        with r.frozen.fixed.Pacer(self.directory, clock=lambda: now[0], sleep=sleep).slot():
            self.assertEqual(now[0], 142.0)
        self.assertEqual(original.MIN_INTERVAL, 21.0)
        self.assertEqual(original.BASE, r.SOURCE_BASE)

    def test_exact_source_six_and_all_original_hashes(self):
        blocked = [x for x in r.rest.load(r.SOURCE_BASE / "repair61_v1" / "progress.json")["slots"]
                   if x["state"] == "blocked_counting_method"]
        self.assertEqual(len(blocked), 6)
        self.assertEqual({x["task_id"] for x in blocked}, r.SLOTS)
        with (r.SOURCE_BASE / "exception_disposition_v2" / "Approved_Rerun_Scope.csv").open(
                encoding="utf-8-sig", newline="") as file:
            scope = {(x["provider"], x["task_id"]): x for x in csv.DictReader(file)}
        for slot in blocked:
            approved = scope["kimi", slot["task_id"]]
            self.assertEqual(approved["episode_id"], slot["original_episode_id"])
            self.assertFalse(slot.get("episode_id"))
            path = Path(slot["original_run"])
            expected = {str(Path(k)): v for k, v in json.loads(approved["original_hashes"]).items()}
            self.assertEqual({str(p.relative_to(path)): r.rest.digest(p)
                              for p in path.rglob("*") if p.is_file()}, expected)
        r.rest.verify_source()


if __name__ == "__main__":
    unittest.main()
