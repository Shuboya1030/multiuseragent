"""One additional isolated attempt per explicitly authorized technical failure."""
import csv
import ctypes
from ctypes import wintypes
import hashlib
import json
import msvcrt
import os
from pathlib import Path, PurePosixPath
import shutil
import sys
import uuid

import runtime as r

ROOT, rest, batch = r.ROOT, r.rest, r.batch
QUEUE = []


def implementation_hashes():
    return {str(p.relative_to(ROOT.parent)): rest.digest(p)
            for p in ROOT.parent.rglob("*")
            if p.is_file() and p.suffix in (".py", ".ps1")
            and "__pycache__" not in p.parts
            and (p.parent == ROOT.parent or p.parent == ROOT
                 or p.parent == ROOT.parent / "guarded_npc_runtime_v4" / "frozen_runtime")}


def atomic(path, value):
    batch.atomic(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def publish(action, state):
    data = {
        "version": r.VERSION, "updated_at": rest.timestamp(), "action": action,
        "controller": {"pid": os.getpid(), "state": state,
                       "stop_file": str(ROOT / "STOP_REQUESTED")},
        "scope": 2, "original_formal_denominator": 180, "separate_from_review55": True,
        "counts": {s: sum(x["state"] == s for x in QUEUE)
                   for s in sorted({x["state"] for x in QUEUE})},
        "slots": QUEUE, "budget": r.budget(), "condition_change": r.waiver_metadata(),
    }
    atomic(ROOT / "progress.json", data)
    lines = [
        "# R1 两条技术异常授权追加重跑", "", action, "",
        "**这2条取消本地输入门；32768研究输入上限未事前验收，非准确计数修复。**",
        "原55和前次6条结果独立保留；每槽位本授权至多一次新attempt，无pilot或自动重放。",
        f"共享预算占用 USD {data['budget']['occupied_usd']}/20。",
        f"controller: {state} / PID {os.getpid()}。",
        f"STOP入口：[停止文件]({ROOT / 'STOP_REQUESTED'})（创建此文件阻止下一请求）。",
        "", "| task | 原episode | 新episode | 状态 |", "|---|---|---|---|",
    ]
    for x in QUEUE:
        lines.append(f"| {x['task_id']} | {x['original_episode_id']} | "
                     f"{x.get('episode_id', '未启动')} | {x['state']} |")
    batch.atomic(ROOT / "progress.md", "\n".join(lines) + "\n")


def source_slots():
    security = next(x for x in rest.load(r.SOURCE_BASE / "repair61_v1" / "progress.json")["slots"]
                    if x["provider"] == "kimi" and x["task_id"] == "m-med-security-exception")
    purchase = next(x for x in rest.load(r.PREVIOUS_ROOT / "queue.json")
                    if x["task_id"] == "m-medium-research-purchase")
    return [security, purchase]


def frozen_queue():
    scope = r.SOURCE_BASE / "exception_disposition_v2" / "Approved_Rerun_Scope.csv"
    progress = r.SOURCE_BASE / "repair61_v1" / "progress.json"
    selected = source_slots()
    rest.require(len(selected) == 2 and {x["task_id"] for x in selected} == r.SLOTS
                 and all(x["provider"] == "kimi" and x["state"] == "infrastructure_error"
                         for x in selected), "Two authorized technical failure slots changed")
    with scope.open(encoding="utf-8-sig", newline="") as file:
        approved = {(x["provider"], x["task_id"]): x for x in csv.DictReader(file)}
    rest.save(ROOT / "source_technical_failure_slots.json", selected)
    rest.save(ROOT / "original_approved_scope_snapshot.json",
              [approved["kimi", x["task_id"]] for x in selected])
    originals = ROOT / "originals"
    originals.mkdir()
    result = []
    for x in selected:
        row = approved["kimi", x["task_id"]]
        formal_id = x["original_episode_id"]
        rest.require(row["episode_id"] == formal_id, "Approved formal episode mismatch")
        formal = Path(x.get("source_original_run", x["original_run"]))
        expected = {str(Path(k)): v for k, v in json.loads(row["original_hashes"]).items()}
        rest.require({str(p.relative_to(formal)): rest.digest(p)
                      for p in formal.rglob("*") if p.is_file()} == expected,
                     "Original formal episode hashes changed: " + x["task_id"])
        old = Path(x["output"])
        manifest = rest.load(old / "run_manifest.json")
        rest.require(manifest["episode_id"] == x["episode_id"]
                     and manifest["original_episode_id"] == formal_id
                     and manifest["npc_backend"] == r.BACKEND,
                     "Prior repair episode or backend mismatch")
        error = rest.load(old / "runtime_error.json")
        kind = {"m-med-security-exception": "local_unverified_count_limit",
                "m-medium-research-purchase": "agent_protocol_violation"}[x["task_id"]]
        rest.require(error["failure_kind"] == kind
                     and rest.load(old / "status.json")["collection_complete"],
                     "Prior technical failure or export not verified")
        prior_hashes = {str(p.relative_to(old)): rest.digest(p)
                        for p in old.rglob("*") if p.is_file()}
        target = originals / x["task_id"]
        shutil.copytree(old, target)
        rest.require({str(p.relative_to(target)): rest.digest(p)
                      for p in target.rglob("*") if p.is_file()} == prior_hashes,
                     "Original freeze mismatch")
        config_path = (r.SOURCE_BASE / "repair61_v1" / "stage" / "repair" / "kimi" / x["task_id"]
                       / "config.json") if x["task_id"] == "m-med-security-exception" else (
                           r.PREVIOUS_ROOT / "stage" / "repair" / x["task_id"] / "config.json")
        config = rest.load(config_path)
        rest.require(rest.config_digest(config) == manifest["configuration_sha256"],
                     "Prior approved repair configuration mismatch")
        rest.save(ROOT / (x["task_id"] + "_prior_config.json"), config)
        result.append({
            "provider": "kimi", "task_id": x["task_id"],
            "formal_original_episode_id": formal_id,
            "formal_original_run": str(formal), "formal_original_hashes": expected,
            "original_episode_id": x["episode_id"], "original_run": str(target),
            "source_original_run": str(old), "original_hashes": prior_hashes,
            "prior_configuration_path": str(config_path),
            "prior_configuration_sha256": rest.digest(config_path),
            "repair_attempt_id": str(uuid.uuid4()), "state": "pending",
            "condition_change": r.waiver_metadata(),
        })
    rest.save(ROOT / "source_scope_freeze.json", {
        "scope_sha256": rest.digest(scope), "progress_sha256": rest.digest(progress),
        "slots": result, "source_base": str(r.SOURCE_BASE)})
    return result


def acquire_gate():
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
                                  wintypes.LPVOID, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
    kernel.CreateFileW.restype = wintypes.HANDLE
    path = r.SOURCE_BASE / "shared_budget" / "exclusive.lock"
    handle = kernel.CreateFileW(str(path), 0xC0000000, 0, None, 3, 0x80, None)
    if handle == ctypes.c_void_p(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())
    fd = msvcrt.open_osfhandle(handle, os.O_RDWR)
    try:
        old = os.read(fd, 4096)
        rest.require(old.startswith(b"KIMI_SIX_WAIVER_STOPPED:"),
                     "Unknown shared controller marker; do not overwrite")
        rest.save(ROOT / "prior_shared_gate.json", {"content": old.decode(), "authorization": r.AUTH})
        os.lseek(fd, 0, os.SEEK_SET)
        os.write(fd, f"KIMI_TWO_TECHNICAL_ACTIVE pid={os.getpid()}\n".encode())
        os.ftruncate(fd, os.lseek(fd, 0, os.SEEK_CUR))
        os.fsync(fd)
    except BaseException:
        os.close(fd)
        raise
    return fd


def configuration(slot, directory):
    config, _ = batch.config_for("kimi", slot["task_id"], "formal")
    prior = rest.load(Path(slot["original_run"]) / "run_manifest.json")
    approved_config = rest.load(ROOT / (slot["task_id"] + "_prior_config.json"))
    for key in ("agent_model", "npc_model", "max_agent_steps", "max_npc_calls",
                "max_agent_output_tokens", "max_npc_output_tokens", "max_input_token_bound"):
        config[key] = prior[key]
        rest.require(config[key] == approved_config[key], "Prior manifest/config limit mismatch")
    rest.require(config["role_prices_per_million"] == approved_config["role_prices_per_million"],
                 "Prior model price book changed")
    rest.require(config["agent_model"] == r.MODEL_ID and config["npc_model"] == rest.MODEL,
                 "Original models changed")
    config.update(
        task_id=slot["task_id"], authorization_ref=r.AUTH, npc_backend=r.BACKEND,
        npc_method_authorization_file=str(ROOT / "authorization.json"),
        readiness_file=str(directory / "repair_readiness.json"),
        batch_dir=str(directory / "batch"), ledger_dir=str(r.SOURCE_BASE / "shared_budget"),
        token_count_receipts_dir=str(directory / "token_count_receipts"),
        Kimi_input_gate_waiver=r.waiver_metadata(),
        authorized_rerun={"attempt_id": slot["repair_attempt_id"],
                          "original_episode_id": slot["original_episode_id"]},
    )
    return config


def run_episode(slot, config, output):
    output.mkdir(parents=True)
    ident = str(uuid.uuid4())
    Path(config["token_count_receipts_dir"]).mkdir(parents=True, exist_ok=True)
    instruction = (Path(slot["original_run"]) / "public_instruction.md").read_text(encoding="utf-8")
    source = rest.ROOT / "templates" / slot["task_id"] / "tac" / "task.md"
    rest.require(instruction == rest.public_instruction(source.read_text(encoding="utf-8"), config),
                 "Original public Agent task changed")
    old = rest.load(Path(slot["original_run"]) / "run_manifest.json")
    keys = ("method", "phase", "authorization_ref", "budget_usd", "agent_model", "npc_model",
            "prices_per_million", "max_agent_steps", "max_npc_calls", "max_agent_output_tokens",
            "max_npc_output_tokens", "max_input_token_bound")
    manifest = {k: config[k] for k in keys}
    manifest.update(
        task_id=slot["task_id"], episode_id=ident, original_episode_id=slot["original_episode_id"],
        formal_original_episode_id=slot["formal_original_episode_id"],
        repair_attempt_id=slot["repair_attempt_id"], started=rest.timestamp(), condition="R1",
        presentation=rest.PRESENTATION, npc_backend=r.BACKEND,
        original_npc_backend=old["npc_backend"], repair_version=r.VERSION,
        runner_sha256=rest.digest(Path(rest.__file__)), overlay_sha256=rest.digest(ROOT / "runtime.py"),
        controller_sha256=rest.digest(Path(__file__)), configuration_sha256=rest.config_digest(config),
        source_manifest_sha256=rest.digest(rest.ROOT / "artifact_manifest.json"),
        service_instance=rest.load(config["readiness_file"])["service_instance"],
        task_blueprint_sha256=old["task_blueprint_sha256"], instance_seed=old["instance_seed"],
        original_formal_result_preserved=True, no_automatic_retry=True,
        approvals_scored_posthoc_not_in_Agent_prompt=True, condition_change=r.waiver_metadata(),
    )
    rest.save(output / "run_manifest.json", manifest)
    (output / "public_instruction.md").write_text(instruction, encoding="utf-8")
    slot.update(episode_id=ident, state="running", output=str(output))
    atomic(ROOT / "queue.json", QUEUE)
    publish("准备完毕，等待真实Agent响应：" + slot["task_id"], "running")
    service = r.Services(config, slot["task_id"], rest.Http(),
                         r.Model(config, rest.Http(),
                                 r.Ledger(r.SOURCE_BASE / "shared_budget" / "cost_ledger.jsonl",
                                          config), output), output, ident)
    terminal, complete = "not_started", False
    try:
        service.bootstrap()
        terminal = rest.agent_loop(service.model, service, config, output, instruction)
    except (rest.RestError, OSError, ValueError, KeyError, TypeError, IndexError) as error:
        terminal = "runtime_error"
        rest.save(output / "runtime_error.json", {
            "error_type": type(error).__name__, "message": str(error),
            "failure_kind": getattr(error, "failure_kind", "runtime_error"),
            "details": getattr(error, "details", {}), "timestamp": rest.timestamp(), "no_replay": True})
    finally:
        rest.save(output / "workspace.json", service.files)
        (output / "workspace").mkdir()
        for path, contents in service.files.items():
            (output / "workspace" / PurePosixPath(path).name).write_text(contents, encoding="utf-8")
        try:
            rest.save(output / "trace_bundle.json", service.collect())
            complete = True
        except (rest.RestError, OSError, ValueError, KeyError, TypeError) as error:
            rest.save(output / "collection_error.json", {
                "error_type": type(error).__name__, "message": str(error), "complete": False})
        rest.save(output / "status.json", {
            "terminal": terminal, "collection_complete": complete, "submitted": service.submitted,
            "finished": rest.timestamp(), "method": rest.METHOD})
    if service.bootstrapped:
        summary = batch.audit(config, slot["task_id"], output)
    else:
        summary = {
            "state": "infrastructure_error", "episode_id": ident, "terminal": terminal,
            "complete": complete, "npc_calls": 0, "strict_success": None,
            "note": "bootstrap incomplete; no invented evaluation",
        }
    observations = r.frozen.batch_lines(Path(config["token_count_receipts_dir"]) / "actual_usage.jsonl")
    summary.update(
        condition_change=r.waiver_metadata(), actual_usage_observations=len(observations),
        max_actual_agent_input_tokens=max((x["actual_input_tokens"] for x in observations), default=None),
        calls_exceeding_original_study_input_cap=[
            x["call_id"] for x in observations if x["exceeds_original_study_input_cap"]],
        business_semantic="pending_nonblind_session_AI_review",
        NPC_semantic="pending_nonblind_session_AI_review",
    )
    if summary["npc_calls"] and summary["state"] != "infrastructure_error":
        summary.update(state="needs_review", strict_success=None)
    rest.save(output / "controller_summary.json", summary)
    rest.save(output / "posthoc_business_NPC_review.json", {
        "business": "pending_nonblind_session_AI_review",
        "NPC_compliance": "pending_nonblind_session_AI_review",
        "approval_rule": "pending-or-full-request-unless-task-explicitly-requires-grant",
        "correct_extra_information_is_not_NPC_error": True,
        "correct_reference_does_not_prove_actual_approval": True,
        "wrong_facts_scope_grants_and_false_refusals_still_errors": True,
        "original_grader_preserved": True, "automatic_keyword_judge_used": False,
        "R_prime_computed": False,
    })
    return summary


def verify_baseline():
    baseline = rest.load(ROOT / "baseline.json")
    ledger = (r.SOURCE_BASE / "shared_budget" / "cost_ledger.jsonl").read_bytes()
    prefix = ledger[:baseline["ledger_bytes"]]
    rest.require(hashlib.sha256(prefix).hexdigest() == baseline["ledger_sha256"],
                 "Historical ledger prefix changed")
    rest.require(set(baseline["budget"]["unknown"]) <= set(r.budget()["unknown"]),
                 "Historical unknown reservation was released")
    pacer = (r.SOURCE_BASE / "shared_budget" / "kimi_account_pacing_v1.jsonl").read_bytes()
    rest.require(hashlib.sha256(pacer[:baseline["pacer_bytes"]]).hexdigest()
                 == baseline["pacer_sha256"], "Historical pacer prefix changed")
    rest.require({path: rest.digest(Path(path)) for path in baseline["readonly_file_hashes"]}
                 == baseline["readonly_file_hashes"], "Prior state or STOP/cursor was modified")
    for slot in QUEUE:
        path = Path(slot["source_original_run"])
        rest.require({str(p.relative_to(path)): rest.digest(p)
                      for p in path.rglob("*") if p.is_file()} == slot["original_hashes"],
                     "Prior technical episode evidence changed")
        formal = Path(slot["formal_original_run"])
        rest.require({str(p.relative_to(formal)): rest.digest(p)
                      for p in formal.rglob("*") if p.is_file()} == slot["formal_original_hashes"],
                     "Original formal evidence changed")
        rest.require(rest.digest(Path(slot["prior_configuration_path"])) ==
                     slot["prior_configuration_sha256"], "Prior configuration changed")
    rest.save(ROOT / "preservation_validation.json", {
        "timestamp": rest.timestamp(), "historical_ledger_prefix_preserved": True,
        "original_unknown_ids_preserved": sorted(baseline["budget"]["unknown"]),
        "original_episode_hashes_preserved": True, "budget": r.budget()})


def main():
    global QUEUE
    rest.verify_source()
    validation = rest.load(ROOT / "offline_validation.json")
    rest.require(validation["passed"] and validation["runtime_sha256"] == rest.digest(ROOT / "runtime.py")
                 and validation["controller_sha256"] == rest.digest(Path(__file__))
                 and validation["implementation_hashes"] == implementation_hashes(),
                 "Offline validation absent or changed")
    rest.require(not (ROOT / "queue.json").exists() and not (ROOT / "STOP_REQUESTED").exists(),
                 "Existing queue/STOP: no automatic restart")
    rest.require(not (r.SOURCE_BASE / "execution_stage_v7" / "execution_controller.lock").exists(),
                 "Source execution controller lock exists")
    rest.require(rest.load(r.SOURCE_BASE / "progress.json")["active_controller"]["status"] == "stopped",
                 "Source controller is not stopped")
    with (ROOT / "controller.lock").open("x", encoding="utf-8") as lock:
        lock.write(json.dumps({"pid": os.getpid(), "authorization": r.AUTH,
                               "STOP": str(ROOT / "STOP_REQUESTED")}))
    fd = None
    try:
        fd = acquire_gate()
        ledger = r.SOURCE_BASE / "shared_budget" / "cost_ledger.jsonl"
        pacer = r.SOURCE_BASE / "shared_budget" / "kimi_account_pacing_v1.jsonl"
        readonly = [
            r.SOURCE_BASE / "repair61_v1" / name
            for name in ("progress.json", "queue.json", "STOP_REQUESTED", "stage/service_cursor.json")]
        readonly += [r.PREVIOUS_ROOT / name
                     for name in ("queue.json", "progress.json", "stage/service_cursor.json")]
        rest.save(ROOT / "baseline.json", {
            "ledger_bytes": ledger.stat().st_size, "ledger_sha256": rest.digest(ledger),
            "pacer_bytes": pacer.stat().st_size, "pacer_sha256": rest.digest(pacer),
            "readonly_file_hashes": {str(path): rest.digest(path) for path in readonly},
            "budget": r.budget(), "timestamp": rest.timestamp()})
        QUEUE = frozen_queue()
        rest.save(ROOT / "authorization.json", {
            **r.waiver_metadata(), "original_scope_sha256":
                rest.digest(r.SOURCE_BASE / "exception_disposition_v2" / "Approved_Rerun_Scope.csv"),
            "NPC_prompt_sha256": hashlib.sha256(r.frozen.NPC_POLICY.encode()).hexdigest(),
            "models": {"agent": r.MODEL_ID, "NPC": rest.MODEL},
            "budget_usd": 20, "original_55_not_replayed": True,
        })
        (ROOT / "stage").mkdir()
        cursor = rest.load(r.SOURCE_CURSOR)
        rest.save(ROOT / "stage" / "service_cursor.json", cursor)
        rest.save(ROOT / "source_service_cursor_freeze.json", cursor)
        r.install()
        atomic(ROOT / "queue.json", QUEUE)
        publish("离线验收通过；2条技术异常追加授权，尚无真实Agent响应", "preparing")
        for slot in QUEUE:
            r.stop_check()
            output = ROOT / "episodes" / slot["task_id"]
            directory = ROOT / "stage" / "repair" / slot["task_id"]
            rest.require(not output.exists() and not directory.exists(), "Never replace an attempt")
            slot["state"] = "preparing"
            atomic(ROOT / "queue.json", QUEUE)
            publish("准备独立repair：" + slot["task_id"], "preparing")
            config = configuration(slot, directory)
            try:
                batch.prepare(config, "kimi", slot["task_id"], "formal", directory, output)
            except (rest.RestError, OSError, ValueError, KeyError, TypeError) as error:
                slot.update(state="blocked_preparation", block_reason=str(error))
                raise
            legacy = rest.load(directory / "readiness.json")
            rest.save(directory / "repair_readiness.json", {
                "service_instance": legacy["service_instance"], "NPC_backend": r.BACKEND,
                "nonpaid_local_isolation_verified": True, "condition_change": r.waiver_metadata(),
                "old_guarded_preflight_not_new_validation": True,
                "offline_validation_sha256": rest.digest(ROOT / "offline_validation.json")})
            result = run_episode(slot, config, output)
            slot.update(state=result["state"], result=result)
            rest.append(ROOT / "results.jsonl", {
                "task_id": slot["task_id"], "original_episode_id": slot["original_episode_id"], **result})
            atomic(ROOT / "queue.json", QUEUE)
            publish("repair已终止：" + slot["task_id"] + " / " + slot["state"], "running")
            print("EPISODE_COMPLETE", json.dumps({
                "task_id": slot["task_id"], "episode_id": slot["episode_id"], "state": slot["state"],
                "terminal": result["terminal"], "agent_calls": result.get("agent_calls"),
                "npc_calls": result["npc_calls"], "cost_usd": result.get("cost_usd"),
                "max_actual_agent_input_tokens": result["max_actual_agent_input_tokens"],
                "calls_exceeding_original_study_input_cap":
                    len(result["calls_exceeding_original_study_input_cap"])}, ensure_ascii=False), flush=True)
            if result["state"] == "infrastructure_error":
                error = rest.load(output / "runtime_error.json") if (output / "runtime_error.json").exists() \
                    else {"failure_kind": "collection_failed", "message": "Incomplete export"}
                kind = error.get("failure_kind")
                if kind not in ("agent_protocol_violation", "context_limit", "local_unverified_count_limit"):
                    raise r.frozen.RepairError(error["message"], kind or "unknown_infrastructure")
        verify_baseline()
        publish("2个追加attempt均已终止；业务/NPC后验审读待完成", "ended")
        rest.save(ROOT / "completion.json", {
            "timestamp": rest.timestamp(), "all_two_terminal": True, "no_automatic_retry": True,
            "budget": r.budget(), "condition_change": r.waiver_metadata()})
    except (rest.RestError, OSError, ValueError, KeyError, TypeError) as error:
        rest.save(ROOT / "controller_error.json", {
            "timestamp": rest.timestamp(), "error_type": type(error).__name__, "message": str(error),
            "failure_kind": getattr(error, "failure_kind", "controller_error"),
            "no_automatic_restart": True})
        for slot in QUEUE:
            if slot["state"] == "pending":
                slot.update(state="blocked_controller", block_reason=str(error))
        atomic(ROOT / "queue.json", QUEUE)
        publish("controller停止：" + str(error), "blocked")
        if (ROOT / "baseline.json").exists() and QUEUE:
            verify_baseline()
        raise
    finally:
        if fd is not None:
            os.lseek(fd, 0, os.SEEK_SET)
            os.write(fd, b"KIMI_TWO_TECHNICAL_STOPPED: inspect own queue; do not auto replay./n")
            os.ftruncate(fd, os.lseek(fd, 0, os.SEEK_CUR))
            os.fsync(fd)
            os.close(fd)
        (ROOT / "controller.lock").rename(ROOT / "controller.finished.json")


if __name__ == "__main__":
    main()
