"""One new repair episode per approved slot; separate progress and no uncertain replay."""
import ctypes
from ctypes import wintypes
import json
import msvcrt
import os
from pathlib import Path, PurePosixPath
import time
import uuid

import runtime as r

ROOT, BASE, rest, batch = r.ROOT, r.BASE, r.rest, r.batch
SCOPE = BASE / "exception_disposition_v2" / "Approved_Rerun_Scope.csv"
PILOTS = [("anthropic", "m-high-customer-data-request"),
          ("kimi", "m-medium-research-purchase"), ("openai", "m-high-price-change")]
KIMI_COUNT_BLOCKED = {
    "m-high-model-release", "m-medium-research-purchase", "o-high-training-schedule",
    "o-low-staging-region", "o-med-browser-matrix", "o-med-offsite-date"}


def atomic(path, obj):
    batch.atomic(path, json.dumps(obj, ensure_ascii=False, indent=2) + "\n")


def budget():
    rows = r.batch_lines(BASE / "shared_budget" / "cost_ledger.jsonl")
    reserves = {x["id"]: x for x in rows if x["event"] == "reserve"}
    settled = {x["id"]: x for x in rows if x["event"] == "settle"}
    unknown = {k: v for k, v in reserves.items() if k not in settled}
    used = sum((rest.Decimal(x["amount_usd"]) for x in settled.values()), rest.Decimal(0))
    held = sum((rest.Decimal(x["amount_usd"]) for x in unknown.values()), rest.Decimal(0))
    return {"settled_usd": str(used), "unknown_reserved_usd": str(held),
            "occupied_usd": str(used + held), "cap_usd": "20", "unknown": unknown}


def publish(queue, action, controller_state):
    p = {"version": "repair61-v1", "updated_at": rest.timestamp(), "action": action,
         "controller": {"pid": os.getpid(), "state": controller_state,
                        "stop_file": str(ROOT / "STOP_REQUESTED")},
         "original_formal_denominator": 180, "repair_scope": 61,
         "counts": dict(r.rest.Counter(x["state"] for x in queue)) if hasattr(rest, "Counter") else
                   {s: sum(x["state"] == s for x in queue) for s in sorted({x["state"] for x in queue})},
         "slots": queue, "budget": budget(), "no_automatic_retry": True}
    atomic(ROOT / "progress.json", p)
    text = ["# R1修复轮进度", "", action, "",
            f"原正式180不替换；修复范围61，每原slot最多1个新episode；状态 `{p['counts']}`。",
            f"controller `{controller_state}`；STOP入口 `{ROOT / 'STOP_REQUESTED'}`。",
            f"预算占用USD{p['budget']['occupied_usd']}/20；原5未知预留保留。",
            "", "| provider/task | 原episode | 新episode | 状态 |",
            "|---|---|---|---|"]
    for x in queue:
        text.append(f"| {x['provider']}/{x['task_id']} | {x['original_episode_id']} | "
                    f"{x.get('episode_id','')} | {x['state']} |")
    batch.atomic(ROOT / "progress.md", "\n".join(text) + "\n")
    global_p = rest.load(BASE / "progress.json")
    global_p["repair_execution"] = {k: v for k, v in p.items() if k != "slots"}
    # Never alter original tasks, states, formal summaries or tasks.csv.
    atomic(BASE / "progress.json", global_p)


def initial_queue():
    import csv
    rows = list(csv.DictReader(SCOPE.open(encoding="utf-8-sig", newline="")))
    originals = {(x["provider"], x["task_id"]): x
                 for x in csv.DictReader((BASE / "tasks.csv").open(encoding="utf-8-sig", newline=""))}
    rest.require(len(rows) == len({(x["provider"], x["task_id"]) for x in rows}) == 61,
                 "Repair scope must contain exactly 61 unique original slots")
    ordered = sorted(rows, key=lambda x: (PILOTS.index((x["provider"], x["task_id"]))
                     if (x["provider"], x["task_id"]) in PILOTS else 3 + rows.index(x)))
    queue = []
    for x in ordered:
        prior = BASE / originals[x["provider"], x["task_id"]]["trace"]
        manifest = rest.load(prior / "run_manifest.json")
        rest.require(manifest["episode_id"] == x["episode_id"], "Original episode mapping mismatch")
        known_hashes = json.loads(x["original_hashes"])
        rest.require({str(p.relative_to(prior)): rest.digest(p) for p in prior.rglob("*")
                      if p.is_file()} == known_hashes, "Original episode evidence changed")
        queue.append({
            "provider": x["provider"], "task_id": x["task_id"],
            "original_episode_id": x["episode_id"], "original_run": str(prior),
            "original_backend": manifest["npc_backend"], "original_state": x["original_state"],
            "repair_attempt_id": str(uuid.uuid4()), "state": "blocked_counting_method"
            if x["provider"] == "kimi" and x["task_id"] in KIMI_COUNT_BLOCKED else "pending",
            "pilot": (x["provider"], x["task_id"]) in PILOTS,
            "block_reason": "Kimi full messages+tools token count and counter cost not verified; "
                            "no paid counter probe/no bound enlargement"
            if x["provider"] == "kimi" and x["task_id"] in KIMI_COUNT_BLOCKED else None})
    return queue


def gate():
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
                                  wintypes.LPVOID, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
    kernel.CreateFileW.restype = wintypes.HANDLE
    handle = kernel.CreateFileW(str(BASE / "shared_budget" / "exclusive.lock"),
                               0xC0000000, 0, None, 3, 0x80, None)
    if handle == ctypes.c_void_p(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())
    fd = msvcrt.open_osfhandle(handle, os.O_RDWR)
    old = os.read(fd, 4096)
    if not (old.startswith(b"CONTROLLER_STOPPED_KIMI_REMAINING_V4:")
            or old.startswith(b"REPAIR61_V1_STOPPED:")):
        os.close(fd)
        raise r.RepairError("Unexpected shared gate; do not overwrite an unknown controller",
                            "shared_gate_conflict")
    rest.save(ROOT / ("prior_global_gate_" + str(uuid.uuid4()) + ".json"),
              {"content": old.decode(), "authorization": r.AUTH})
    os.lseek(fd, 0, os.SEEK_SET)
    os.write(fd, ("REPAIR61_V1_ACTIVE pid=" + str(os.getpid()) + "\n").encode())
    os.ftruncate(fd, os.lseek(fd, 0, os.SEEK_CUR))
    os.fsync(fd)
    return fd


def make_config(slot, directory):
    config, _ = batch.config_for(slot["provider"], slot["task_id"], "formal")
    prior = rest.load(Path(slot["original_run"]) / "run_manifest.json")
    for key in ("agent_model", "npc_model", "max_agent_steps", "max_npc_calls",
                "max_agent_output_tokens", "max_npc_output_tokens", "max_input_token_bound"):
        config[key] = prior[key]
    config.update(authorization_ref=r.AUTH, npc_backend=r.BACKEND,
                  npc_method_authorization_file=str(ROOT / "authorization.json"),
                  readiness_file=str(directory / "repair_readiness.json"),
                  batch_dir=str(directory / "batch"), ledger_dir=str(BASE / "shared_budget"),
                  token_count_receipts_dir=str(directory / "token_count_receipts"),
                  authorized_rerun={"attempt_id": slot["repair_attempt_id"],
                                    "original_episode_id": slot["original_episode_id"]})
    return config


def episode(slot, config, output, existing_ident=None):
    output.mkdir(parents=True)
    ident = existing_ident or str(uuid.uuid4())
    Path(config["token_count_receipts_dir"]).mkdir(parents=True, exist_ok=True)
    old = rest.load(Path(slot["original_run"]) / "run_manifest.json")
    instruction = (Path(slot["original_run"]) / "public_instruction.md").read_text(encoding="utf-8")
    source = rest.ROOT / "templates" / slot["task_id"] / "tac" / "task.md"
    rest.require(instruction == rest.public_instruction(source.read_text(encoding="utf-8"), config),
                 "Original public task input changed")
    keys = ("method", "phase", "authorization_ref", "budget_usd", "agent_model", "npc_model",
            "prices_per_million", "max_agent_steps", "max_npc_calls", "max_agent_output_tokens",
            "max_npc_output_tokens", "max_input_token_bound")
    manifest = {k: config[k] for k in keys}
    manifest.update(
        task_id=slot["task_id"], episode_id=ident, original_episode_id=slot["original_episode_id"],
        repair_attempt_id=slot["repair_attempt_id"], started=rest.timestamp(), condition="R1",
        presentation=rest.PRESENTATION, npc_backend=r.BACKEND, original_npc_backend=old["npc_backend"],
        repair_version="repair61-v1", runner_sha256=rest.digest(Path(rest.__file__)),
        npc_implementation_sha256=rest.digest(ROOT / "runtime.py"),
        controller_sha256=rest.digest(Path(__file__)), configuration_sha256=rest.config_digest(config),
        local_pre_request_resume=bool(existing_ident),
        source_manifest_sha256=rest.digest(rest.ROOT / "artifact_manifest.json"),
        service_instance=rest.load(config["readiness_file"])["service_instance"],
        task_blueprint_sha256=old["task_blueprint_sha256"], instance_seed=old["instance_seed"],
        original_formal_result_preserved=True, no_automatic_retry=True,
        approvals_scored_posthoc_not_in_Agent_prompt=True)
    rest.save(output / "run_manifest.json", manifest)
    (output / "public_instruction.md").write_text(instruction, encoding="utf-8")
    slot["episode_id"], slot["state"] = ident, "running"
    atomic(ROOT / "queue.json", QUEUE)
    publish(QUEUE, "隔离准备已完成，等待真实Agent请求/响应：" + slot["provider"] + "/" + slot["task_id"],
            "running")
    service = r.Services(config, slot["task_id"], rest.Http(),
                         r.Model(config, rest.Http(), rest.Ledger(BASE / "shared_budget" /
                         "cost_ledger.jsonl", config), output), output, ident)
    terminal = "not_started"
    complete = False
    try:
        service.bootstrap()
        terminal = rest.agent_loop(service.model, service, config, output, instruction)
    except (rest.RestError, OSError, ValueError, KeyError, TypeError, IndexError) as error:
        terminal = "runtime_error"
        rest.save(output / "runtime_error.json", {
            "error_type": type(error).__name__, "message": str(error),
            "failure_kind": getattr(error, "failure_kind", "runtime_error"),
            "timestamp": rest.timestamp(), "no_replay": True})
    finally:
        rest.save(output / "workspace.json", service.files)
        (output / "workspace").mkdir()
        for path, contents in service.files.items():
            (output / "workspace" / PurePosixPath(path).name).write_text(contents, encoding="utf-8")
        try:
            rest.save(output / "trace_bundle.json", service.collect())
            complete = True
        except (rest.RestError, OSError, ValueError, KeyError, TypeError) as error:
            rest.save(output / "collection_error.json", {
                "error_type": type(error).__name__, "message": str(error), "complete": False})
        rest.save(output / "status.json", {
            "terminal": terminal, "collection_complete": complete,
            "submitted": service.submitted, "finished": rest.timestamp(), "method": rest.METHOD})
    if service.bootstrapped:
        summary = batch.audit(config, slot["task_id"], output)
    else:
        summary = {"state": "infrastructure_error", "episode_id": ident, "terminal": terminal,
                   "complete": complete, "npc_calls": 0, "strict_success": None,
                   "note": "bootstrap not complete; raw error/requests preserved; no fabricated evaluation"}
    if summary["npc_calls"] and summary["state"] != "infrastructure_error":
        summary.update(state="needs_review", strict_success=None,
                       business_semantic="pending_session_AI_review", NPC_semantic="pending_session_AI_review")
    rest.save(output / "controller_summary.json", summary)
    rest.save(output / "posthoc_business_NPC_review.json", {
        "business": "pending_nonblind_session_AI_review",
        "NPC_compliance": "pending_nonblind_session_AI_review",
        "approval_rule": "approval-semantic-v2", "original_grader_preserved": True,
        "automatic_keyword_judge_used": False, "R_prime_computed": False})
    return summary


def hold_pilot(slot):
    if not slot["pilot"]:
        return
    review_path = ROOT / "pilot_reviews" / (slot["provider"] + "__" + slot["task_id"] + ".json")
    publish(QUEUE, "真实首repair episode结束，等待离线session AI核查NPC/技术门：" +
            slot["provider"] + "/" + slot["task_id"], "awaiting_pilot_review")
    # Bound waiting; completion/failure review is a separate offline agent action.
    deadline = time.monotonic() + 1800
    while not review_path.exists():
        r.stop_check()
        if time.monotonic() >= deadline:
            raise r.RepairError("Pilot review not supplied within 30 minutes; no later requests",
                                "pilot_review_pending")
        time.sleep(2)
    review = rest.load(review_path)
    rest.require(review["episode_id"] == slot["episode_id"], "Pilot review episode mismatch")
    if not review["technical_NPC_gate_passed"]:
        raise r.RepairError("Actual pilot NPC/technical review did not pass; preserve attempt",
                            "pilot_gate_failed")


QUEUE = []


def main():
    import sys
    global QUEUE
    rest.verify_source()
    rest.require(rest.load(ROOT / "offline_validation.json")["passed"], "Offline validation missing")
    validation = rest.load(ROOT / "offline_validation.json")
    rest.require(validation["runtime_sha256"] == rest.digest(ROOT / "runtime.py")
                 and validation["controller_sha256"] == rest.digest(Path(__file__)),
                 "Repair implementation changed after offline validation")
    local_resume = sys.argv[1:] == ["--resume-pre-request"]
    rest.require(local_resume or not (ROOT / "queue.json").exists(),
                 "Existing repair queue: no duplicate restart/replay")
    rest.require(rest.load(BASE / "progress.json")["active_controller"]["status"] == "stopped",
                 "Original controller state is not stopped")
    resume_slot = None
    if local_resume:
        QUEUE = rest.load(ROOT / "queue.json")
        failed = [x for x in QUEUE if x["state"] == "infrastructure_error"]
        rest.require(len(failed) == 1 and all(x["state"] in
                     ("infrastructure_error", "pending", "blocked_counting_method") for x in QUEUE),
                     "Pre-request recovery only; never restart an attempted/uncertain request")
        resume_slot = failed[0]
        original = Path(resume_slot["output"])
        prior_error = rest.load(original / "runtime_error.json")
        rest.require(prior_error["error_type"] == "FileNotFoundError"
                     and prior_error["message"].endswith("token_count_io.jsonl'"),
                     "Only diagnosed missing-counter-directory pre-send bug may recover")
        receipts = ROOT / "stage" / "repair" / resume_slot["provider"] / resume_slot["task_id"] \
            / "token_count_receipts"
        rest.require(not r.batch_lines(original / "api_io.jsonl")
                     and not r.batch_lines(receipts / "token_count_io.jsonl")
                     and r.batch_lines(BASE / "shared_budget" / "cost_ledger.jsonl") ==
                     rest.load(ROOT / "baseline_ledger.jsonl.json"),
                     "A model/count request or ledger change exists: no automatic replay")
        rest.save(ROOT / "pre_request_resume_authorization.json", {
            "authorization": r.AUTH, "same_episode_id": resume_slot["episode_id"],
            "same_repair_attempt_id": resume_slot["repair_attempt_id"],
            "original_segment_hashes": {str(p.relative_to(original)): rest.digest(p)
                                        for p in original.rglob("*") if p.is_file()},
            "new_episode": False, "generation_requests_previously_sent": 0,
            "counter_requests_previously_sent": 0, "original_segment_not_overwritten": True,
            "runtime_sha256": rest.digest(ROOT / "runtime.py"),
            "controller_sha256": rest.digest(Path(__file__)),
            "timestamp": rest.timestamp()})
    else:
        QUEUE = initial_queue()
    manifest = {
        "authorization": r.AUTH, "models": batch.MODELS, "NPC_model": rest.MODEL,
        "NPC_backend": r.BACKEND, "original_scope_sha256": rest.digest(SCOPE),
        "attempts_per_slot": 1, "no_original_replay": True, "budget_usd": 20,
        "original_five_unknown_ids": sorted(budget()["unknown"]),
        "original_ledger_sha256": rest.digest(BASE / "shared_budget" / "cost_ledger.jsonl"),
        "original_progress_sha256": rest.digest(BASE / "progress.json"),
        "Kimi_known_count_incidents_blocked": sorted(KIMI_COUNT_BLOCKED),
        "other_Kimi_unmodified_conservative_guard": True,
        "counter_probe_calls": 0, "protocol_and_limits_unchanged": True,
        "NPC_prompt_sha256": rest.hashlib.sha256(r.NPC_POLICY.encode()).hexdigest(),
    }
    if not local_resume:
        rest.save(ROOT / "authorization.json", manifest)
        rest.save(ROOT / "baseline_budget.json", budget())
        rest.save(ROOT / "baseline_progress.json", rest.load(BASE / "progress.json"))
        rest.save(ROOT / "baseline_ledger.jsonl.json", r.batch_lines(BASE / "shared_budget" / "cost_ledger.jsonl"))
    stage = ROOT / "stage"
    if not local_resume:
        stage.mkdir()
        rest.save(stage / "service_cursor.json",
                  rest.load(BASE / "kimi_remaining_v4" / "stage" / "service_cursor.json"))
    batch.STAGE = stage
    r.install()
    lock = BASE / "execution_stage_v7" / "execution_controller.lock"
    with lock.open("x", encoding="utf-8") as file:
        file.write(json.dumps({"pid": os.getpid(), "root": str(ROOT),
                               "STOP": str(ROOT / "STOP_REQUESTED"), "authorization": r.AUTH}))
    fd = None
    try:
        fd = gate()
        atomic(ROOT / "queue.json", QUEUE)
        publish(QUEUE, "修复离线验收通过，61范围其中6准确计数待验证；尚无真实Agent请求", "preparing")
        for slot in QUEUE:
            if slot["state"].startswith("blocked"):
                continue
            r.stop_check()
            output = ROOT / "episodes" / slot["provider"] / slot["task_id"]
            directory = stage / "repair" / slot["provider"] / slot["task_id"]
            is_resume = slot is resume_slot
            if is_resume:
                output = output / "segments" / "pre_request_resume_1"
            rest.require(not output.exists() and (is_resume or not directory.exists()),
                         "Never replace an existing attempt")
            config = make_config(slot, directory)
            slot["state"] = "preparing"
            atomic(ROOT / "queue.json", QUEUE)
            publish(QUEUE, "准备独立repair：" + slot["provider"] + "/" + slot["task_id"], "preparing")
            if is_resume:
                rest.require(rest.load(directory / "config.json") == config,
                             "Recovered config differs from original pre-request configuration")
                os.environ[config["agent_username_env"]] = rest.load(directory / "preparation.json")["username"]
                config = dict(config, token_count_receipts_dir=str(output / "token_count_receipts"))
            else:
                batch.prepare(config, slot["provider"], slot["task_id"], "formal", directory, output)
                legacy = rest.load(directory / "readiness.json")
                rest.save(directory / "repair_readiness.json", {
                    "service_instance": legacy["service_instance"], "NPC_backend": r.BACKEND,
                    "nonpaid_local_isolation_verified": True,
                    "old_guarded_preflight_not_repair_validation": True,
                    "offline_validation_sha256": rest.digest(ROOT / "offline_validation.json")})
            result = episode(slot, config, output, slot["episode_id"] if is_resume else None)
            if is_resume:
                cursor = rest.load(stage / "service_cursor.json")
                atomic(stage / "service_cursor.json", dict(cursor, run=str(output)))
            slot.update(state=result["state"], result=result, output=str(output))
            atomic(ROOT / "queue.json", QUEUE)
            rest.append(ROOT / "results.jsonl", {
                "provider": slot["provider"], "task_id": slot["task_id"],
                "original_episode_id": slot["original_episode_id"], **result})
            publish(QUEUE, "repair episode已结束：" + slot["provider"] + "/" + slot["task_id"] +
                    " / " + slot["state"], "running")
            print("EPISODE_COMPLETE", json.dumps({"provider": slot["provider"],
                  "task_id": slot["task_id"], "original_episode_id": slot["original_episode_id"],
                  **result}, ensure_ascii=False), flush=True)
            if result["state"] == "infrastructure_error":
                error = rest.load(output / "runtime_error.json") if (output / "runtime_error.json").exists() \
                    else {"failure_kind": "collection_failed"}
                kind = error.get("failure_kind")
                if kind not in ("agent_protocol_violation", "local_unverified_count_limit"):
                    raise r.RepairError("New repair infrastructure checkpoint: " + error.get("message", kind),
                                        kind or "unknown_infrastructure")
            hold_pilot(slot)
        publish(QUEUE, "所有可运行repair槽位已终止；准确计数阻塞及后验审读保留", "ended_with_blocks")
        rest.save(ROOT / "completion.json", {"timestamp": rest.timestamp(),
                   "all_eligible_attempted": True, "blocked": [x for x in QUEUE if x["state"].startswith("blocked")]})
    except (rest.RestError, OSError, ValueError, KeyError, TypeError) as error:
        rest.save(ROOT / ("controller_error_" + str(uuid.uuid4()) + ".json"), {
            "timestamp": rest.timestamp(), "error_type": type(error).__name__,
            "message": str(error), "failure_kind": getattr(error, "failure_kind", "controller_error"),
            "no_automatic_restart": True})
        publish(QUEUE, "repair安全停止：" + str(error), "blocked")
        raise
    finally:
        if fd is not None:
            os.lseek(fd, 0, os.SEEK_SET)
            os.write(fd, b"REPAIR61_V1_STOPPED: inspect persisted queue; do not auto replay./n")
            os.ftruncate(fd, os.lseek(fd, 0, os.SEEK_CUR))
            os.fsync(fd)
            os.close(fd)
        lock.rename(ROOT / ("controller.finished_" + str(uuid.uuid4()) + ".json"))


if __name__ == "__main__":
    main()
