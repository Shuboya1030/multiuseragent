"""Authorized single-controller continuation; frozen Agent loop and natural NPC v5."""
import argparse
import ctypes
from ctypes import wintypes
import json
import msvcrt
import os
from pathlib import Path, PurePosixPath
import sys
import time
import uuid

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import natural_npc_comparison as natural
batch, rest = natural.batch, natural.rest
ROOT = BASE / "natural_v5_resumption_v2"
AUTH = "assignment:741f367f-a37b-48de-a57d-1e7bbe84ade4:call_lvONawgMkJS2QimT71ux2aLO"
REPAIRS = ("m-high-incident-postmortem", "m-high-model-release")
ENABLED = ("openai", "anthropic")


def save_queue(queue):
    batch.atomic(ROOT / "queue.json", json.dumps(queue, ensure_ascii=False, indent=2) + "\n")


def archive(path):
    return {str(p.relative_to(path)): rest.digest(p) for p in path.rglob("*") if p.is_file()}


def plan(progress, order):
    rest.require(not any(r["state"] == "running" for r in progress["tasks"]),
                 "Unfinished episode: inspect before any resumption")
    rows = {(r["provider"], r["task_id"]): r for r in progress["tasks"]}
    selected = [s for s in order if s["provider"] in ENABLED
                and rows[s["provider"], s["task_id"]]["state"] in ("pending", "blocked")]
    rest.require(len(selected) == len({(s["provider"], s["task_id"]) for s in selected}),
                 "Duplicate formal slot")
    for s in selected:
        rest.require(not batch.output_path(s["provider"], s["task_id"], "formal").exists(),
                     "Unrun slot already has an output; no replay")
    repairs = [dict(kind="diagnostic", provider="anthropic", task_id=t,
                    model=batch.MODELS["anthropic"], state="pending") for t in REPAIRS]
    return repairs + [dict(s, kind="formal", state="pending") for s in selected]


def stop_check():
    p = rest.load(BASE / "progress.json")
    rest.require(not p.get("execution_paused_by_user") and not (ROOT / "STOP_REQUESTED").exists(),
                 "User pause requested: no next paid request")


class Model(rest.OpenAI):
    def complete(self, role, messages, tools=None):
        stop_check()
        result = super().complete(role, messages, tools)
        if role == "agent" and not (self.output / "first_actual_agent_request.json").exists():
            first = next(json.loads(l) for l in (self.output / "api_io.jsonl").read_text(
                encoding="utf-8").splitlines() if json.loads(l)["stage"] == "request"
                and json.loads(l)["role"] == "agent")
            receipt = dict(task_id=self.output.name,
                episode_id=rest.load(self.output / "run_manifest.json")["episode_id"],
                timestamp=first["timestamp"], call_id=first["call_id"],
                model=self.config["agent_model"], npc_backend=natural.BACKEND,
                request_received_response=True)
            rest.save(self.output / "first_actual_agent_request.json", receipt)
            rest.append(ROOT / "actual_agent_starts.jsonl", receipt)
            batch.progress_update("已确认真实Agent请求及响应：" + self.config["agent_model"] + "/" +
                                  self.output.name + "；NPC自然语义v5，非启动准备。",
                                  "formal" if self.config["phase"] == "full" else "diagnostic")
            print("FIRST_ACTUAL_AGENT_REQUEST", json.dumps(receipt), flush=True)
        return result


def validate_scope(config, task):
    check = dict(config, npc_backend="controlled_rest_roleplay", phase="full")
    rest.validate(check, task, live=False)
    rest.require(config["npc_backend"] == natural.BACKEND and config["npc_model"] == rest.MODEL
                 and config["agent_model"] in (batch.MODELS[p] for p in ENABLED),
                 "Unapproved model/backend")
    rest.require(config["allow_paid_calls"] is True and rest.Decimal(str(config["budget_usd"])) == 20
                 and Path(config["ledger_dir"]).resolve() == (BASE / "shared_budget").resolve(),
                 "Wrong cumulative budget or paid authorization")
    rest.require(not Path(config["batch_dir"]).resolve().is_relative_to(rest.ROOT),
                 "Private state inside task source")
    required = [config[k] for k in ("agent_password_env", "owncloud_username_env",
                                   "owncloud_password_env", "openai_key_env")]
    if config["agent_model"] == "claude-haiku-5-5":
        required.append("ANTHROPIC_API_KEY")
    for account in config["npc_accounts"].values():
        required.extend((account["username_env"], account["password_env"]))
    rest.require(all(os.environ.get(k) for k in required), "Required credentials absent")
    rest.verify_source()
    rest.Ledger(BASE / "shared_budget" / "cost_ledger.jsonl", config)


def episode(config, task, output, parent=None):
    output.mkdir()
    ident = str(uuid.uuid4())
    instruction_path = rest.ROOT / "templates" / task / "tac" / "task.md"
    instruction = rest.public_instruction(instruction_path.read_text(encoding="utf-8"), config)
    keys = ("method", "phase", "authorization_ref", "budget_usd", "agent_model", "npc_model",
            "prices_per_million", "max_agent_steps", "max_npc_calls", "max_agent_output_tokens",
            "max_npc_output_tokens", "max_input_token_bound")
    manifest = {k: config[k] for k in keys}
    if parent:
        prior = rest.load(parent / "run_manifest.json")
        rest.require(instruction == (parent / "public_instruction.md").read_text(encoding="utf-8"),
                     "Repair task input changed")
        rest.require(all(config[k] == prior[k] for k in keys if k.startswith("max_") or k.endswith("_model")),
                     "Repair Agent model or limits changed")
        manifest["parent_episode_id"] = prior["episode_id"]
        manifest["original_formal_episode_id"] = prior["parent_episode_id"]
    manifest.update(task_id=task, episode_id=ident, condition="R1", presentation=rest.PRESENTATION,
        started=rest.timestamp(), npc_backend=natural.BACKEND, resume_authorization_ref=AUTH,
        source_manifest_sha256=rest.digest(rest.ROOT / "artifact_manifest.json"),
        configuration_sha256=rest.config_digest(config), runner_sha256=rest.digest(Path(rest.__file__)),
        npc_implementation_sha256=rest.digest(BASE / "natural_npc_comparison.py"),
        controller_sha256=rest.digest(Path(__file__)),
        service_instance=rest.load(config["readiness_file"])["service_instance"],
        instance_seed=rest.load(rest.ROOT / "templates" / task / "blueprint.json")["instance_seed"],
        task_blueprint_sha256=rest.digest(rest.ROOT / "templates" / task / "blueprint.json"),
        public_instruction_sha256=rest.digest(instruction_path),
        rendered_public_instruction_sha256=rest.hashlib.sha256(instruction.encode()).hexdigest(),
        diagnostic_separate_from_formal=bool(parent), no_automatic_retry=True)
    rest.save(output / "run_manifest.json", manifest)
    with (output / "public_instruction.md").open("x", encoding="utf-8") as file:
        file.write(instruction)
    ledger = rest.Ledger(BASE / "shared_budget" / "cost_ledger.jsonl", config)
    http = rest.Http()
    service = natural.NaturalServices(config, task, http, Model(config, http, ledger, output), output, ident)
    terminal, collection = "not_started", False
    try:
        service.bootstrap()
        terminal = rest.agent_loop(service.model, service, config, output, instruction)
    except (rest.RestError, KeyError, ValueError, TypeError, IndexError, OSError, rest.ET.ParseError) as error:
        terminal = "runtime_error"
        rest.save(output / "runtime_error.json", dict(error_type=type(error).__name__, message=str(error),
            failure_kind=getattr(error, "failure_kind", "runtime_error"), timestamp=rest.timestamp()))
    finally:
        rest.save(output / "workspace.json", service.files)
        (output / "workspace").mkdir()
        for path, content in service.files.items():
            with (output / "workspace" / PurePosixPath(path).name).open("x", encoding="utf-8") as file:
                file.write(content)
        try:
            rest.save(output / "trace_bundle.json", service.collect())
            collection = True
        except (rest.RestError, KeyError, ValueError, TypeError, IndexError, OSError) as error:
            rest.save(output / "collection_error.json",
                      dict(error_type=type(error).__name__, message=str(error), complete=False))
        rest.save(output / "status.json", dict(terminal=terminal, collection_complete=collection,
            submitted=service.submitted, finished=rest.timestamp(), method=rest.METHOD))
    summary = batch.audit(config, task, output)
    if summary["npc_calls"] and summary["state"] != "infrastructure_error":
        summary = dict(summary, state="needs_review", strict_success=None,
            semantic_review_status="pending_nonblinded_AI_review",
            raw_grader_result_retained=True,
            note="Natural NPC evidence and environment require semantic review; not an Agent failure.")
    rest.save(output / "controller_summary.json", summary)
    return summary


def hold_gate():
    gate = BASE / "shared_budget" / "exclusive.lock"
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
                                  wintypes.LPVOID, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
    kernel.CreateFileW.restype = wintypes.HANDLE
    handle = kernel.CreateFileW(str(gate), 0xC0000000, 0, None, 3, 0x80, None)
    if handle == ctypes.c_void_p(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())
    fd = msvcrt.open_osfhandle(handle, os.O_RDWR)
    original = os.read(fd, 4096)
    prior = BASE / "natural_v5_resumption_v1"
    startup_only = (
        original.startswith(b"CONTROLLER_STOPPED_NATURAL_V5:") and
        (prior / "controller_error.json").exists() and
        rest.load(prior / "controller_error.json")["error_type"] == "FileExistsError" and
        not list(prior.rglob("api_io.jsonl")) and
        not (prior / "stage" / "diagnostic").exists() and
        rest.load(BASE / "progress.json").get("active_controller", {}).get("status") == "stopped"
    )
    if not original.startswith(b"USER_REQUESTED_PAUSE:") and not startup_only:
        os.close(fd)
        raise rest.RestError("Unexpected global gate: inspect rather than clearing it")
    rest.save(ROOT / "original_pause_gate.json", dict(content=original.decode(), authorization_ref=AUTH))
    os.lseek(fd, 0, os.SEEK_SET)
    os.write(fd, ("AUTHORIZED_NATURAL_V5_CONTROLLER: pid=" + str(os.getpid()) + "\n").encode())
    os.ftruncate(fd, os.lseek(fd, 0, os.SEEK_CUR))
    os.fsync(fd)
    return fd


def main(check_only=False):
    rest.verify_source()
    p = rest.load(BASE / "progress.json")
    frozen = rest.load(BASE / "execution_stage_v7" / "formal_schedule.json")
    queue = plan(p, frozen["order"])
    rest.require(len(queue) == 90, "Expected two repairs and 88 previously unrun formal slots")
    cursor = rest.load(BASE / "haiku_natural_npc_comparison_v1" / "stage" / "service_cursor.json")
    rest.require(rest.episode_status(Path(cursor["run"]))["collection_complete"], "Latest service export unsealed")
    for task in REPAIRS:
        prior = BASE / "haiku_natural_npc_comparison_v1" / "episodes" / task
        rest.require(rest.load(prior / "run_manifest.json")["npc_implementation_sha256"] ==
                     rest.digest(BASE / "natural_npc_comparison.py"), "NPC v5 implementation drift")
    if check_only:
        print(json.dumps(dict(queue_size=len(queue), formal=88, repairs=2, kimi=0,
            backend=natural.BACKEND, latest_cursor=cursor, api_calls=0)), flush=True)
        return
    for provider in ENABLED:
        config, _ = batch.config_for(provider, REPAIRS[0], "formal")
        validate_scope(dict(config, npc_backend=natural.BACKEND), REPAIRS[0])
    ROOT.mkdir()
    rest.save(ROOT / "authorization.json", dict(authorization_ref=AUTH,
        user_quote="ok你继续跑实验吧，这两个NPC环境异常的你也重新来一次",
        backend=natural.BACKEND, repairs=REPAIRS, repair_attempts_each=1,
        formal_unrun=88, kimi_remains_paused=True, budget_usd="20",
        evidence_review="Nonblinded session AI; original unreviewed output retained; no additional judge API",
        compatibility="New controller replaces legacy guarded readiness/pilot gate under explicit resume authorization; "
                      "no Agent loop/tool/task/scorer changes. Legacy preparation metadata is not v5 validation.",
        timestamp=rest.timestamp()))
    rest.save(ROOT / "progress_before.json", p)
    save_queue(queue)
    stage = ROOT / "stage"
    stage.mkdir()
    rest.save(stage / "service_cursor.json", cursor)
    batch.STAGE = stage
    lock = BASE / "execution_stage_v7" / "execution_controller.lock"
    with lock.open("x", encoding="utf-8") as file:
        file.write(json.dumps(dict(pid=os.getpid(), authorization_ref=AUTH, stop_file=str(ROOT / "STOP_REQUESTED"))))
    fd = None
    try:
        fd = hold_gate()
        waiter = BASE / "execution_stage_v7" / "continuation.lock"
        if waiter.exists():
            saved = rest.load(waiter)
            kernel = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
            kernel.OpenProcess.restype = wintypes.HANDLE
            handle = kernel.OpenProcess(0x1000, False, saved["pid"])
            if handle:
                kernel.CloseHandle.argtypes = [wintypes.HANDLE]
                kernel.CloseHandle(handle)
                raise rest.RestError("Old waiter PID exists; inspect identity before removing queue marker")
            rest.require(ctypes.get_last_error() == 87, "Cannot verify old waiter exit")
            waiter.rename(ROOT / "archived_inactive_waiter.json")
        p.update(execution_paused_by_user=False, active_npc_backend=natural.BACKEND,
            active_controller=dict(pid=os.getpid(), root=str(ROOT), stop_file=str(ROOT / "STOP_REQUESTED"),
                                   authorization_ref=AUTH, status="running"),
            phase="preparation", current_action="v5唯一执行链准备；两条隔离重试+88个未运行正式槽位，尚未确认真实Agent请求。")
        selected = {(s["provider"], s["task_id"]) for s in queue if s["kind"] == "formal"}
        for row in p["tasks"]:
            if (row["provider"], row["task_id"]) in selected:
                row.update(state="pending", note="User-authorized v5 continuation; initial formal attempt only.")
        for provider in ENABLED:
            p["provider_execution_status"][provider].update(status="authorized_natural_v5",
                npc_backend=natural.BACKEND)
        p["provider_execution_status"]["kimi"]["status"] = "paused_rpm_limit"
        batch.publish(p)
        disabled = set()
        for slot in queue:
            stop_check()
            provider, task = slot["provider"], slot["task_id"]
            if provider in disabled:
                slot.update(state="blocked", reason="Provider infrastructure checkpoint; no automatic replay")
                save_queue(queue)
                continue
            formal = slot["kind"] == "formal"
            if formal:
                time.sleep(65)
                stop_check()
            directory = stage / slot["kind"] / provider / task
            config, _ = batch.config_for(provider, task, "formal")
            config.update(npc_backend=natural.BACKEND, resume_authorization_ref=AUTH,
                npc_method_authorization_file=str(ROOT / "authorization.json"),
                phase="full" if formal else "diagnostic",
                readiness_file=str(directory / "v5_readiness.json"), batch_dir=str(directory / "batch"))
            parent = None if formal else BASE / "haiku_natural_npc_comparison_v1" / "episodes" / task
            hashes = archive(parent) if parent else None
            output = batch.output_path(provider, task, "formal") if formal else ROOT / "repair_episodes" / task
            if parent:
                config["authorized_rerun"] = dict(authorization_ref=AUTH, attempt_id="natural-v5-repair-once")
            validate_scope(config, task)
            slot.update(state="preparing", output=str(output), timestamp=rest.timestamp())
            save_queue(queue)
            batch.prepare(config, provider, task, "formal" if formal else "diagnostic", directory, output)
            (directory / "readiness.json").rename(directory / "legacy_metadata_not_v5_validation.json")
            legacy = rest.load(directory / "legacy_metadata_not_v5_validation.json")
            rest.validate_material_policy(config, legacy)
            rest.save(directory / "v5_readiness.json", dict(service_instance=legacy["service_instance"],
                authorization_ref=AUTH, npc_backend=natural.BACKEND,
                no_material_rereview=True, owned_services_and_packet_verified=True,
                npc_semantic_compliance="posthoc_review_required_not_claimed_prevalidated"))
            output.parent.mkdir(exist_ok=True, parents=True)
            slot["state"] = "running"
            save_queue(queue)
            if formal:
                batch.progress_update("v5正式任务准备完成，等待真实Agent请求：" + provider + "/" + task,
                                      "formal", provider, task, running=True)
                progress = rest.load(BASE / "progress.json")
                row = next(r for r in progress["tasks"] if r["provider"] == provider and r["task_id"] == task)
                row["note"] = "隔离服务已就绪；尚未确认Agent首请求。"
                batch.publish(progress)
            result = episode(config, task, output, parent)
            if parent:
                rest.require(archive(parent) == hashes, "Prior anomalous episode changed")
            slot.update(state=result["state"], episode_id=result["episode_id"], summary=result)
            save_queue(queue)
            rest.append(ROOT / "results.jsonl", dict(kind=slot["kind"], provider=provider, **result))
            if formal:
                batch.progress_update("v5正式完成，原始评分保留；NPC语义证据待审：" + provider + "/" + task,
                                      "formal", provider, task, summary=result)
            else:
                progress = rest.load(BASE / "progress.json")
                progress.setdefault("diagnostic_repairs", {})[task] = dict(
                    npc_backend=natural.BACKEND, output=str(output), **result)
                batch.publish(progress)
                batch.progress_update("一次性隔离诊断重试已结束：" + task + "；与正式分母分开。",
                                      "diagnostic")
            print("EPISODE_COMPLETE", json.dumps(dict(kind=slot["kind"], task_id=task,
                episode_id=result["episode_id"], state=result["state"], cost_usd=result["cost_usd"])), flush=True)
            if not result["complete"]:
                raise rest.RestError("Unsealed collection: stop before rotating shared channel")
            if result["state"] == "infrastructure_error" or result["unknown_usage_call_ids"]:
                rows = [json.loads(l) for l in (output / "api_io.jsonl").read_text(encoding="utf-8").splitlines()]
                requests = [r for r in rows if r["stage"] == "request"]
                error = rest.load(output / "runtime_error.json") if (output / "runtime_error.json").exists() else {}
                if not requests or requests[-1]["role"] == "npc" or "budget" in str(error).lower():
                    raise rest.RestError("Shared NPC/service/budget blocker; no next paid call")
                disabled.add(provider)
                progress = rest.load(BASE / "progress.json")
                progress["provider_execution_status"][provider]["status"] = "paused_infrastructure_checkpoint"
                for row in progress["tasks"]:
                    if row["provider"] == provider and row["state"] == "pending":
                        row.update(state="blocked", note="Provider infrastructure checkpoint; no automatic retry.")
                batch.publish(progress)
        rest.save(ROOT / "completion.json", dict(finished=rest.timestamp(),
            queue_counts={s: sum(r["state"] == s for r in queue) for s in {r["state"] for r in queue}},
            kimi_remains_paused=True, semantic_review_required=True))
        batch.progress_update("本轮唯一v5执行链已完成可运行队列；Kimi仍暂停，NPC语义证据/异常另列待审。",
                              "blocked")
    except (rest.RestError, OSError, KeyError, ValueError, TypeError) as error:
        rest.save(ROOT / "controller_error.json", dict(error_type=type(error).__name__,
            message=str(error), timestamp=rest.timestamp(), no_replay=True))
        batch.progress_update("v5执行链安全停止：" + str(error), "blocked")
        raise
    finally:
        if fd is not None:
            os.lseek(fd, 0, os.SEEK_SET)
            os.write(fd, b"CONTROLLER_STOPPED_NATURAL_V5: inspect durable queue; never replay automatically./n")
            os.ftruncate(fd, os.lseek(fd, 0, os.SEEK_CUR))
            os.fsync(fd)
            os.close(fd)
        lock.rename(ROOT / "controller.finished.json")
        progress = rest.load(BASE / "progress.json")
        if progress.get("active_controller", {}).get("pid") == os.getpid():
            progress["active_controller"]["status"] = "stopped"
            progress["active_controller"]["finished"] = rest.timestamp()
            batch.publish(progress)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    main(parser.parse_args().check)
