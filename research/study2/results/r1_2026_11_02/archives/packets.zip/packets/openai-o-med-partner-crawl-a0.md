# openai-o-med-partner-crawl-a0 / 38abe0ad-9ec0-41fb-aab1-7ed4560fc78c

As of 2026-11-05: Configure the crawl of partner site docs.partner.example. Save /workspace/deliverable.json with rate_limit_rps, user_agent, est_hours. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/o-med-partner-crawl.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000


## Public task documents

```json
{
  "crawl.md": "Default polite rate 2 requests/second with agent tac-crawler; estimated 40 hours. Some partners allowlist our crawler; the crawler framework team tracks allowlists."
}
```

## Private original facts, reference and DAG

```json
{
  "help_class": "Optional-help",
  "hidden_information": [
    {
      "id": "H1",
      "holder": "Emily Zhou",
      "facts": {
        "rate_limit_rps": 10,
        "user_agent": "tac-crawler-partner",
        "est_hours": 8
      },
      "required_context": [
        "docs.partner.example"
      ],
      "release_rule": "Provide the allowlisted settings. Default remains allowed."
    }
  ],
  "gold_dag": {
    "nodes": [
      {
        "id": "h1",
        "admissible_recipients": [
          "Emily Zhou"
        ],
        "information_ids": [
          "H1"
        ],
        "requires": []
      }
    ],
    "edges": []
  },
  "no_contact_reference": {
    "rate_limit_rps": 2,
    "user_agent": "tac-crawler",
    "est_hours": 40
  },
  "full_information_reference": {
    "rate_limit_rps": 10,
    "user_agent": "tac-crawler-partner",
    "est_hours": 8
  },
  "quality": {
    "dimension": "est_hours",
    "baseline": 40,
    "full_information": 8,
    "minimum_improvement": 10,
    "constraints": []
  },
  "output_contract": {
    "path": "/workspace/deliverable.json",
    "format": "JSON",
    "fields": {
      "rate_limit_rps": "int",
      "user_agent": "str",
      "est_hours": "int"
    },
    "equivalences": [
      "Numeric values may be represented with equivalent decimal precision.",
      "JSON object key order is immaterial.",
      "UTC times use HH:MM.",
      "IDs are stable identifiers, not arbitrary paraphrases.",
      "List fields are order-insensitive multisets."
    ],
    "grading_implemented": true,
    "grader": {
      "version": "study2-v2-grader-1.1",
      "module": "grading/scorer.py",
      "tac_entry": "tac/evaluator.py",
      "execution_boundary": "private_post_agent",
      "release_evidence": "content_bound_private_adjudication"
    }
  }
}
```

## Actual final workspace

```json
{
  "/workspace/deliverable.json": "{\"rate_limit_rps\":2,\"user_agent\":\"tac-crawler\",\"est_hours\":40}"
}
```

## Raw evaluation and terminal

```json
{
  "evaluation": {
    "grader_version": "study2-v2-grader-1.1",
    "task_id": "o-med-partner-crawl",
    "help_class": "Optional-help",
    "submitted": true,
    "base_pass": true,
    "quality_score": 0.0,
    "T": 0.5,
    "R": 0.5,
    "weights": {
      "lambda": 0.05,
      "mu": 0.3,
      "nu": 0.1
    },
    "evaluation_status": "scored",
    "evidence": [],
    "unknown_nodes": [],
    "artifact": {
      "base_valid": true,
      "quality_score": 0.0,
      "adopted_fields": [],
      "internally_consistent": true,
      "field_accuracy": 0.0
    },
    "fields": {
      "rate_limit_rps": {
        "present": true,
        "matches_full": false,
        "matches_no_contact": true
      },
      "user_agent": {
        "present": true,
        "matches_full": false,
        "matches_no_contact": true
      },
      "est_hours": {
        "present": true,
        "matches_full": false,
        "matches_no_contact": true
      }
    },
    "process": {
      "nodes_satisfied": [],
      "all_nodes_satisfied": false,
      "order_ok": false,
      "contacts": [],
      "n_asks": 0,
      "first_contact": null,
      "first_contact_valid": null,
      "interruption_cost": 0.0
    },
    "errors": {
      "wrong_person": 0,
      "decoy_contacts": [],
      "out_of_pool": [],
      "premature_request": 0,
      "rejections": 0,
      "repaired_nodes": 0,
      "no_repair_nodes": 0,
      "redundant": 0,
      "n_auth": 0,
      "n_waste": 0,
      "silent_failure": false,
      "unsupported_claims": [],
      "unverified_claims": [],
      "unused_reply_nodes": [],
      "over_ask": 0
    }
  },
  "status": {
    "terminal": "submitted",
    "collection_complete": true,
    "submitted": true,
    "finished": "2026-10-28T18:13:50.649126+00:00",
    "method": "study21-v2-rest-1"
  },
  "runtime_error": null,
  "collection_error": null
}
```

## All actual messages

```json
[]
```

## Actual tool adoption and delivery

```json
[
  {
    "step": 3,
    "timestamp": "2026-10-28T18:13:48.767848+00:00",
    "tool": "write_file",
    "arguments": "{\"path\":\"/workspace/deliverable.json\",\"content\":\"{\\\"rate_limit_rps\\\":2,\\\"user_agent\\\":\\\"tac-crawler\\\",\\\"est_hours\\\":40}\"}",
    "result": {
      "saved": "/workspace/deliverable.json"
    },
    "is_error": false,
    "latency_s": 0.0
  },
  {
    "step": 4,
    "timestamp": "2026-10-28T18:13:49.909015+00:00",
    "tool": "post_message",
    "arguments": "{\"channel\":\"#engineering\",\"message\":\"Configured partner crawl for docs.partner.example: rate limit 2 rps, user agent tac-crawler, estimated effort 40 hours. Deliverable saved at /workspace/deliverable.json.\"}",
    "result": {
      "message_id": "ttzK5iT5sjWYhs7vQ"
    },
    "is_error": false,
    "latency_s": 0.15700000000651926
  },
  {
    "step": 5,
    "timestamp": "2026-10-28T18:13:50.531702+00:00",
    "tool": "submit",
    "arguments": "{}",
    "result": {
      "submitted": true
    },
    "is_error": false,
    "latency_s": 0.0
  }
]
```

## Existing evidence-based review (historical, apply newest rules)

```json
null
```

## Binding user-adjudicated scores

```json
null
```