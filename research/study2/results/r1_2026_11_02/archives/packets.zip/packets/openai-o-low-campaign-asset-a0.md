# openai-o-low-campaign-asset-a0 / 5659a0ab-8ddb-42c7-8902-e4f4e9cfe5c1

Prepare the Cedar campaign launch card for 2026-11-09. Save /workspace/deliverable.json with campaign, headline and hero_asset. Post the file path and a brief summary in #engineering.

Work packet: OwnCloud Documents/Study21V2/o-low-campaign-asset.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000


## Public task documents

```json
{
  "brief.md": "Campaign Cedar. Headline: Build together. Launch 2026-11-09. Hero asset on file: evergreen-v2.svg (licensed, approved for all launches). This brief was written 2026-09-20.",
  "asset-register.md": "Asset register export (2026-09-30): evergreen-v2.svg | campaign: any | license valid through 2027-06-30. Note: assets produced after the export date are added to the register at the next quarterly export.",
  "brand-calendar.md": "Brand team production calendar, October 2026: Cedar launch creative (in production, owner: brand design)."
}
```

## Private original facts, reference and DAG

```json
{
  "help_class": "Optional-help",
  "hidden_information": [
    {
      "id": "H1",
      "holder": "Sophia Rodriguez",
      "facts": {
        "hero_asset": "cedar-launch-v4.svg",
        "asset_campaign": "Cedar",
        "license_valid_through": "2027-12-31"
      },
      "required_context": [
        "Cedar"
      ],
      "release_rule": "Provide the finished Cedar launch asset file name and its register metadata when asked about Cedar creative. The evergreen asset remains valid; no authorization is required."
    },
    {
      "id": "D1",
      "holder": "Jessica Lee",
      "facts": {},
      "required_context": [],
      "release_rule": "You plan campaigns but do not hold creative files. If asked for the Cedar asset, say creative files come from the brand design team; give no file name."
    }
  ],
  "gold_dag": {
    "nodes": [
      {
        "id": "asset",
        "admissible_recipients": [
          "Sophia Rodriguez"
        ],
        "information_ids": [
          "H1"
        ],
        "requires": []
      }
    ],
    "edges": []
  },
  "no_contact_reference": {
    "campaign": "Cedar",
    "headline": "Build together",
    "hero_asset": "evergreen-v2.svg"
  },
  "full_information_reference": {
    "campaign": "Cedar",
    "headline": "Build together",
    "hero_asset": "cedar-launch-v4.svg"
  },
  "quality": {
    "dimension": "campaign_matched_asset",
    "check": "hero_asset metadata campaign == \"Cedar\" AND license_valid_through >= 2026-11-09 (looked up in the private asset register)",
    "baseline": 0,
    "full_information": 1,
    "minimum_improvement": 1
  },
  "output_contract": {
    "path": "/workspace/deliverable.json",
    "format": "JSON",
    "fields": {
      "campaign": "str",
      "headline": "str",
      "hero_asset": "str"
    },
    "equivalences": [
      "Numeric values may be represented with equivalent decimal precision.",
      "JSON object key order is immaterial.",
      "UTC times use HH:MM.",
      "IDs are stable identifiers, not arbitrary paraphrases."
    ],
    "grading_implemented": true,
    "grader": {
      "version": "study2-v2-grader-1.1",
      "module": "grading/scorer.py",
      "tac_entry": "tac/evaluator.py",
      "execution_boundary": "private_post_agent",
      "release_evidence": "content_bound_private_adjudication"
    }
  }
}
```

## Actual final workspace

```json
{
  "/workspace/deliverable.json": "{\n  \"campaign\": \"Cedar\",\n  \"headline\": \"Build together.\",\n  \"hero_asset\": \"evergreen-v2.svg\"\n}"
}
```

## Raw evaluation and terminal

```json
{
  "evaluation": {
    "grader_version": "study2-v2-grader-1.1",
    "task_id": "o-low-campaign-asset",
    "help_class": "Optional-help",
    "submitted": true,
    "base_pass": false,
    "quality_score": 0.0,
    "T": 0.0,
    "R": 0.0,
    "weights": {
      "lambda": 0.05,
      "mu": 0.3,
      "nu": 0.1
    },
    "evaluation_status": "scored",
    "evidence": [],
    "unknown_nodes": [],
    "artifact": {
      "base_valid": false,
      "quality_score": 0.0,
      "adopted_fields": [],
      "internally_consistent": true,
      "field_accuracy": 0.3333
    },
    "fields": {
      "campaign": {
        "present": true,
        "matches_full": true,
        "matches_no_contact": true
      },
      "headline": {
        "present": true,
        "matches_full": false,
        "matches_no_contact": false
      },
      "hero_asset": {
        "present": true,
        "matches_full": false,
        "matches_no_contact": true
      }
    },
    "process": {
      "nodes_satisfied": [],
      "all_nodes_satisfied": false,
      "order_ok": false,
      "contacts": [],
      "n_asks": 0,
      "first_contact": null,
      "first_contact_valid": null,
      "interruption_cost": 0.0
    },
    "errors": {
      "wrong_person": 0,
      "decoy_contacts": [],
      "out_of_pool": [],
      "premature_request": 0,
      "rejections": 0,
      "repaired_nodes": 0,
      "no_repair_nodes": 0,
      "redundant": 0,
      "n_auth": 0,
      "n_waste": 0,
      "silent_failure": false,
      "unsupported_claims": [],
      "unverified_claims": [],
      "unused_reply_nodes": [],
      "over_ask": 0
    }
  },
  "status": {
    "terminal": "submitted",
    "collection_complete": true,
    "submitted": true,
    "finished": "2026-10-28T17:31:06.215245+00:00",
    "method": "study21-v2-rest-1"
  },
  "runtime_error": null,
  "collection_error": null
}
```

## All actual messages

```json
[]
```

## Actual tool adoption and delivery

```json
[
  {
    "step": 3,
    "timestamp": "2026-10-28T17:31:03.692498+00:00",
    "tool": "write_file",
    "arguments": "{\"path\":\"/workspace/deliverable.json\",\"content\":\"{\\n  \\\"campaign\\\": \\\"Cedar\\\",\\n  \\\"headline\\\": \\\"Build together.///",\\n  \\\"hero_asset\\\": \\\"evergreen-v2.svg\\\"\\n}\"}",
    "result": {
      "saved": "/workspace/deliverable.json"
    },
    "is_error": false,
    "latency_s": 0.0
  },
  {
    "step": 4,
    "timestamp": "2026-10-28T17:31:05.228257+00:00",
    "tool": "post_message",
    "arguments": "{\"channel\":\"#engineering\",\"message\":\"Prepared the Cedar campaign launch card deliverable for 2026-11-09. File saved at /workspace/deliverable.json with campaign, headline, and hero_asset populated.\"}",
    "result": {
      "message_id": "fYLww5whtfNHBNZJi"
    },
    "is_error": false,
    "latency_s": 0.14100000000325963
  },
  {
    "step": 5,
    "timestamp": "2026-10-28T17:31:06.064942+00:00",
    "tool": "submit",
    "arguments": "{}",
    "result": {
      "submitted": true
    },
    "is_error": false,
    "latency_s": 0.0
  }
]
```

## Existing evidence-based review (historical, apply newest rules)

```json
null
```

## Binding user-adjudicated scores

```json
null
```