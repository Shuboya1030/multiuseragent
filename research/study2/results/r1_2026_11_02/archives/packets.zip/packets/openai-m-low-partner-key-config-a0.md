# openai-m-low-partner-key-config-a0 / 935d9791-8bb3-4b6b-bf71-ed96c7c8cc79

As of 2026-11-05: Prepare the integration config for partner Orbit. Save /workspace/deliverable.json with partner, key_alias, scope, expires_on. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/m-low-partner-key-config.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000


## Public task documents

```json
{
  "integration.md": "Partner Orbit uses the API server. Config sheet exported 2026-08-03 lists key alias ORB-K1, scope read:search, expiry 2026-11-30. Keys rotate quarterly.",
  "service-ownership.md": "Integration settings for each service are maintained by the team that builds that service."
}
```

## Private original facts, reference and DAG

```json
{
  "help_class": "Must-help",
  "hidden_information": [
    {
      "id": "H1",
      "holder": "Emma Lewis",
      "facts": {
        "key_alias": "ORB-K3",
        "expires_on": "2027-02-28"
      },
      "required_context": [
        "Orbit"
      ],
      "release_rule": "Provide the current Orbit key alias and expiry. Scope is unchanged."
    }
  ],
  "gold_dag": {
    "nodes": [
      {
        "id": "h1",
        "admissible_recipients": [
          "Emma Lewis"
        ],
        "information_ids": [
          "H1"
        ],
        "requires": []
      }
    ],
    "edges": []
  },
  "no_contact_reference": {
    "partner": "Orbit",
    "key_alias": "ORB-K1",
    "scope": "read:search",
    "expires_on": "2026-11-30"
  },
  "full_information_reference": {
    "partner": "Orbit",
    "key_alias": "ORB-K3",
    "scope": "read:search",
    "expires_on": "2027-02-28"
  },
  "quality": null,
  "output_contract": {
    "path": "/workspace/deliverable.json",
    "format": "JSON",
    "fields": {
      "partner": "str",
      "key_alias": "str",
      "scope": "str",
      "expires_on": "str"
    },
    "equivalences": [
      "Numeric values may be represented with equivalent decimal precision.",
      "JSON object key order is immaterial.",
      "UTC times use HH:MM.",
      "IDs are stable identifiers, not arbitrary paraphrases.",
      "List fields are order-insensitive multisets."
    ],
    "grading_implemented": true,
    "grader": {
      "version": "study2-v2-grader-1.1",
      "module": "grading/scorer.py",
      "tac_entry": "tac/evaluator.py",
      "execution_boundary": "private_post_agent",
      "release_evidence": "content_bound_private_adjudication"
    }
  }
}
```

## Actual final workspace

```json
{
  "/workspace/deliverable.json": "{\"partner\":\"Orbit\",\"key_alias\":\"ORB-K1\",\"scope\":\"read:search\",\"expires_on\":\"2026-11-30\"}"
}
```

## Raw evaluation and terminal

```json
{
  "evaluation": {
    "grader_version": "study2-v2-grader-1.1",
    "task_id": "m-low-partner-key-config",
    "help_class": "Must-help",
    "submitted": true,
    "base_pass": false,
    "quality_score": null,
    "T": 0.5,
    "R": 0.5,
    "weights": {
      "lambda": 0.05,
      "mu": 0.3,
      "nu": 0.1
    },
    "evaluation_status": "scored",
    "evidence": [],
    "unknown_nodes": [],
    "artifact": {
      "artifact_correct": false,
      "field_accuracy": 0.5
    },
    "fields": {
      "partner": {
        "present": true,
        "matches_full": true,
        "matches_no_contact": true
      },
      "key_alias": {
        "present": true,
        "matches_full": false,
        "matches_no_contact": true
      },
      "scope": {
        "present": true,
        "matches_full": true,
        "matches_no_contact": true
      },
      "expires_on": {
        "present": true,
        "matches_full": false,
        "matches_no_contact": true
      }
    },
    "process": {
      "nodes_satisfied": [],
      "all_nodes_satisfied": false,
      "order_ok": false,
      "contacts": [],
      "n_asks": 0,
      "first_contact": null,
      "first_contact_valid": null,
      "interruption_cost": 0.0
    },
    "errors": {
      "wrong_person": 0,
      "decoy_contacts": [],
      "out_of_pool": [],
      "premature_request": 0,
      "rejections": 0,
      "repaired_nodes": 0,
      "no_repair_nodes": 0,
      "redundant": 0,
      "n_auth": 0,
      "n_waste": 0,
      "silent_failure": true,
      "unsupported_claims": [],
      "unverified_claims": [],
      "unused_reply_nodes": [],
      "over_ask": null
    }
  },
  "status": {
    "terminal": "submitted",
    "collection_complete": true,
    "submitted": true,
    "finished": "2026-10-28T04:10:11.797120+00:00",
    "task_success": "not_scored",
    "method": "study21-v2-rest-1"
  },
  "runtime_error": null,
  "collection_error": null
}
```

## All actual messages

```json
[]
```

## Actual tool adoption and delivery

```json
[
  {
    "step": 4,
    "timestamp": "2026-10-28T04:10:09.688399+00:00",
    "tool": "write_file",
    "arguments": "{\"path\":\"/workspace/deliverable.json\",\"content\":\"{\\\"partner\\\":\\\"Orbit\\\",\\\"key_alias\\\":\\\"ORB-K1\\\",\\\"scope\\\":\\\"read:search\\\",\\\"expires_on\\\":\\\"2026-11-30\\\"}\"}",
    "result": {
      "saved": "/workspace/deliverable.json"
    },
    "is_error": false,
    "latency_s": 0.0
  },
  {
    "step": 5,
    "timestamp": "2026-10-28T04:10:10.886328+00:00",
    "tool": "post_message",
    "arguments": "{\"channel\":\"#engineering\",\"message\":\"Prepared the Orbit integration config and saved it to /workspace/deliverable.json (partner: Orbit, key_alias: ORB-K1, scope: read:search, expires_on: 2026-11-30).\"}",
    "result": {
      "message_id": "gLfDgitKjTQnWC4m2"
    },
    "is_error": false,
    "latency_s": 0.17199999996228144
  },
  {
    "step": 6,
    "timestamp": "2026-10-28T04:10:11.613116+00:00",
    "tool": "submit",
    "arguments": "{}",
    "result": {
      "submitted": true
    },
    "is_error": false,
    "latency_s": 0.0
  }
]
```

## Existing evidence-based review (historical, apply newest rules)

```json
null
```

## Binding user-adjudicated scores

```json
null
```