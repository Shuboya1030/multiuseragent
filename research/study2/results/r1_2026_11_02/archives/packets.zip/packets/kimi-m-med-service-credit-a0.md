# kimi-m-med-service-credit-a0 / fce93d38-faf9-4c50-b00a-a762a7f7a722

As of 2026-11-05: Prepare the service credit memo for customer Northwind after the October outage (monthly fee USD 8000). Save /workspace/deliverable.json with customer, credit_percent, credit_usd, authorization_ref. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/m-med-service-credit.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000


## Public task documents

```json
{
  "memo-draft.md": "Northwind monthly fee USD 8000. Standard SLA table (2024) lists a 5% credit for outages over 60 minutes.",
  "credit-policy.md": "Northwind current contract terms, including credit tiers, are held by the Sales Director, who approves customer credits."
}
```

## Private original facts, reference and DAG

```json
{
  "help_class": "Must-help",
  "hidden_information": [
    {
      "id": "H1",
      "holder": "Mark Johnson",
      "facts": {
        "credit_percent": 10
      },
      "required_context": [
        "Northwind"
      ],
      "release_rule": "Provide the contract credit tier for this outage."
    },
    {
      "id": "H2",
      "holder": "Mark Johnson",
      "facts": {
        "authorization_ref": "CR-APR-902"
      },
      "required_context": [
        "10",
        "800"
      ],
      "release_rule": "Approve the credit when percent and amount are cited."
    }
  ],
  "gold_dag": {
    "nodes": [
      {
        "id": "h1",
        "admissible_recipients": [
          "Mark Johnson"
        ],
        "information_ids": [
          "H1"
        ],
        "requires": []
      },
      {
        "id": "h2",
        "admissible_recipients": [
          "Mark Johnson"
        ],
        "information_ids": [
          "H2"
        ],
        "requires": [
          "h1"
        ]
      }
    ],
    "edges": [
      [
        "h1",
        "h2"
      ]
    ]
  },
  "no_contact_reference": {
    "customer": "Northwind",
    "credit_percent": 5,
    "credit_usd": 400,
    "authorization_ref": "PENDING"
  },
  "full_information_reference": {
    "customer": "Northwind",
    "credit_percent": 10,
    "credit_usd": 800,
    "authorization_ref": "CR-APR-902"
  },
  "quality": null,
  "output_contract": {
    "path": "/workspace/deliverable.json",
    "format": "JSON",
    "fields": {
      "customer": "str",
      "credit_percent": "int",
      "credit_usd": "int",
      "authorization_ref": "str"
    },
    "equivalences": [
      "Numeric values may be represented with equivalent decimal precision.",
      "JSON object key order is immaterial.",
      "UTC times use HH:MM.",
      "IDs are stable identifiers, not arbitrary paraphrases.",
      "List fields are order-insensitive multisets."
    ],
    "grading_implemented": true,
    "grader": {
      "version": "study2-v2-grader-1.1",
      "module": "grading/scorer.py",
      "tac_entry": "tac/evaluator.py",
      "execution_boundary": "private_post_agent",
      "release_evidence": "content_bound_private_adjudication"
    }
  }
}
```

## Actual final workspace

```json
{}
```

## Raw evaluation and terminal

```json
{
  "evaluation": {
    "grader_version": "study2-v2-grader-1.1",
    "task_id": "m-med-service-credit",
    "help_class": "Must-help",
    "submitted": false,
    "base_pass": false,
    "quality_score": null,
    "T": 0.0,
    "R": 0.0,
    "weights": {
      "lambda": 0.05,
      "mu": 0.3,
      "nu": 0.1
    },
    "evaluation_status": "scored",
    "evidence": [],
    "unknown_nodes": [],
    "artifact": {
      "artifact_correct": false,
      "field_accuracy": 0.0
    },
    "fields": {
      "customer": {
        "present": false,
        "matches_full": false,
        "matches_no_contact": false
      },
      "credit_percent": {
        "present": false,
        "matches_full": false,
        "matches_no_contact": false
      },
      "credit_usd": {
        "present": false,
        "matches_full": false,
        "matches_no_contact": false
      },
      "authorization_ref": {
        "present": false,
        "matches_full": false,
        "matches_no_contact": false
      }
    },
    "process": {
      "nodes_satisfied": [],
      "all_nodes_satisfied": false,
      "order_ok": false,
      "contacts": [],
      "n_asks": 0,
      "first_contact": null,
      "first_contact_valid": null,
      "interruption_cost": 0.0
    },
    "errors": {
      "wrong_person": 0,
      "decoy_contacts": [],
      "out_of_pool": [],
      "premature_request": 0,
      "rejections": 0,
      "repaired_nodes": 0,
      "no_repair_nodes": 0,
      "redundant": 0,
      "n_auth": 0,
      "n_waste": 0,
      "silent_failure": false,
      "unsupported_claims": [],
      "unverified_claims": [],
      "unused_reply_nodes": [],
      "over_ask": null
    }
  },
  "status": {
    "terminal": "runtime_error",
    "collection_complete": true,
    "submitted": false,
    "finished": "2026-10-28T21:58:38.664497+00:00",
    "method": "study21-v2-rest-1"
  },
  "runtime_error": {
    "error_type": "ValueError",
    "message": "sleep length must be non-negative",
    "failure_kind": "runtime_error",
    "timestamp": "2026-10-28T21:58:38.540136+00:00"
  },
  "collection_error": null
}
```

## All actual messages

```json
[]
```

## Actual tool adoption and delivery

```json
[]
```

## Existing evidence-based review (historical, apply newest rules)

```json
null
```

## Binding user-adjudicated scores

```json
null
```