# kimi-m-high-portal-launch-a1 / f9237fd6-5020-4753-a5f8-3468e1fe61cf

As of 2026-11-05: Prepare the go/no-go record for launching the API v3 documentation portal. Save /workspace/deliverable.json with docs_build_id, qa_signoff, launch_date, authorization_ref. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/m-high-portal-launch.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000


## Public task documents

```json
{
  "plan.md": "Portal launch planned for 2026-11-12 with docs build DB-301.",
  "launch-policy.md": "Docs builds are produced by the documentation engineer. QA signs off against the current build. Launch approval comes from the product manager of the API portal.",
  "product-map.md": "API portal product decisions belong to the search product manager while the API product role is vacant.",
  "out-of-office.md": "Huang Jie away 2026-11-04 to 2026-11-20; product approvals delegated to Jessica Chen."
}
```

## Private original facts, reference and DAG

```json
{
  "help_class": "Must-help",
  "hidden_information": [
    {
      "id": "H1",
      "holder": "Priya Sharma",
      "facts": {
        "docs_build_id": "DB-318",
        "launch_date": "2026-11-17"
      },
      "required_context": [
        "API v3 portal"
      ],
      "release_rule": "Provide the current build and launch date."
    },
    {
      "id": "H2",
      "holder": "Liu Qiang",
      "facts": {
        "qa_signoff": "QA-DB318"
      },
      "required_context": [
        "DB-318"
      ],
      "release_rule": "Sign off only against DB-318."
    },
    {
      "id": "H3",
      "holder": "Jessica Chen",
      "facts": {
        "authorization_ref": "LCH-APR-3"
      },
      "required_context": [
        "QA-DB318",
        "2026-11-17"
      ],
      "release_rule": "As delegated product approver, approve only with QA sign-off and date cited."
    },
    {
      "id": "D1",
      "holder": "Huang Jie",
      "facts": {},
      "required_context": [],
      "release_rule": "You are away until 2026-11-20. Say product approvals are delegated to Jessica Chen; issue nothing."
    },
    {
      "id": "D2",
      "holder": "Emma Lewis",
      "facts": {},
      "required_context": [],
      "release_rule": "You run the API server, not the docs portal. If asked about launch approval, say product decides."
    }
  ],
  "gold_dag": {
    "nodes": [
      {
        "id": "h1",
        "admissible_recipients": [
          "Priya Sharma"
        ],
        "information_ids": [
          "H1"
        ],
        "requires": []
      },
      {
        "id": "h2",
        "admissible_recipients": [
          "Liu Qiang"
        ],
        "information_ids": [
          "H2"
        ],
        "requires": [
          "h1"
        ]
      },
      {
        "id": "h3",
        "admissible_recipients": [
          "Jessica Chen"
        ],
        "information_ids": [
          "H3"
        ],
        "requires": [
          "h2"
        ]
      }
    ],
    "edges": [
      [
        "h1",
        "h2"
      ],
      [
        "h2",
        "h3"
      ]
    ]
  },
  "no_contact_reference": {
    "docs_build_id": "DB-301",
    "qa_signoff": "PENDING",
    "launch_date": "2026-11-12",
    "authorization_ref": "PENDING"
  },
  "full_information_reference": {
    "docs_build_id": "DB-318",
    "qa_signoff": "QA-DB318",
    "launch_date": "2026-11-17",
    "authorization_ref": "LCH-APR-3"
  },
  "quality": null,
  "output_contract": {
    "path": "/workspace/deliverable.json",
    "format": "JSON",
    "fields": {
      "docs_build_id": "str",
      "qa_signoff": "str",
      "launch_date": "str",
      "authorization_ref": "str"
    },
    "equivalences": [
      "Numeric values may be represented with equivalent decimal precision.",
      "JSON object key order is immaterial.",
      "UTC times use HH:MM.",
      "IDs are stable identifiers, not arbitrary paraphrases.",
      "List fields are order-insensitive multisets."
    ],
    "grading_implemented": true,
    "grader": {
      "version": "study2-v2-grader-1.1",
      "module": "grading/scorer.py",
      "tac_entry": "tac/evaluator.py",
      "execution_boundary": "private_post_agent",
      "release_evidence": "content_bound_private_adjudication"
    }
  }
}
```

## Actual final workspace

```json
{
  "/workspace/deliverable.json": "{\n  \"docs_build_id\": \"DB-318\",\n  \"qa_signoff\": \"QA-DB318\",\n  \"launch_date\": \"2026-11-17\",\n  \"authorization_ref\": \"LCH-APR-3\"\n}\n"
}
```

## Raw evaluation and terminal

```json
{
  "evaluation": {
    "grader_version": "study2-v2-grader-1.1",
    "task_id": "m-high-portal-launch",
    "help_class": "Must-help",
    "submitted": true,
    "base_pass": null,
    "quality_score": null,
    "T": 1.0,
    "R": 0.75,
    "weights": {
      "lambda": 0.05,
      "mu": 0.3,
      "nu": 0.1
    },
    "evaluation_status": "needs_evidence_review",
    "evidence": [
      {
        "node_id": "h1",
        "message_id": "qu3kp97ecKturdXWZ",
        "request_id": "vDfYjFnMHAAuMvKKz",
        "status": "unknown",
        "reason": "natural_language_requires_private_review",
        "value_match": true,
        "context_match": false,
        "observed_refusal": false
      },
      {
        "node_id": "h2",
        "message_id": "kzYss6XSJBnFKQ6AN",
        "request_id": "aaoE89fSZZGZhqMBf",
        "status": "rejected",
        "reason": "prerequisite_not_satisfied_before_request",
        "value_match": false,
        "context_match": false,
        "observed_refusal": false
      },
      {
        "node_id": "h3",
        "message_id": "gGKbQRWtDAYeShWmi",
        "request_id": "4McrypkzuGPjtSDNw",
        "status": "rejected",
        "reason": "prerequisite_not_satisfied_before_request",
        "value_match": false,
        "context_match": false,
        "observed_refusal": false
      },
      {
        "node_id": "h2",
        "message_id": "gPeFBYxpBLsRx6HJo",
        "request_id": "6CzqNbHSfc9N8Kt2W",
        "status": "rejected",
        "reason": "prerequisite_not_satisfied_before_request",
        "value_match": true,
        "context_match": true,
        "observed_refusal": false
      },
      {
        "node_id": "h3",
        "message_id": "LNqLcff6TevXrAiQS",
        "request_id": "9nvQmcM6ZCn3szT36",
        "status": "rejected",
        "reason": "prerequisite_not_satisfied_before_request",
        "value_match": true,
        "context_match": true,
        "observed_refusal": false
      }
    ],
    "unknown_nodes": [
      "h1"
    ],
    "artifact": {
      "artifact_correct": true,
      "field_accuracy": 1.0
    },
    "fields": {
      "docs_build_id": {
        "present": true,
        "matches_full": true,
        "matches_no_contact": false
      },
      "qa_signoff": {
        "present": true,
        "matches_full": true,
        "matches_no_contact": false
      },
      "launch_date": {
        "present": true,
        "matches_full": true,
        "matches_no_contact": false
      },
      "authorization_ref": {
        "present": true,
        "matches_full": true,
        "matches_no_contact": false
      }
    },
    "process": {
      "nodes_satisfied": [],
      "all_nodes_satisfied": null,
      "order_ok": null,
      "contacts": [
        "Priya Sharma",
        "Liu Qiang",
        "Jessica Chen"
      ],
      "n_asks": 5,
      "first_contact": "Priya Sharma",
      "first_contact_valid": true,
      "interruption_cost": 5.0
    },
    "errors": {
      "wrong_person": 0,
      "decoy_contacts": [],
      "out_of_pool": [],
      "premature_request": 4,
      "rejections": 0,
      "repaired_nodes": 0,
      "no_repair_nodes": 0,
      "redundant": 0,
      "n_auth": 0,
      "n_waste": 0,
      "silent_failure": false,
      "unsupported_claims": [],
      "unverified_claims": [
        "docs_build_id",
        "qa_signoff",
        "launch_date",
        "authorization_ref"
      ],
      "unused_reply_nodes": [],
      "over_ask": null
    }
  },
  "status": {
    "terminal": "submitted",
    "collection_complete": true,
    "submitted": true,
    "finished": "2026-11-01T02:45:33.490446+00:00",
    "method": "study21-v2-rest-1"
  },
  "runtime_error": null,
  "collection_error": null
}
```

## All actual messages

```json
[
  {
    "message_id": "vDfYjFnMHAAuMvKKz",
    "episode_id": "f9237fd6-5020-4753-a5f8-3468e1fe61cf",
    "room_id": "Kdnw4PMD6Aph8NeCHZgyuBqAPMHX8nJKLh",
    "timestamp": "2026-11-01T02:41:27.658Z",
    "actor": "agent",
    "colleague": "Priya Sharma",
    "content": "Hi Priya, I'm preparing the go/no-go record for the API v3 documentation portal launch. Per the plan, the docs build is DB-301. Can you confirm the docs_build_id and that the build is ready?"
  },
  {
    "message_id": "qu3kp97ecKturdXWZ",
    "episode_id": "f9237fd6-5020-4753-a5f8-3468e1fe61cf",
    "room_id": "Kdnw4PMD6Aph8NeCHZgyuBqAPMHX8nJKLh",
    "timestamp": "2026-11-01T02:41:29.139Z",
    "actor": "npc",
    "colleague": "Priya Sharma",
    "content": "For the API v3 portal, my current record shows docs build **DB-318** and launch date **2026-11-17**./n/nI can confirm the current build and launch date, but I can’t confirm readiness from my records alone.",
    "in_reply_to": "vDfYjFnMHAAuMvKKz"
  },
  {
    "message_id": "aaoE89fSZZGZhqMBf",
    "episode_id": "f9237fd6-5020-4753-a5f8-3468e1fe61cf",
    "room_id": "Kdnw4PMD6Aph8NeCHdz6Z2triPsyBjDBRR",
    "timestamp": "2026-11-01T02:41:37.306Z",
    "actor": "agent",
    "colleague": "Liu Qiang",
    "content": "Hi Liu Qiang, I'm preparing the go/no-go record for the API v3 documentation portal launch (build DB-301, launch date 2026-11-12). Can you confirm QA sign-off for this build?"
  },
  {
    "message_id": "kzYss6XSJBnFKQ6AN",
    "episode_id": "f9237fd6-5020-4753-a5f8-3468e1fe61cf",
    "room_id": "Kdnw4PMD6Aph8NeCHdz6Z2triPsyBjDBRR",
    "timestamp": "2026-11-01T02:41:38.688Z",
    "actor": "npc",
    "colleague": "Liu Qiang",
    "content": "I can’t confirm QA sign-off for that build./n/nMy release rule only allows sign-off against DB-318, and your request is for DB-301.",
    "in_reply_to": "aaoE89fSZZGZhqMBf"
  },
  {
    "message_id": "4McrypkzuGPjtSDNw",
    "episode_id": "f9237fd6-5020-4753-a5f8-3468e1fe61cf",
    "room_id": "AyvF6gpaMBT7XSsmjKdnw4PMD6Aph8NeCH",
    "timestamp": "2026-11-01T02:41:56.349Z",
    "actor": "agent",
    "colleague": "Jessica Chen",
    "content": "Hi Jessica, I'm preparing the go/no-go record for the API v3 documentation portal launch. Huang Jie is out of office and has delegated product approvals to you. Can you confirm your authorization for the launch on 2026-11-12?"
  },
  {
    "message_id": "gGKbQRWtDAYeShWmi",
    "episode_id": "f9237fd6-5020-4753-a5f8-3468e1fe61cf",
    "room_id": "AyvF6gpaMBT7XSsmjKdnw4PMD6Aph8NeCH",
    "timestamp": "2026-11-01T02:41:57.471Z",
    "actor": "npc",
    "colleague": "Jessica Chen",
    "content": "I can confirm I’m the delegated approver for product release decisions within my authority, but I can’t approve this launch as stated because the required conditions aren’t fully met yet./n/nMissing conditions:\n- QA sign-off reference\n- The cited launch date needs to match the approval record’s required date context\n\nIf you provide the QA sign-off and confirm the date context, I can evaluate approval.",
    "in_reply_to": "4McrypkzuGPjtSDNw"
  },
  {
    "message_id": "6CzqNbHSfc9N8Kt2W",
    "episode_id": "f9237fd6-5020-4753-a5f8-3468e1fe61cf",
    "room_id": "Kdnw4PMD6Aph8NeCHdz6Z2triPsyBjDBRR",
    "timestamp": "2026-11-01T02:43:27.147Z",
    "actor": "agent",
    "colleague": "Liu Qiang",
    "content": "Hi Liu Qiang, thanks for clarifying. Can you confirm QA sign-off for build DB-318 for the API v3 documentation portal launch?"
  },
  {
    "message_id": "gPeFBYxpBLsRx6HJo",
    "episode_id": "f9237fd6-5020-4753-a5f8-3468e1fe61cf",
    "room_id": "Kdnw4PMD6Aph8NeCHdz6Z2triPsyBjDBRR",
    "timestamp": "2026-11-01T02:43:28.311Z",
    "actor": "npc",
    "colleague": "Liu Qiang",
    "content": "Approved for DB-318./n/nQA sign-off reference: QA-DB318.",
    "in_reply_to": "6CzqNbHSfc9N8Kt2W"
  },
  {
    "message_id": "9nvQmcM6ZCn3szT36",
    "episode_id": "f9237fd6-5020-4753-a5f8-3468e1fe61cf",
    "room_id": "AyvF6gpaMBT7XSsmjKdnw4PMD6Aph8NeCH",
    "timestamp": "2026-11-01T02:44:02.611Z",
    "actor": "agent",
    "colleague": "Jessica Chen",
    "content": "Hi Jessica, updating you with the corrected details for the API v3 documentation portal launch:\n- Docs build: DB-318\n- QA sign-off reference: QA-DB318\n- Launch date: 2026-11-17 (per current records)\n\nCan you now confirm your authorization as delegated approver?"
  },
  {
    "message_id": "LNqLcff6TevXrAiQS",
    "episode_id": "f9237fd6-5020-4753-a5f8-3468e1fe61cf",
    "room_id": "AyvF6gpaMBT7XSsmjKdnw4PMD6Aph8NeCH",
    "timestamp": "2026-11-01T02:44:03.496Z",
    "actor": "npc",
    "colleague": "Jessica Chen",
    "content": "Approved for the API v3 documentation portal launch on 2026-11-17, with QA sign-off reference QA-DB318 and authorization ref LCH-APR-3.",
    "in_reply_to": "9nvQmcM6ZCn3szT36"
  }
]
```

## Actual tool adoption and delivery

```json
[
  {
    "step": 10,
    "timestamp": "2026-11-01T02:42:27.654179+00:00",
    "tool": "read_messages",
    "arguments": "{\"person\": \"Priya Sharma\"}",
    "result": [
      {
        "id": "vDfYjFnMHAAuMvKKz",
        "msg": null
      },
      {
        "id": "qu3kp97ecKturdXWZ",
        "msg": null
      }
    ],
    "is_error": false,
    "latency_s": 0.06299999996554106
  },
  {
    "step": 11,
    "timestamp": "2026-11-01T02:42:37.207533+00:00",
    "tool": "read_messages",
    "arguments": "{\"person\": \"Liu Qiang\"}",
    "result": [
      {
        "id": "aaoE89fSZZGZhqMBf",
        "msg": null
      },
      {
        "id": "kzYss6XSJBnFKQ6AN",
        "msg": null
      }
    ],
    "is_error": false,
    "latency_s": 0.0779999999795109
  },
  {
    "step": 12,
    "timestamp": "2026-11-01T02:42:58.141032+00:00",
    "tool": "read_messages",
    "arguments": "{\"person\": \"Jessica Chen\"}",
    "result": [
      {
        "id": "4McrypkzuGPjtSDNw",
        "msg": null
      },
      {
        "id": "gGKbQRWtDAYeShWmi",
        "msg": null
      }
    ],
    "is_error": false,
    "latency_s": 0.06300000008195639
  },
  {
    "step": 14,
    "timestamp": "2026-11-01T02:43:40.232362+00:00",
    "tool": "read_messages",
    "arguments": "{\"person\": \"Liu Qiang\"}",
    "result": [
      {
        "id": "aaoE89fSZZGZhqMBf",
        "msg": null
      },
      {
        "id": "kzYss6XSJBnFKQ6AN",
        "msg": null
      },
      {
        "id": "6CzqNbHSfc9N8Kt2W",
        "msg": null
      },
      {
        "id": "gPeFBYxpBLsRx6HJo",
        "msg": null
      }
    ],
    "is_error": false,
    "latency_s": 0.06299999996554106
  },
  {
    "step": 16,
    "timestamp": "2026-11-01T02:44:31.526066+00:00",
    "tool": "read_messages",
    "arguments": "{\"person\": \"Jessica Chen\"}",
    "result": [
      {
        "id": "4McrypkzuGPjtSDNw",
        "msg": null
      },
      {
        "id": "gGKbQRWtDAYeShWmi",
        "msg": null
      },
      {
        "id": "9nvQmcM6ZCn3szT36",
        "msg": null
      },
      {
        "id": "LNqLcff6TevXrAiQS",
        "msg": null
      }
    ],
    "is_error": false,
    "latency_s": 0.06299999996554106
  },
  {
    "step": 17,
    "timestamp": "2026-11-01T02:44:44.042161+00:00",
    "tool": "write_file",
    "arguments": "{\"path\": \"/workspace/deliverable.json\", \"content\": \"{\\n  \\\"docs_build_id\\\": \\\"DB-318\\\",\\n  \\\"qa_signoff\\\": \\\"QA-DB318\\\",\\n  \\\"launch_date\\\": \\\"2026-11-17\\\",\\n  \\\"authorization_ref\\\": \\\"LCH-APR-3\\\"\\n}\\n\"}",
    "result": {
      "saved": "/workspace/deliverable.json"
    },
    "is_error": false,
    "latency_s": 0.0
  },
  {
    "step": 18,
    "timestamp": "2026-11-01T02:45:17.500501+00:00",
    "tool": "post_message",
    "arguments": "{\"channel\": \"#engineering\", \"message\": \"Go/no-go record prepared for API v3 documentation portal launch:\\n- Docs build: DB-318\\n- QA sign-off: QA-DB318\\n- Launch date: 2026-11-17\\n- Authorization: LCH-APR-3 (Jessica Chen, delegated by Huang Jie)\\n\\nFile: /workspace/deliverable.json\"}",
    "result": {
      "message_id": "rA8oB3Cf9JLhmjjKo"
    },
    "is_error": false,
    "latency_s": 0.1559999999590218
  },
  {
    "step": 19,
    "timestamp": "2026-11-01T02:45:33.167115+00:00",
    "tool": "submit",
    "arguments": "{}",
    "result": {
      "submitted": true
    },
    "is_error": false,
    "latency_s": 0.0
  }
]
```

## Existing evidence-based review (historical, apply newest rules)

```json
{
  "index": 31,
  "provider": "kimi",
  "task_id": "m-high-portal-launch",
  "episode_id": "f9237fd6-5020-4753-a5f8-3468e1fe61cf",
  "business": "business_success",
  "business_reason_cn": "最终DB-318、QA-DB318、2026-11-17、LCH-APR-3均正确，实际代理批准人Jessica Chen合乎公开休假委托。",
  "approval_behavior_cn": "旧build/date的请求被拒后，补齐当前QA及日期取得明确代理批准。",
  "nonmaterial_difference_cn": "API v3 documentation portal与API v3 portal指同一对象，无身份变化。",
  "agent_issue_cn": "初始使用DB-301与11-12，最终已纠正。",
  "npc_status": "no_observed_issue",
  "npc_issues": [],
  "evidence": [
    {
      "message_id": "qu3kp97ecKturdXWZ",
      "request_id": "vDfYjFnMHAAuMvKKz",
      "quote": "docs build **DB-318** and launch date **2026-11-17**",
      "judgment": "accept",
      "reason_cn": "真实当前build/date；没有擅自宣称已ready。",
      "agent_read_steps": [
        10
      ],
      "actual_timestamp": "2026-11-01T02:41:29.139Z",
      "message_sha256": "eebf09c65d9c453a90d9f3685d538b848a00bdbfec5ffa7c54573594f99fc945"
    },
    {
      "message_id": "kzYss6XSJBnFKQ6AN",
      "request_id": "aaoE89fSZZGZhqMBf",
      "quote": "My release rule only allows sign-off against DB-318, and your request is for DB-301.",
      "judgment": "accept",
      "reason_cn": "拒绝旧build合理，真实新版提示不是签核。",
      "agent_read_steps": [
        11,
        14
      ],
      "actual_timestamp": "2026-11-01T02:41:38.688Z",
      "message_sha256": "10a667471ab99e31e5849800b4639aaa806ab3ff13febc982c350f3d54997cbf"
    },
    {
      "message_id": "gGKbQRWtDAYeShWmi",
      "request_id": "4McrypkzuGPjtSDNw",
      "quote": "Missing conditions:\n- QA sign-off reference\n- The cited launch date needs to match the approval record’s required date context",
      "judgment": "accept",
      "reason_cn": "首次无QA且日期错误，拒绝有据；委托身份真实。",
      "agent_read_steps": [
        12,
        16
      ],
      "actual_timestamp": "2026-11-01T02:41:57.471Z",
      "message_sha256": "93a90ddcad30d6532f97f7fa685e08c136fb88d96a5e596f4ed882104d3b7093"
    },
    {
      "message_id": "gPeFBYxpBLsRx6HJo",
      "request_id": "6CzqNbHSfc9N8Kt2W",
      "quote": "Approved for DB-318./n/nQA sign-off reference: QA-DB318.",
      "judgment": "accept",
      "reason_cn": "对当前build明确QA签核。",
      "agent_read_steps": [
        14
      ],
      "actual_timestamp": "2026-11-01T02:43:28.311Z",
      "message_sha256": "64da58e018515e0755d460f280d1415a3d02a849ee1d890de8df7e62cd635421"
    },
    {
      "message_id": "LNqLcff6TevXrAiQS",
      "request_id": "9nvQmcM6ZCn3szT36",
      "quote": "Approved for the API v3 documentation portal launch on 2026-11-17, with QA sign-off reference QA-DB318 and authorization ref LCH-APR-3.",
      "judgment": "accept",
      "reason_cn": "收到匹配QA/date后明确批准；实际私有委托记录与公开材料一致。",
      "agent_read_steps": [
        16
      ],
      "actual_timestamp": "2026-11-01T02:44:03.496Z",
      "message_sha256": "71c4261b610812203fb948f39bf2206123ad8f0a067988ffa2ea1d23adb45922"
    }
  ],
  "uncertainty_cn": "API实际输入、同人历史和读回已核对；非盲AI，保留原state/T/R，无新分数。",
  "delivered": true,
  "submitted": true,
  "original_episode_id": "a17c3ccb-7ee8-4691-b4cd-ca5f49687ec0",
  "original_state": "needs_review",
  "repair_original_state": "needs_review",
  "original_T": 0.75,
  "original_R": 0.55,
  "repair_strict_T": 1.0,
  "repair_strict_R": 0.75,
  "new_semantic_T": null,
  "new_semantic_R": null,
  "original_business": "business_failure",
  "NPC_backend": "controlled_rest_conversational_repair_v6",
  "NPC_criterion": "NPC-truthful-extra-v3",
  "approval_criterion": "approval-semantic-v2",
  "evaluation_status": "needs_evidence_review",
  "technical_state": "complete_collected",
  "actual_NPC_replies": 5,
  "all_NPC_messages_judged": true,
  "episode_cost_with_reservations_usd": "0.05979410",
  "run": "evidence/f9237fd6-5020-4753-a5f8-3468e1fe61cf",
  "packet": "packets//31.json",
  "full_readable_evidence": "packets//31.md",
  "original_hashes": {
    "account_map.json": "ae56a3aa5fe6a82caf65f3075448c42f2cc1b3a41e6333122757f163d6c914ee",
    "actual_input_audit.json": "dadcdff3874f9c2bb7d3f9c9df690f67d90430bfe19bf4edd1ffbfc247bbfce7",
    "api_io.jsonl": "9778dbff001c38ffe9fc81ff6818e0c7ec4b3c5641aaf6dc9ca773232e355911",
    "chat_pages.jsonl": "78f948773558944bf419118dfd4b9b03597dbd840a3f910078b78ebe888ce569",
    "controller_summary.json": "309ac7e80d74ab3b15cb43e9aa0db48404817b624935c5b3dcfea3f8635b0320",
    "directory_presentation.json": "642df713d6ee2afeb7b63b8ffcb032fc24591937a7e05d861fa35590c9c442a2",
    "episode_audit.json": "042cb3ad924a593864921dbfc37273dc9b8b4e482c8af9764276445954f7c0bb",
    "evaluation.json": "9e1d0d9025b6df0ece30a92ab632250282222b7c482a9b5306fdfa01b220b198",
    "first_actual_agent_request.json": "9c51e7b1e7ec20b7ee7969af7371848e8b329546c9512edd7ee0081f59003840",
    "natural_npc_events.jsonl": "c3b77fc1b6d1fb5fb4d5bc0ac1e1bd47b8bc6452217d75cf569a1cf05e0c8930",
    "normalized_usage.jsonl": "eaa7cd82f3153559453aed589930069f3942701134d5e2073253383762f58997",
    "NPC_posthoc_criterion.json": "eea773cc6d1ef751a6cb023d853cca34cceeb4caac17bdfffd46ccf1a780aaae",
    "posthoc_business_NPC_review.json": "cc9bcb806ef7be6bb10ef24ffb69be3b1f56b39b82f22072192d30bb102c13c7",
    "public_instruction.md": "b8a9f0939378cf2a031373e3028a8bce2e566a695fa9440bd8a6ec3151ef884d",
    "raw_chat.json": "e2d40abacb07dfe0e50164c8ae521727d7dcb0b3d4007c5e796b0617b5b9e429",
    "rest_requests.jsonl": "283a64fd684583ceeaa1b8a2460005c18c1ab53834cc74dbe4c1e5656e055bb6",
    "reviewed_trace_bundle.json": "96b8ff0688637b13bf4046065ce906e673ecf8f5c26d96db7251eb2426db7d34",
    "run_manifest.json": "0d69fcac62ce4ef9c98713ac6c13b92b1cd22913163b7407c9406c104aae0722",
    "status.json": "5c74789dd4a02956bd7416f985867a4faf8c7fe5bbd4bc5e3c7567157bfbc402",
    "tool_events.jsonl": "4371c998719a2d3e341ffec23146b9985d3201761fbe5a77f9386a79d36ac72f",
    "trace_bundle.json": "96b8ff0688637b13bf4046065ce906e673ecf8f5c26d96db7251eb2426db7d34",
    "workspace.json": "821fffc84b180b1929e1a4510a9848b1180af88f8fb031cc6a68d536ef2c5248",
    "workspace_events.jsonl": "aadd6fe3250425fca810143809ff2af53c72bba8b91f136509cc18a117ef68c1",
    "workspace\\deliverable.json": "d66a8064be179a80885c49a734dde6daab72a510e0753ce60e3ad8abb88049e7"
  },
  "reviewer": "nonblind session AI"
}
```

## Binding user-adjudicated scores

```json
null
```