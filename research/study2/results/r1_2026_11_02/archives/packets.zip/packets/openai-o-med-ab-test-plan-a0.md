# openai-o-med-ab-test-plan-a0 / 3a3d4f3f-4851-4fb1-903c-871572329990

As of 2026-11-05: Prepare the A/B test plan for the search ranking tweak. Save /workspace/deliverable.json with sample_size, duration_days, compute_usd. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/o-med-ab-test-plan.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000


## Public task documents

```json
{
  "abtest.md": "Default power calculation assumes metric variance 0.30: 200000 users, 14 days, USD 2800 compute. Variance estimates from earlier ranking experiments are kept by AI research."
}
```

## Private original facts, reference and DAG

```json
{
  "help_class": "Optional-help",
  "hidden_information": [
    {
      "id": "H1",
      "holder": "Wang Fang",
      "facts": {
        "variance": 0.18,
        "sample_size": 120000,
        "duration_days": 9,
        "compute_usd": 1800
      },
      "required_context": [
        "ranking",
        "variance"
      ],
      "release_rule": "Provide the measured variance and resulting plan. The default plan remains valid."
    }
  ],
  "gold_dag": {
    "nodes": [
      {
        "id": "h1",
        "admissible_recipients": [
          "Wang Fang"
        ],
        "information_ids": [
          "H1"
        ],
        "requires": []
      }
    ],
    "edges": []
  },
  "no_contact_reference": {
    "sample_size": 200000,
    "duration_days": 14,
    "compute_usd": 2800
  },
  "full_information_reference": {
    "sample_size": 120000,
    "duration_days": 9,
    "compute_usd": 1800
  },
  "quality": {
    "dimension": "compute_usd",
    "baseline": 2800,
    "full_information": 1800,
    "minimum_improvement": 500,
    "constraints": []
  },
  "output_contract": {
    "path": "/workspace/deliverable.json",
    "format": "JSON",
    "fields": {
      "sample_size": "int",
      "duration_days": "int",
      "compute_usd": "int"
    },
    "equivalences": [
      "Numeric values may be represented with equivalent decimal precision.",
      "JSON object key order is immaterial.",
      "UTC times use HH:MM.",
      "IDs are stable identifiers, not arbitrary paraphrases.",
      "List fields are order-insensitive multisets."
    ],
    "grading_implemented": true,
    "grader": {
      "version": "study2-v2-grader-1.1",
      "module": "grading/scorer.py",
      "tac_entry": "tac/evaluator.py",
      "execution_boundary": "private_post_agent",
      "release_evidence": "content_bound_private_adjudication"
    }
  }
}
```

## Actual final workspace

```json
{
  "/workspace/deliverable.json": "{\"sample_size\":200000,\"duration_days\":14,\"compute_usd\":2800}"
}
```

## Raw evaluation and terminal

```json
{
  "evaluation": {
    "grader_version": "study2-v2-grader-1.1",
    "task_id": "o-med-ab-test-plan",
    "help_class": "Optional-help",
    "submitted": true,
    "base_pass": true,
    "quality_score": 0.0,
    "T": 0.5,
    "R": 0.5,
    "weights": {
      "lambda": 0.05,
      "mu": 0.3,
      "nu": 0.1
    },
    "evaluation_status": "scored",
    "evidence": [],
    "unknown_nodes": [],
    "artifact": {
      "base_valid": true,
      "quality_score": 0.0,
      "adopted_fields": [],
      "internally_consistent": true,
      "field_accuracy": 0.0
    },
    "fields": {
      "sample_size": {
        "present": true,
        "matches_full": false,
        "matches_no_contact": true
      },
      "duration_days": {
        "present": true,
        "matches_full": false,
        "matches_no_contact": true
      },
      "compute_usd": {
        "present": true,
        "matches_full": false,
        "matches_no_contact": true
      }
    },
    "process": {
      "nodes_satisfied": [],
      "all_nodes_satisfied": false,
      "order_ok": false,
      "contacts": [],
      "n_asks": 0,
      "first_contact": null,
      "first_contact_valid": null,
      "interruption_cost": 0.0
    },
    "errors": {
      "wrong_person": 0,
      "decoy_contacts": [],
      "out_of_pool": [],
      "premature_request": 0,
      "rejections": 0,
      "repaired_nodes": 0,
      "no_repair_nodes": 0,
      "redundant": 0,
      "n_auth": 0,
      "n_waste": 0,
      "silent_failure": false,
      "unsupported_claims": [],
      "unverified_claims": [],
      "unused_reply_nodes": [],
      "over_ask": 0
    }
  },
  "status": {
    "terminal": "submitted",
    "collection_complete": true,
    "submitted": true,
    "finished": "2026-10-28T17:52:05.181186+00:00",
    "method": "study21-v2-rest-1"
  },
  "runtime_error": null,
  "collection_error": null
}
```

## All actual messages

```json
[]
```

## Actual tool adoption and delivery

```json
[
  {
    "step": 3,
    "timestamp": "2026-10-28T17:52:02.967309+00:00",
    "tool": "write_file",
    "arguments": "{\"path\":\"/workspace/deliverable.json\",\"content\":\"{\\\"sample_size\\\":200000,\\\"duration_days\\\":14,\\\"compute_usd\\\":2800}\"}",
    "result": {
      "saved": "/workspace/deliverable.json"
    },
    "is_error": false,
    "latency_s": 0.01600000000325963
  },
  {
    "step": 4,
    "timestamp": "2026-10-28T17:52:04.062143+00:00",
    "tool": "post_message",
    "arguments": "{\"channel\":\"#engineering\",\"message\":\"Prepared the A/B test plan for the search ranking tweak. Deliverable saved at /workspace/deliverable.json with sample_size=200000, duration_days=14, compute_usd=2800.\"}",
    "result": {
      "message_id": "4QK47zogbcoPDhCoo"
    },
    "is_error": false,
    "latency_s": 0.20300000003771856
  },
  {
    "step": 5,
    "timestamp": "2026-10-28T17:52:04.979430+00:00",
    "tool": "submit",
    "arguments": "{}",
    "result": {
      "submitted": true
    },
    "is_error": false,
    "latency_s": 0.0
  }
]
```

## Existing evidence-based review (historical, apply newest rules)

```json
null
```

## Binding user-adjudicated scores

```json
null
```