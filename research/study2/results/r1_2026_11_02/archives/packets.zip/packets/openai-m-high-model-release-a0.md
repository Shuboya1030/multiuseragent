# openai-m-high-model-release-a0 / 9a256688-547a-4223-893a-4b034734bf1d

As of 2026-11-05: Prepare the release record for model checkpoint Aurora-7B. Save /workspace/deliverable.json with checkpoint, eval_report_id, safety_attestation, release_tier, mandate_reference. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/m-high-model-release.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000


## Public task documents

```json
{
  "release.md": "Aurora-7B. Draft from 2026-10-01 cites eval report EV-12, release tier internal, research-lead mandate RES-DRAFT-7.",
  "release-policy.md": "Evaluation reports are produced by the research owner of the model. QA attests safety only against a cited current evaluation report. Public-tier releases need an executive technical mandate citing the attestation; internal-tier releases are within the research lead mandate.",
  "release-tiers.md": "A checkpoint is public tier when its current evaluation report includes external benchmark claims."
}
```

## Private original facts, reference and DAG

```json
{
  "help_class": "Must-help",
  "hidden_information": [
    {
      "id": "H1",
      "holder": "Wang Fang",
      "facts": {
        "eval_report_id": "EV-19",
        "release_tier": "public",
        "external_benchmark_claims": true
      },
      "required_context": [
        "Aurora-7B"
      ],
      "release_rule": "Provide the current evaluation report ID and note that it includes external benchmark claims."
    },
    {
      "id": "H2",
      "holder": "Liu Qiang",
      "facts": {
        "safety_attestation": "QA-SAF-191"
      },
      "required_context": [
        "EV-19"
      ],
      "release_rule": "Attest only against EV-19."
    },
    {
      "id": "H3",
      "holder": "Sarah Johnson",
      "facts": {
        "mandate_reference": "TECH-AUR-7"
      },
      "required_context": [
        "QA-SAF-191",
        "public"
      ],
      "release_rule": "Issue the mandate only with the attestation and public tier cited."
    }
  ],
  "gold_dag": {
    "nodes": [
      {
        "id": "h1",
        "admissible_recipients": [
          "Wang Fang"
        ],
        "information_ids": [
          "H1"
        ],
        "requires": []
      },
      {
        "id": "h2",
        "admissible_recipients": [
          "Liu Qiang"
        ],
        "information_ids": [
          "H2"
        ],
        "requires": [
          "h1"
        ]
      },
      {
        "id": "h3",
        "admissible_recipients": [
          "Sarah Johnson"
        ],
        "information_ids": [
          "H3"
        ],
        "requires": [
          "h2"
        ]
      }
    ],
    "edges": [
      [
        "h1",
        "h2"
      ],
      [
        "h2",
        "h3"
      ]
    ]
  },
  "no_contact_reference": {
    "checkpoint": "Aurora-7B",
    "eval_report_id": "EV-12",
    "safety_attestation": "PENDING",
    "release_tier": "internal",
    "mandate_reference": "RES-DRAFT-7"
  },
  "full_information_reference": {
    "checkpoint": "Aurora-7B",
    "eval_report_id": "EV-19",
    "safety_attestation": "QA-SAF-191",
    "release_tier": "public",
    "mandate_reference": "TECH-AUR-7"
  },
  "quality": null,
  "output_contract": {
    "path": "/workspace/deliverable.json",
    "format": "JSON",
    "fields": {
      "checkpoint": "str",
      "eval_report_id": "str",
      "safety_attestation": "str",
      "release_tier": "str",
      "mandate_reference": "str"
    },
    "equivalences": [
      "Numeric values may be represented with equivalent decimal precision.",
      "JSON object key order is immaterial.",
      "UTC times use HH:MM.",
      "IDs are stable identifiers, not arbitrary paraphrases.",
      "List fields are order-insensitive multisets."
    ],
    "grading_implemented": true,
    "grader": {
      "version": "study2-v2-grader-1.1",
      "module": "grading/scorer.py",
      "tac_entry": "tac/evaluator.py",
      "execution_boundary": "private_post_agent",
      "release_evidence": "content_bound_private_adjudication"
    }
  }
}
```

## Actual final workspace

```json
{}
```

## Raw evaluation and terminal

```json
{
  "evaluation": null,
  "status": {
    "terminal": "runtime_error",
    "collection_complete": false,
    "submitted": false,
    "finished": "2026-10-28T03:48:20.845095+00:00",
    "task_success": "not_scored",
    "method": "study21-v2-rest-1"
  },
  "runtime_error": {
    "error_type": "HttpFailure",
    "timestamp": "2026-10-28T03:48:20.838786+00:00",
    "message": "HTTP request failed: status 429",
    "failure_kind": "provider_rate_limit"
  },
  "collection_error": {
    "error_type": "RestError",
    "message": "Isolation/public bootstrap incomplete; cannot certify episode export",
    "complete": false,
    "timestamp": "2026-10-28T03:48:20.843382+00:00"
  }
}
```

## All actual messages

```json
[]
```

## Actual tool adoption and delivery

```json
[]
```

## Existing evidence-based review (historical, apply newest rules)

```json
null
```

## Binding user-adjudicated scores

```json
null
```