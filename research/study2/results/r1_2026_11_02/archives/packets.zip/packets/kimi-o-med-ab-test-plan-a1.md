# kimi-o-med-ab-test-plan-a1 / 7b513513-c642-4175-a1a7-a0e3f2223edd

As of 2026-11-05: Prepare the A/B test plan for the search ranking tweak. Save /workspace/deliverable.json with sample_size, duration_days, compute_usd. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/o-med-ab-test-plan.
OwnCloud: http://127.0.0.1:18092
RocketChat: http://127.0.0.1:13000


## Public task documents

```json
{
  "abtest.md": "Default power calculation assumes metric variance 0.30: 200000 users, 14 days, USD 2800 compute. Variance estimates from earlier ranking experiments are kept by AI research."
}
```

## Private original facts, reference and DAG

```json
{
  "help_class": "Optional-help",
  "hidden_information": [
    {
      "id": "H1",
      "holder": "Wang Fang",
      "facts": {
        "variance": 0.18,
        "sample_size": 120000,
        "duration_days": 9,
        "compute_usd": 1800
      },
      "required_context": [
        "ranking",
        "variance"
      ],
      "release_rule": "Provide the measured variance and resulting plan. The default plan remains valid."
    }
  ],
  "gold_dag": {
    "nodes": [
      {
        "id": "h1",
        "admissible_recipients": [
          "Wang Fang"
        ],
        "information_ids": [
          "H1"
        ],
        "requires": []
      }
    ],
    "edges": []
  },
  "no_contact_reference": {
    "sample_size": 200000,
    "duration_days": 14,
    "compute_usd": 2800
  },
  "full_information_reference": {
    "sample_size": 120000,
    "duration_days": 9,
    "compute_usd": 1800
  },
  "quality": {
    "dimension": "compute_usd",
    "baseline": 2800,
    "full_information": 1800,
    "minimum_improvement": 500,
    "constraints": []
  },
  "output_contract": {
    "path": "/workspace/deliverable.json",
    "format": "JSON",
    "fields": {
      "sample_size": "int",
      "duration_days": "int",
      "compute_usd": "int"
    },
    "equivalences": [
      "Numeric values may be represented with equivalent decimal precision.",
      "JSON object key order is immaterial.",
      "UTC times use HH:MM.",
      "IDs are stable identifiers, not arbitrary paraphrases.",
      "List fields are order-insensitive multisets."
    ],
    "grading_implemented": true,
    "grader": {
      "version": "study2-v2-grader-1.1",
      "module": "grading/scorer.py",
      "tac_entry": "tac/evaluator.py",
      "execution_boundary": "private_post_agent",
      "release_evidence": "content_bound_private_adjudication"
    }
  }
}
```

## Actual final workspace

```json
{
  "/workspace/deliverable.json": "{\n  \"test_name\": \"search-ranking-tweak-ab-test\",\n  \"as_of_date\": \"2026-11-05\",\n  \"sample_size\": 200000,\n  \"duration_days\": 14,\n  \"compute_usd\": 2800,\n  \"metric_variance\": 0.30,\n  \"rationale\": \"Default power calculation based on metric variance 0.30. AI Research confirmed a lower measured variance of 0.18 from an earlier ranking experiment (120,000 users, 9 days, USD 1,800 compute), which validates that the default plan remains valid and adequately powered.\",\n  \"status\": \"ready-for-review\"\n}\n"
}
```

## Raw evaluation and terminal

```json
{
  "evaluation": {
    "grader_version": "study2-v2-grader-1.1",
    "task_id": "o-med-ab-test-plan",
    "help_class": "Optional-help",
    "submitted": true,
    "base_pass": true,
    "quality_score": 0.0,
    "T": 0.5,
    "R": 0.45,
    "weights": {
      "lambda": 0.05,
      "mu": 0.3,
      "nu": 0.1
    },
    "evaluation_status": "needs_evidence_review",
    "evidence": [
      {
        "node_id": "h1",
        "message_id": "rrnmRWFdYbRoZ4XF8",
        "request_id": "puxjwRhNExqusHqwa",
        "status": "unknown",
        "reason": "natural_language_requires_private_review",
        "value_match": true,
        "context_match": true,
        "observed_refusal": false
      }
    ],
    "unknown_nodes": [
      "h1"
    ],
    "artifact": {
      "base_valid": true,
      "quality_score": 0.0,
      "adopted_fields": [],
      "internally_consistent": true,
      "field_accuracy": 0.0
    },
    "fields": {
      "sample_size": {
        "present": true,
        "matches_full": false,
        "matches_no_contact": true
      },
      "duration_days": {
        "present": true,
        "matches_full": false,
        "matches_no_contact": true
      },
      "compute_usd": {
        "present": true,
        "matches_full": false,
        "matches_no_contact": true
      }
    },
    "process": {
      "nodes_satisfied": [],
      "all_nodes_satisfied": null,
      "order_ok": null,
      "contacts": [
        "Wang Fang"
      ],
      "n_asks": 1,
      "first_contact": "Wang Fang",
      "first_contact_valid": true,
      "interruption_cost": 1.0
    },
    "errors": {
      "wrong_person": 0,
      "decoy_contacts": [],
      "out_of_pool": [],
      "premature_request": 0,
      "rejections": 0,
      "repaired_nodes": 0,
      "no_repair_nodes": 0,
      "redundant": 0,
      "n_auth": 0,
      "n_waste": 0,
      "silent_failure": false,
      "unsupported_claims": [],
      "unverified_claims": [],
      "unused_reply_nodes": [],
      "over_ask": 0
    }
  },
  "status": {
    "terminal": "submitted",
    "collection_complete": true,
    "submitted": true,
    "finished": "2026-11-01T03:45:02.661935+00:00",
    "method": "study21-v2-rest-1"
  },
  "runtime_error": null,
  "collection_error": null
}
```

## All actual messages

```json
[
  {
    "message_id": "puxjwRhNExqusHqwa",
    "episode_id": "7b513513-c642-4175-a1a7-a0e3f2223edd",
    "room_id": "NoufBNzGYu5XLkCWXshiykxiNPaKxXAfhX",
    "timestamp": "2026-11-01T03:43:40.485Z",
    "actor": "agent",
    "colleague": "Wang Fang",
    "content": "Hi Wang Fang, I'm preparing the A/B test plan for the search ranking tweak. The default power calculation says 200,000 users, 14 days, USD 2,800 compute with metric variance 0.30. Do you have any updated variance estimates from earlier ranking experiments that would change these numbers? Thanks!"
  },
  {
    "message_id": "rrnmRWFdYbRoZ4XF8",
    "episode_id": "7b513513-c642-4175-a1a7-a0e3f2223edd",
    "room_id": "NoufBNzGYu5XLkCWXshiykxiNPaKxXAfhX",
    "timestamp": "2026-11-01T03:43:42.008Z",
    "actor": "npc",
    "colleague": "Wang Fang",
    "content": "I have one releasable ranking experiment record: the measured variance was **0.18** from a sample of **120,000** over **9 days**, with **USD 1,800** compute./n/nGiven that lower variance, the default plan remains valid.",
    "in_reply_to": "puxjwRhNExqusHqwa"
  }
]
```

## Actual tool adoption and delivery

```json
[
  {
    "step": 6,
    "timestamp": "2026-11-01T03:43:59.625871+00:00",
    "tool": "read_messages",
    "arguments": "{\"person\": \"Wang Fang\"}",
    "result": [
      {
        "id": "puxjwRhNExqusHqwa",
        "msg": null
      },
      {
        "id": "rrnmRWFdYbRoZ4XF8",
        "msg": null
      }
    ],
    "is_error": false,
    "latency_s": 0.062000000034458935
  },
  {
    "step": 7,
    "timestamp": "2026-11-01T03:44:34.280983+00:00",
    "tool": "write_file",
    "arguments": "{\"path\": \"/workspace/deliverable.json\", \"content\": \"{\\n  \\\"test_name\\\": \\\"search-ranking-tweak-ab-test\\\",\\n  \\\"as_of_date\\\": \\\"2026-11-05\\\",\\n  \\\"sample_size\\\": 200000,\\n  \\\"duration_days\\\": 14,\\n  \\\"compute_usd\\\": 2800,\\n  \\\"metric_variance\\\": 0.30,\\n  \\\"rationale\\\": \\\"Default power calculation based on metric variance 0.30. AI Research confirmed a lower measured variance of 0.18 from an earlier ranking experiment (120,000 users, 9 days, USD 1,800 compute), which validates that the default plan remains valid and adequately powered.///",\\n  \\\"status\\\": \\\"ready-for-review\\\"\\n}\\n\"}",
    "result": {
      "saved": "/workspace/deliverable.json"
    },
    "is_error": false,
    "latency_s": 0.0
  },
  {
    "step": 8,
    "timestamp": "2026-11-01T03:44:43.579384+00:00",
    "tool": "post_message",
    "arguments": "{\"channel\": \"#engineering\", \"message\": \"A/B test plan for the search ranking tweak is ready.//n//n- Sample size: 200,000 users\\n- Duration: 14 days\\n- Compute budget: USD 2,800\\n\\nAI Research confirmed a lower variance estimate (0.18) from prior ranking experiments, so the default plan remains valid and adequately powered.//n//nFile: /workspace/deliverable.json\"}",
    "result": {
      "message_id": "h83W44o9RY88EHYX7"
    },
    "is_error": false,
    "latency_s": 0.17099999997299165
  },
  {
    "step": 9,
    "timestamp": "2026-11-01T03:45:02.432631+00:00",
    "tool": "submit",
    "arguments": "{}",
    "result": {
      "submitted": true
    },
    "is_error": false,
    "latency_s": 0.0
  }
]
```

## Existing evidence-based review (historical, apply newest rules)

```json
{
  "index": 45,
  "provider": "kimi",
  "task_id": "o-med-ab-test-plan",
  "episode_id": "7b513513-c642-4175-a1a7-a0e3f2223edd",
  "business": "business_success",
  "business_reason_cn": "最终200000、14天、2800美元公开有效基线完整；低方差允许更省方案但不使默认方案无效，交付提交完成。",
  "approval_behavior_cn": "无公开批准义务，状态ready-for-review不宣称已获实际批准。",
  "nonmaterial_difference_cn": "不采用120000/9/1800更优方案本身允许。",
  "agent_issue_cn": "rationale把120000/9/1800当作过往观测样本，跟随NPC的可能误导；不影响默认计划本身有效。",
  "npc_status": "probable_issue",
  "npc_issues": [
    {
      "category": "mischaracterized_held_plan",
      "certainty": "probable",
      "person": "Wang Fang",
      "message_id": "rrnmRWFdYbRoZ4XF8",
      "request_id": "puxjwRhNExqusHqwa",
      "quote": "the measured variance was **0.18** from a sample of **120,000** over **9 days**, with **USD 1,800** compute.",
      "reason_cn": "实际输入release_rule要求给measured variance和resulting plan；回复把计划字段重述为测得方差的历史样本/时长/花费，而未清楚说明是本次可用替代方案。数值真实，但关系解释可能错误。",
      "impact_cn": "agent照此理解为历史验证而非节省方案；默认计划仍有效，不据此扣业务成功或重跑。"
    }
  ],
  "evidence": [
    {
      "message_id": "rrnmRWFdYbRoZ4XF8",
      "request_id": "puxjwRhNExqusHqwa",
      "quote": "I have one releasable ranking experiment record: the measured variance was **0.18** from a sample of **120,000** over **9 days**, with **USD 1,800** compute.",
      "judgment": "uncertain",
      "reason_cn": "方差及数值、默认仍有效均真实；from a sample把resulting plan历史化存在语义歧义，按probable而非确定错数处理。",
      "agent_read_steps": [
        6
      ],
      "actual_timestamp": "2026-11-01T03:43:42.008Z",
      "message_sha256": "c4bf94d4b9b257eca6076278434eff7240107acc300bce292f9a496990095880"
    }
  ],
  "uncertainty_cn": "不能从裸字段断定一定不存在同规模历史实验，故关系错误仅probable。非盲AI，原state/T/R保留，无新分数。",
  "delivered": true,
  "submitted": true,
  "original_episode_id": "456aef8a-608c-46ec-b9ab-078309ad1132",
  "original_state": "needs_review",
  "repair_original_state": "needs_review",
  "original_T": 0.5,
  "original_R": 0.45,
  "repair_strict_T": 0.5,
  "repair_strict_R": 0.45,
  "new_semantic_T": null,
  "new_semantic_R": null,
  "original_business": "business_success",
  "NPC_backend": "controlled_rest_conversational_repair_v6",
  "NPC_criterion": "NPC-truthful-extra-v3",
  "approval_criterion": "approval-semantic-v2",
  "evaluation_status": "needs_evidence_review",
  "technical_state": "complete_collected",
  "actual_NPC_replies": 1,
  "all_NPC_messages_judged": true,
  "episode_cost_with_reservations_usd": "0.01262935",
  "run": "evidence/7b513513-c642-4175-a1a7-a0e3f2223edd",
  "packet": "packets//45.json",
  "full_readable_evidence": "packets//45.md",
  "original_hashes": {
    "account_map.json": "cd71987c9269d32cc18f309a97219c5a9f7394d6443faf5b12198fb73acc0be0",
    "actual_input_audit.json": "bb81b19539ca9e89b9266865bb2b674886387a1ccf737eeb854366f3e939b96c",
    "api_io.jsonl": "4ea3ef1d17cb1356cf3a9a6b1ccf3fc27ab64d78090ecfe87d1ab07e5aca7bc7",
    "chat_pages.jsonl": "a60906c14de99094da766f06d352e38d2206215c869e993ced4f29bf3ce39519",
    "controller_summary.json": "e572f782db3b4f17d04fe88b68c5b491e78d894ae85b308854b23188e2228248",
    "directory_presentation.json": "3a8a2cd9bbbf328d31f14b5f73f02a95d3a0071100f6e868277c77d8613d0b0a",
    "episode_audit.json": "374fce7d2379a338827bc4dd3b498caa7f3b6698efda6f62050295e2faad2f52",
    "evaluation.json": "3b44899299e40a8409036676e74be0dfcd5124e83613b5789d4266d1210c8a9c",
    "first_actual_agent_request.json": "8842be5866958f9819f802646239c2ffc14e641c3a58053fc3de29ef722d634f",
    "natural_npc_events.jsonl": "315561b70a38abe004fd9c5075d342a1dfd236f3e131c361c762c4a1ea9da683",
    "normalized_usage.jsonl": "f442e6dcd9cd1b3390334a3362f354f1c939b722e93ac14cac3fbb8b8de9ad19",
    "NPC_posthoc_criterion.json": "eea773cc6d1ef751a6cb023d853cca34cceeb4caac17bdfffd46ccf1a780aaae",
    "posthoc_business_NPC_review.json": "cc9bcb806ef7be6bb10ef24ffb69be3b1f56b39b82f22072192d30bb102c13c7",
    "public_instruction.md": "aa1a082f11deb9ad1cc6eb2409ed235bc07ec91b6f1c80f2e9e7ff53c31297f6",
    "raw_chat.json": "99a1ab30daf6fbfe676c07b6759e9f79486d57fa0ff70098a74e16cdd537cc72",
    "rest_requests.jsonl": "26dd0c62943fd46028c733f65085b0780860a3f877faa500c4c48bb2a7d6739d",
    "reviewed_trace_bundle.json": "d811fc68c2399a264723640a3dcf6b613334637509d47c8fe78a2cb4cd631ee8",
    "run_manifest.json": "948cfd909a5a8d6ec8ee50b7c9373bf8bb815c6d28241d3415de1e9d86ef0700",
    "status.json": "b1480539d573e35e7879a79e68f45c648682e4a31f1f577d612499e1a97eeeaa",
    "tool_events.jsonl": "7f3209ccc03ce67d50975d4a79e7b736c704322afc50d92be9b3479ce3bbacda",
    "trace_bundle.json": "d811fc68c2399a264723640a3dcf6b613334637509d47c8fe78a2cb4cd631ee8",
    "workspace.json": "b2502f3ff6fa4f07845b99775815b5dfa69c8d9f7718997f36d274ad29166017",
    "workspace_events.jsonl": "16452cbfe3cb894de3347b1172ca0e0174f41f69394d45e922910b3fb75a9c3c",
    "workspace\\deliverable.json": "be4b762b952afca27ce3acf678454164f80bfa1cea8b44c275bfb2d38d31c430"
  },
  "reviewer": "nonblind session AI"
}
```

## Binding user-adjudicated scores

```json
null
```