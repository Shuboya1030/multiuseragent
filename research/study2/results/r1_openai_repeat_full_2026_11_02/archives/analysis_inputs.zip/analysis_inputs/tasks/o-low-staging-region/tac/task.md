As of 2026-11-05: Prepare the deployment request for the crawler staging cluster. Save /workspace/deliverable.json with region, instance_type, monthly_usd. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/o-low-staging-region.
OwnCloud: [REDACTED_RUNTIME_ENDPOINT]
RocketChat: [REDACTED_RUNTIME_ENDPOINT]
