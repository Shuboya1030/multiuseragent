As of 2026-11-05: Schedule the nightly embedding batch job. Save /workspace/deliverable.json with start_utc, gpu_type, monthly_usd. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/o-med-batch-schedule.
OwnCloud: [REDACTED_RUNTIME_ENDPOINT]
RocketChat: [REDACTED_RUNTIME_ENDPOINT]
