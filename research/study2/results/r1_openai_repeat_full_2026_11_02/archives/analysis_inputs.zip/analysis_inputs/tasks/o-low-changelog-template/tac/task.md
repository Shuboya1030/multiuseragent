As of 2026-11-05: Prepare the API changelog page for v3.4. Save /workspace/deliverable.json with version, template_id, sections. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/o-low-changelog-template.
OwnCloud: [REDACTED_RUNTIME_ENDPOINT]
RocketChat: [REDACTED_RUNTIME_ENDPOINT]
