As of 2026-11-05: Prepare the catering order for the Search team offsite lunch on 2026-11-18 (22 people). Save /workspace/deliverable.json with headcount, menu, vegetarian_meals, total_usd. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/o-low-team-lunch.
OwnCloud: [REDACTED_RUNTIME_ENDPOINT]
RocketChat: [REDACTED_RUNTIME_ENDPOINT]
