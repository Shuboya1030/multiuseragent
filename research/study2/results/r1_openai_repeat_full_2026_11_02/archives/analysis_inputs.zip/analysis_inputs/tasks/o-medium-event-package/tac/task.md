Prepare the cost sheet for the Harbor customer workshop. Save /workspace/deliverable.json with attendees, package_code and total_usd. Post the file path and total in #engineering.

Work packet: OwnCloud Documents/Study21V2/o-medium-event-package.
OwnCloud: [REDACTED_RUNTIME_ENDPOINT]
RocketChat: [REDACTED_RUNTIME_ENDPOINT]
