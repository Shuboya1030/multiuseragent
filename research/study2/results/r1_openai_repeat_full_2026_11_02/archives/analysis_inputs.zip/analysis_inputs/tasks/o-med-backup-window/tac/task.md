As of 2026-11-05: Configure the nightly backup for the JanusGraph cluster. Save /workspace/deliverable.json with window_utc, retention_days, storage_tb. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/o-med-backup-window.
OwnCloud: [REDACTED_RUNTIME_ENDPOINT]
RocketChat: [REDACTED_RUNTIME_ENDPOINT]
