"""Independent OpenAI repeat/control; approved NPC v6 and shared safeguards."""
import copy
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent
TOP = ROOT.parents[1]
SOURCE_BASE = TOP.parent / "r1_formal"
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT.parent))
import frozen_repair as frozen

rest, batch = frozen.rest, frozen.batch
MINI = "gpt-5.4-mini-2026-03-17"
FULL = "gpt-5.4-2026-03-05"
AUTH = {
    "mini_repeat": "assignment:741f367f-a37b-48de-a57d-1e7bbe84ade4:call_wgIbFW5CYOKVSCanUCeGRXOT",
    "gpt54_control": "assignment:741f367f-a37b-48de-a57d-1e7bbe84ade4:call_7uVxapWXmsSREtrWAn079lA1",
}
CURSOR = Path(
    r"../r1_2026_11_02/provenance/independent"
    r"\r1_two_technical_reruns\frozen_stage\two_runner\stage\service_cursor.json")
batch.BASE = SOURCE_BASE
batch.OLD = SOURCE_BASE.parent / "r1_local_services" / "deployment_20261027"
batch.STAGE = ROOT / "stage"
frozen.pacing.BASE = SOURCE_BASE
BACKEND = frozen.BACKEND
Services = frozen.Services
Http = frozen.Http
stop_check = frozen.stop_check
rest.PRICE_BOOK[FULL] = {"input": 2.50, "output": 15.00, "cached_input": 0.25}


def budget():
    rows = frozen.batch_lines(SOURCE_BASE / "shared_budget" / "cost_ledger.jsonl")
    reserved = {r["id"]: r for r in rows if r["event"] == "reserve"}
    settled = {r["id"]: r for r in rows if r["event"] == "settle"}
    unknown = {k: v for k, v in reserved.items() if k not in settled}
    paid = sum((rest.Decimal(r["amount_usd"]) for r in settled.values()), rest.Decimal(0))
    held = sum((rest.Decimal(r["amount_usd"]) for r in unknown.values()), rest.Decimal(0))
    return {"settled_usd": str(paid), "unknown_reserved_usd": str(held),
            "occupied_usd": str(paid + held), "cap_usd": "20", "unknown": unknown}


class Ledger(frozen.Ledger):
    def settle(self, call, role, usage, bound, maximum):
        if role != "agent" or self.config["agent_model"] != FULL:
            return super().settle(call, role, usage, bound, maximum)
        prompt, completion = usage["prompt_tokens"], usage["completion_tokens"]
        cached = usage.get("prompt_tokens_details", {}).get("cached_tokens", 0)
        rest.require(type(prompt) is int and type(completion) is int and type(cached) is int
                     and 0 <= cached <= prompt <= bound and 0 <= completion <= maximum,
                     "Full model usage out of reserved bounds; retain reservation")
        amount = (rest.Decimal(prompt - cached) * rest.Decimal("2.50")
                  + rest.Decimal(cached) * rest.Decimal("0.25")
                  + rest.Decimal(completion) * rest.Decimal("15.00")) / 1_000_000
        rest.require(amount <= self.charges[call], "Settlement exceeds reservation")
        self.charges[call] = amount
        rest.append(self.path, {"event": "settle", "id": call, "role": role,
                               "amount_usd": str(amount), "usage": usage,
                               "cached_input_tokens": cached, "pricing_model": FULL,
                               "timestamp": rest.timestamp()})


class Model(frozen.Model):
    def complete(self, role, messages, tools=None):
        if role != "agent" or self.config["agent_model"] != FULL:
            return super().complete(role, messages, tools)
        stop_check()
        rest.require(self.config["allow_paid_calls"] is True and self.config["authorization_ref"],
                     "Paid model call disabled")
        request = {"model": FULL, "messages": messages, "max_completion_tokens": 2048,
                   "reasoning_effort": "none", "service_tier": "default", "stream": False}
        if tools:
            request.update(tools=tools, tool_choice="auto", parallel_tool_calls=False)
        call, bound = self.ledger.reserve(role, request)
        rest.append(self.output / "api_io.jsonl", {
            "stage": "request", "call_id": call, "role": role,
            "request": request, "timestamp": rest.timestamp()})
        started = time.monotonic()
        response = self.http.json(
            "POST", "https://api.openai.com/v1/chat/completions",
            {"Authorization": "Bearer " + os.environ[self.config["openai_key_env"]]}, request)
        rest.append(self.output / "api_io.jsonl", {
            "stage": "response", "call_id": call, "role": role, "response": response,
            "timestamp": rest.timestamp(), "latency_s": time.monotonic() - started})
        rest.require(isinstance(response, dict) and isinstance(response.get("usage"), dict),
                     "Missing provider usage; retain reservation")
        rest.require(response.get("service_tier") == "default" and response.get("model") == FULL,
                     "Returned model/tier mismatch; retain reservation")
        self.ledger.settle(call, role, response["usage"], bound, 2048)
        rest.require(isinstance(response.get("choices"), list) and len(response["choices"]) == 1,
                     "Malformed provider choices")
        choice = response["choices"][0]
        rest.require(choice["finish_reason"] in ("stop", "tool_calls"),
                     "Refusal, truncation or unsupported finish")
        message = choice["message"]
        rest.require(isinstance(message, dict) and message.get("role") == "assistant"
                     and not message.get("refusal"), "Malformed/refused assistant response")
        receipt = self.output / "first_actual_agent_request.json"
        if not receipt.exists():
            manifest = rest.load(self.output / "run_manifest.json")
            value = {"episode_id": manifest["episode_id"], "group": "gpt54_control",
                     "task_id": manifest["task_id"], "call_id": call, "model": FULL,
                     "response_model": response["model"], "response_id": response.get("id"),
                     "timestamp": rest.timestamp(), "usage": response["usage"],
                     "real_response_confirmed": True}
            rest.save(receipt, value)
            rest.append(ROOT / "actual_agent_starts.jsonl", value)
            print("FIRST_ACTUAL_AGENT_REQUEST", json.dumps(value), flush=True)
        return {key: message[key] for key in ("role", "content", "tool_calls") if key in message}


def install():
    frozen.install()
    rest.Ledger = Ledger
