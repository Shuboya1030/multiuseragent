"""Nonpaid fixtures only; neither service bootstrap nor generation is called."""
import collections
import copy
import json
import os
from pathlib import Path
import tempfile

import runtime as r
import controller as c


def main():
    r.rest.verify_source()
    scope = r.rest.load(r.TOP / "scope.json")
    assert len(scope) == len({(s["group"], s["task_id"]) for s in scope}) == 90
    assert collections.Counter(s["group"] for s in scope) == {
        "mini_repeat": 30, "gpt54_control": 60}
    for slot in scope:
        assert r.rest.digest(r.rest.ROOT / "templates" / slot["task_id"] / "blueprint.json") \
            == slot["task_blueprint_sha256"]
        slot = {**slot, "attempt_id": "offline-fixture"}
        cfg = c.configuration(slot, r.ROOT / "offline-unused")
        original = r.rest.load(Path(slot["original_run"]) / "run_manifest.json")
        assert all(cfg[k] == original[k] for k in (
            "max_agent_steps", "max_npc_calls", "max_agent_output_tokens",
            "max_npc_output_tokens", "max_input_token_bound"))
        assert (Path(slot["original_run"]) / "public_instruction.md").read_text(encoding="utf-8") == \
            r.rest.public_instruction(
                (r.rest.ROOT / "templates" / slot["task_id"] / "tac" / "task.md").read_text(encoding="utf-8"),
                cfg)
    prefixes = r.rest.load(r.SOURCE_BASE / "final_r1_evaluation_v1" / "freeze.json")["source_hashes"]
    assert all(r.rest.digest(Path(p)) == sha for p, sha in prefixes.items())
    old_v6 = r.CURSOR.parents[1] / "frozen_repair.py"
    assert r.rest.digest(old_v6) == r.rest.digest(r.ROOT / "frozen_repair.py")
    assert not (r.ROOT / "STOP_REQUESTED").exists()
    before = r.budget()
    assert len(before["unknown"]) == 5 and r.rest.Decimal(before["occupied_usd"]) < 20
    with tempfile.TemporaryDirectory(prefix="r1_nonpaid_fixture_") as temporary:
        output = Path(temporary)
        config = c.configuration({**scope[30], "attempt_id": "fixture"}, output)
        config.update(openai_key_env="R1_OFFLINE_FAKE_KEY")
        os.environ["R1_OFFLINE_FAKE_KEY"] = "nonsecret-offline-fixture"
        r.rest.save(output / "first_actual_agent_request.json", {"offline_fixture": True})

        class FakeHTTP:
            request = None

            def json(self, method, url, headers, request):
                assert method == "POST" and url == "https://api.openai.com/v1/chat/completions"
                self.request = copy.deepcopy(request)
                return {"model": r.FULL, "service_tier": "default",
                        "usage": {"prompt_tokens": 1000, "completion_tokens": 10,
                                  "prompt_tokens_details": {"cached_tokens": 400}},
                        "choices": [{"finish_reason": "tool_calls",
                                     "message": {"role": "assistant", "content": None,
                                                 "tool_calls": [{"id": "test", "type": "function",
                                                     "function": {"name": "submit", "arguments": "{}"}}]}}]}

        class FakeLedger:
            def reserve(self, role, request):
                assert role == "agent" and request["model"] == r.FULL
                return "offline-fixture", 32768

            def settle(self, call, role, usage, bound, maximum):
                assert call == "offline-fixture" and maximum == 2048 and bound == 32768

        http = FakeHTTP()
        model = r.Model(config, http, FakeLedger(), output)
        first = next(x for x in r.frozen.batch_lines(
            Path(scope[0]["original_run"]) / "api_io.jsonl")
                     if x["stage"] == "request" and x["role"] == "agent")["request"]
        model.complete("agent", first["messages"], first["tools"])
        expected = {**copy.deepcopy(first), "model": r.FULL}
        assert http.request == expected, "Full GPT route must differ from original mini wire only by model"
        ledger_path = output / "local-only-ledger.jsonl"
        ledger = r.Ledger(ledger_path, config)
        ledger.charges["fixture"] = r.rest.Decimal("0.1")
        ledger.settle("fixture", "agent",
                      {"prompt_tokens": 1000, "completion_tokens": 10,
                       "prompt_tokens_details": {"cached_tokens": 400}}, 32768, 2048)
        assert r.frozen.batch_lines(ledger_path)[0]["amount_usd"] == "0.00175"
        os.environ.pop("R1_OFFLINE_FAKE_KEY")
    assert r.budget() == before
    history = r.rest.load(r.SOURCE_BASE / "final_r1_evaluation_v1" / "all_attempt_evaluations.json")["attempts"]
    repairs = [a for a in history if a["provider"] == "openai" and a["attempt_order"] > 0]
    assert len(repairs) == 4 and all(a["task_id"].startswith("m-") for a in repairs)
    r.rest.save(r.ROOT / "offline_validation.json", {
        "passed": True, "timestamp": r.rest.timestamp(),
        "runtime_sha256": r.rest.digest(r.ROOT / "runtime.py"),
        "controller_sha256": r.rest.digest(r.ROOT / "controller.py"),
        "authorized_scope": {"mini_repeat": 30, "gpt54_control": 60},
        "immutable_source_hashes_verified": len(prefixes), "original_task_instructions_and_limits_verified": 90,
        "full_wire_diff_from_original_mini": ["model"],
        "full_cached_input_pricing_fixture_passed": True,
        "shared_ledger_untouched": True, "external_or_paid_calls": 0,
        "historical_openai_repair_tasks": [a["task_id"] for a in repairs],
        "after_one_repeat_attempt_count": {"original_plus_repeat_only": 26,
                                          "original_plus_targeted_repair_plus_repeat": 4},
        "historical_NPC_condition_not_identical_to_new_v6": True,
        "plan_A_literal_search": "No literal 方案A / Option A / Plan A in existing r1_formal Markdown; "
                                 "user's explicit v6/same-prompt/64-step/R1 configuration applied.",
        "R_prime_computed": False})
    r.rest.save(r.ROOT / "budget_projection.json", {
        "before": before, "remaining_usd": str(r.rest.Decimal(20) - r.rest.Decimal(before["occupied_usd"])),
        "reservation_upper_bound_per_agent_call_usd": {"mini": "0.033792", "full": "0.112640"},
        "reservation_upper_bound_per_NPC_call_usd": "0.029184",
        "90_episodes_all_64_agent_and_64_NPC_requests_upper_bound_usd": "665.518080",
        "this_worst_case_is_not_fundable_under_current_cap": True,
        "policy": "No extra budget authorized. Each actual call reserves worst case against the same USD20 "
                  "historical ledger. Stop before any call that cannot be reserved; do not lower limits.",
        "forecast": "Historical mini Must mostly made no contacts; not a reliable full-model turn-count forecast.",
        "full_price_source": "https://developers.openai.com/api/docs/models/gpt-5.4",
        "full_prices_per_M": {"uncached_input": "2.50", "cached_input": "0.25", "all_completion": "15.00"},
        "mini_NPC_prices_unchanged": r.rest.PRICE_BOOK[r.MINI]})
    print("Nonpaid validation passed: 90 unchanged tasks/limits, full wire parity, correct cached pricing, "
          f"{len(prefixes)} original source hashes, v6 exact, no external/model/service calls.")


if __name__ == "__main__":
    main()
