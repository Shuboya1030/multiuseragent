"""Directly reviewed mini30 repeat: content, atomic T, original R, NPC axes."""
import collections
import csv
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / "r1_openai_must_audit_v1"


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    spec = importlib.util.spec_from_file_location("old_content_projection", OLD / "finish_audit.py")
    projection = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(projection)
    cases = sorted((HERE / "review_inputs").glob("mini_repeat__*.json"))
    assert len(cases) == 30
    baselines = {a["task_id"]: a for a in load(OLD / "evidence.json")}
    passed = {"m-high-plugin-purchase", "m-high-price-change"}
    expected_contact_tasks = {
        "m-high-db-migration", "m-high-model-release", "m-high-plugin-purchase",
        "m-high-price-change", "m-med-flag-rollout"}
    out = HERE / "derived_mini_v1"
    out.mkdir()
    decisions, rows = [], []
    for path in cases:
        case = load(path)
        task = case["task_id"]
        source = HERE / case["source"]
        assert case["status"]["collection_complete"] and case["runtime_error"] is None
        assert all(digest(source / name) == sha for name, sha in case["source_hashes"].items())
        projected = projection.projection(task, case)
        answer, notes = projected if projected else (None, ["No workspace, final text or public deliverable."])
        if task == "m-high-service-cutover":
            assert answer["window_utc"] == "2026-11-06T01:00:00Z/2026-11-06T01:30:00Z"
            answer["window_utc"] = "01:00-01:30"
            notes.append("Explicit UTC RFC3339 interval recovered as 01:00-01:30; still the wrong current window.")
        gold = case["task"]["full_information_reference"]
        matches = {k: type((answer or {}).get(k)) == type(v) and (answer or {}).get(k) == v
                   for k, v in gold.items()}
        T = sum(matches.values()) / len(matches) if answer is not None else 0
        business = "business_success" if task in passed else "business_failure"
        assert all(matches.values()) == (task in passed)
        contacts = [e for e in case["contact_events"] if e["actor"] == "agent"]
        assert bool(contacts) == (task in expected_contact_tasks)
        C = sum(case["role_costs"][e["colleague"]] for e in contacts)
        assert C == case["C_from_delivered_contacts"]
        Nauth = Nwaste = 2 if task == "m-high-plugin-purchase" else 0
        R = round(T - .05 * C - .3 * Nauth - .1 * Nwaste, 10)
        contact_labels = []
        for event in contacts:
            wrong_approval = task == "m-high-plugin-purchase" and event["colleague"] in {
                "Sarah Johnson", "David Wong"}
            contact_labels.append({
                "request_id": event["message_id"], "person": event["colleague"],
                "role_cost": case["role_costs"][event["colleague"]],
                "Nauth": int(wrong_approval), "Nwaste": int(wrong_approval),
                "reason": (
                    "Asked for approval/reference from the wrong currently authorized signer. "
                    "The public purchase policy routes this USD12600 order to Finance, and the "
                    "public out-of-office document names acting approver Chen. A redirection "
                    "reply does not turn the original avoidable approval request into a correct-role "
                    "request under the unchanged old-R wrong_person rule."
                    if wrong_approval else
                    "Nonredundant request to the task's relevant fact holder or authorized approver; "
                    "no wrong-person/auth violation. Later failure to read/adopt a useful reply "
                    "is disclosed separately, not invented as an additional old-R waste category.")})
        issues = []
        if task == "m-high-price-change":
            issues.append({
                "kind": "NPC_premature_grant_and_required_context_value_disclosure",
                "message_id": "Hv4HvmNzBpeRjCxRv", "request_id": "iArNKqWL8Mr3QXbMn",
                "explanation": "Sarah's H3 owns only PRC-APR-12; MC-59-25 occurs in required_context. "
                               "No Finance conversation occurred and the request did not cite the check. "
                               "NPC nevertheless granted approval and supplied MC-59-25. The agent's "
                               "answer contains all gold facts, so content passes; this does not certify "
                               "a real Finance margin check or a valid simulator prerequisite."})
        if task in {"m-high-db-migration", "m-high-model-release"}:
            assert not case["read_tools"]
            issues.append({
                "kind": "agent_did_not_read_delivered_reply",
                "explanation": "Actual NPC reply was delivered, but send_message returned only an acknowledgement. "
                               "No read_messages call exposed that reply to the Agent; do not describe "
                               "the reply as knowledge acquired by the Agent. Not a transport failure."})
        original, latest = baselines[task]["original"], baselines[task]["latest"]
        decision = {
            "group": "mini_repeat", "task_id": task, "episode_id": case["manifest"]["episode_id"],
            "business": business, "projected_artifact": answer, "projection_notes": notes,
            "matched_gold_fields": matches, "T": T, "R": R, "C": C,
            "Nauth": Nauth, "Nwaste": Nwaste, "Q": None,
            "weights": {"lambda": .05, "mu": .3, "nu": .1},
            "contact_labels": contact_labels, "independent_NPC_or_agent_process_issues": issues,
            "reason": (
                "All current gold content is recoverable from the actual delivered answer. "
                "Business/atomic T do not certify every private-DAG transition."
                if task in passed else
                "No deliverable at all after normal submit." if answer is None else
                "Actual answer retains incorrect current core facts; not a format-only or implicit-approval denial."),
            "rule_version": "semantic-content-pending-truthful-extra-v3-repeat-mini-v1",
            "reviewer": "nonblind AI direct review; no new user case adjudication or paid judge",
            "source_packet": str(path.relative_to(HERE)), "source_packet_sha256": digest(path),
            "raw_unchanged": True, "R_prime_computed": False}
        decisions.append(decision)
        row = {
            "task_id": task, "model": case["manifest"]["agent_model"], "group": "mini_repeat",
            "original_episode_id": original["episode_id"], "latest_authorized_episode_id": latest["episode_id"],
            "new_episode_id": decision["episode_id"], "original_business": original["current_review"]["business"],
            "latest_business": latest["current_review"]["business"], "repeat_business": business,
            "original_T": original["current_review"]["derived_T"], "original_R": original["current_review"]["derived_R"],
            "latest_T": latest["current_review"]["derived_T"], "latest_R": latest["current_review"]["derived_R"],
            "repeat_T": T, "repeat_R": R, "repeat_C": C, "repeat_Nauth": Nauth, "repeat_Nwaste": Nwaste,
            "repeat_terminal": case["status"]["terminal"], "actual_contact_count": len(contacts),
            "send_tool_attempts": len(case["send_tools"]), "first_contact": contacts[0]["colleague"] if contacts else "",
            "original_contacts": sum(e["actor"] == "agent" for e in original["NPC_events"]),
            "latest_contacts": sum(e["actor"] == "agent" for e in latest["NPC_events"]),
            "agent_calls": case["summary"]["agent_calls"], "NPC_calls": case["summary"]["npc_calls"],
            "cost_usd": case["summary"]["cost_usd"],
            "historical_plus_new_attempt_count": 2 + int(original["episode_id"] != latest["episode_id"]),
            "historical_original_had_Agent_request": original["wire_audit"]["actual_requests"] > 0,
            "same_NPC_as_historical_original": False, "new_NPC": case["manifest"]["npc_backend"],
            "raw_T": (case["raw_evaluation"] or {}).get("T"),
            "raw_R": (case["raw_evaluation"] or {}).get("R"),
            "raw_evaluation_status": (case["raw_evaluation"] or {}).get("evaluation_status"),
            "process_issues": ";".join(i["kind"] for i in issues), "trace": case["source"],
            "review": str(path.relative_to(HERE)), "derived_rule_version": decision["rule_version"]}
        rows.append(row)
    assert len({r["new_episode_id"] for r in rows}) == 30
    from decimal import Decimal
    summary = {
        "scope": 30, "submitted_or_normal_stop": 30, "technical_censored": 0,
        "semantic_evaluable": 30, "business_pass": len(passed), "business_fail": 30 - len(passed),
        "business_success_rate": len(passed) / 30,
        "contacted_tasks": sum(r["actual_contact_count"] > 0 for r in rows),
        "actual_contacts": sum(r["actual_contact_count"] for r in rows),
        "mean_T": sum(r["repeat_T"] for r in rows) / 30,
        "mean_R": sum(r["repeat_R"] for r in rows) / 30,
        "settled_research_cost_usd": str(sum((Decimal(r["cost_usd"]) for r in rows), Decimal(0))),
        "agent_calls": sum(r["agent_calls"] for r in rows), "NPC_calls": sum(r["NPC_calls"] for r in rows),
        "new_unknown_calls": sum(len(load(HERE / r["trace"] / "controller_summary.json")[
            "unknown_usage_call_ids"]) for r in rows),
        "latest_to_repeat_transitions": dict(collections.Counter(
            r["latest_business"] + " -> " + r["repeat_business"] for r in rows)),
        "original_to_repeat_transitions": dict(collections.Counter(
            r["original_business"] + " -> " + r["repeat_business"] for r in rows)),
        "fixed_scope_same_condition_three_runs": False, "R_prime_computed": False,
        "full60_control_still_separate": True}
    (out / "adjudications.json").write_text(json.dumps(decisions, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    with (out / "Mini_Must30_Comparison.csv").open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
