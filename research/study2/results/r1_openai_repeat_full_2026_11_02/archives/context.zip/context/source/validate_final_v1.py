"""Verify all ninety offline evaluations, actual wires and shared settlements."""
import collections
import csv
import hashlib
import json
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUNNER = ROOT / "frozen_stage" / "runner"


def load(p):
    return json.loads(p.read_text(encoding="utf-8-sig"))


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def lines(p):
    return [json.loads(s) for s in p.read_text(encoding="utf-8").splitlines() if s]


def main():
    scope = load(ROOT / "scope.json")
    all_decisions = load(ROOT / "derived_mini_v1" / "adjudications.json") + load(
        ROOT / "derived_full_v1" / "adjudications.json")
    decisions = {(a["group"], a["task_id"]): a for a in all_decisions}
    assert len(scope) == len(decisions) == len({a["episode_id"] for a in all_decisions}) == 90
    ledger_path = ROOT.parent / "r1_formal" / "shared_budget" / "cost_ledger.jsonl"
    ledger = lines(ledger_path)
    reserved = {v["id"]: v for v in ledger if v["event"] == "reserve"}
    settled = {v["id"]: v for v in ledger if v["event"] == "settle"}
    baseline = load(RUNNER / "baseline.json")
    assert set(reserved) - set(settled) == set(baseline["budget"]["unknown"])
    assert len(set(reserved) - set(settled)) == 5
    group_costs = collections.defaultdict(Decimal)
    counts = collections.Counter()
    all_calls, first_wires, evidence = set(), {}, {}
    for slot in scope:
        key = slot["group"], slot["task_id"]
        decision = decisions[key]
        packet_path = ROOT / decision["source_packet"]
        assert digest(packet_path) == decision["source_packet_sha256"]
        case = load(packet_path)
        source = ROOT / case["source"]
        assert case["manifest"]["episode_id"] == decision["episode_id"]
        assert case["status"]["collection_complete"] and case["runtime_error"] is None
        assert all(digest(source / name) == sha for name, sha in case["source_hashes"].items())
        assert case["public_instruction"].split("\n\nWork packet:")[0] == case["task"]["prompt"]
        api = lines(source / "api_io.jsonl")
        requests = [a for a in api if a["stage"] == "request"]
        responses = {a["call_id"]: a for a in api if a["stage"] == "response"}
        assert len(requests) == len(responses)
        prior_messages = None
        episode_cost = Decimal(0)
        for request in requests:
            call, role, wire = request["call_id"], request["role"], request["request"]
            assert call not in all_calls and call in reserved and call in settled
            all_calls.add(call)
            response = responses[call]["response"]
            expected_model = "gpt-5.4-2026-03-05" if (
                slot["group"] == "gpt54_control" and role == "agent") else "gpt-5.4-mini-2026-03-17"
            assert wire["model"] == response["model"] == expected_model
            usage = response["usage"]
            assert response["choices"][0]["finish_reason"] in ("stop", "tool_calls")
            assert usage.get("completion_tokens_details", {}).get("reasoning_tokens", 0) == 0
            prompt, completion = usage["prompt_tokens"], usage["completion_tokens"]
            cached = usage.get("prompt_tokens_details", {}).get("cached_tokens", 0)
            if expected_model == "gpt-5.4-2026-03-05":
                amount = (Decimal(prompt - cached) * Decimal("2.50") +
                          Decimal(cached) * Decimal(".25") + Decimal(completion) * 15) / 1000000
            else:
                amount = (Decimal(prompt) * Decimal(".75") +
                          Decimal(completion) * Decimal("4.5")) / 1000000
            assert Decimal(settled[call]["amount_usd"]) == amount
            assert amount <= Decimal(reserved[call]["amount_usd"])
            episode_cost += amount
            counts[slot["group"] + "_" + role] += 1
            if role == "agent":
                assert wire["reasoning_effort"] == "none"
                assert wire["max_completion_tokens"] == 2048
                assert wire["tool_choice"] == "auto" and wire["parallel_tool_calls"] is False
                assert len(wire["tools"]) == 8 and "temperature" not in wire and "seed" not in wire
                if prior_messages is not None:
                    assert wire["messages"][:len(prior_messages)] == prior_messages
                    assert len(wire["messages"]) > len(prior_messages)
                else:
                    first_wires[key] = wire
                prior_messages = wire["messages"]
        assert Decimal(case["summary"]["cost_usd"]) == episode_cost
        assert not case["summary"]["unknown_usage_call_ids"]
        group_costs[slot["group"]] += episode_cost
        contacts = [e for e in case["contact_events"] if e["actor"] == "agent"]
        assert decision["C"] == sum(case["role_costs"][e["colleague"]] for e in contacts)
        assert abs(decision["R"] - (decision["T"] - .05 * decision["C"]
                   - .3 * decision["Nauth"] - .1 * decision["Nwaste"])) < 1e-9
        evidence[decision["episode_id"]] = {
            "group": key[0], "task_id": key[1],
            "source_packet_sha256": digest(packet_path),
            "source_files_checked": len(case["source_hashes"]),
            "requests_settled": len(requests),
        }
    for key, wire in first_wires.items():
        if key[0] == "mini_repeat":
            full = first_wires["gpt54_control", key[1]]
            assert {k: v for k, v in wire.items() if k != "model"} == {
                k: v for k, v in full.items() if k != "model"}
    assert group_costs["mini_repeat"] == Decimal(".30682500")
    assert group_costs["gpt54_control"] == Decimal("2.19931925")
    assert len(all_calls) == 933
    assert all(digest(Path(p)) == sha for p, sha in baseline["source_hashes"].items())
    for p, prefix in baseline["shared_prefixes"].items():
        assert hashlib.sha256(Path(p).read_bytes()[:prefix["bytes"]]).hexdigest() == prefix["sha256"]
    total_paid = sum((Decimal(v["amount_usd"]) for v in settled.values()), Decimal(0))
    unknown = sum((Decimal(reserved[k]["amount_usd"]) for k in set(reserved) - set(settled)), Decimal(0))
    assert total_paid == Decimal("7.32870910")
    assert unknown == Decimal(".11172275") and total_paid + unknown < 20
    assert load(RUNNER / "completion.json")["all_90_terminal"]
    assert load(RUNNER / "controller.finished.json")["pid"] == 33744
    assert not (RUNNER / "controller.lock").exists()
    with (ROOT / "derived_full_v1" / "GPT54_Full60_Comparison.csv").open(
            encoding="utf-8-sig", newline="") as file:
        rows = list(csv.DictReader(file))
    assert len(rows) == len({r["new_episode_id"] for r in rows}) == 60
    assert sum(r["full_business"] == "business_success" for r in rows) == 50
    result = {
        "passed": True, "scope_unique_attempts": 90, "semantic_reviews": 90,
        "full_reviews": 60, "mini_reviews": 30, "new_unsettled_calls": 0,
        "settled_calls": len(all_calls), "call_counts": dict(counts),
        "group_costs_usd": {k: str(v) for k, v in group_costs.items()},
        "global_settled_usd": str(total_paid), "historical_unknown_count": 5,
        "historical_unknown_usd": str(unknown), "global_occupied_usd": str(total_paid + unknown),
        "all_wire_models_history_parameters_verified": True,
        "all_thirty_first_wires_only_model_differs": True,
        "original_source_hashes_preserved": len(baseline["source_hashes"]),
        "historical_pacer_ledger_prefixes_preserved": True,
        "controller_finished_lock_released": True,
        "R_prime_computed": False,
        "reference_scoring_gaps": 0,
        "dataset_validity_caveat": "o-high-eval-budget optimized GPU hours are underdetermined",
    }
    (ROOT / "derived_full_v1" / "validation.json").write_text(json.dumps(result, indent=2))
    (ROOT / "derived_full_v1" / "source_verification.json").write_text(json.dumps(evidence, indent=2))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
