"""Preserve local research definitions needed for later offline R-prime work."""
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
RESEARCH = Path.cwd() / "research" / "study2" / "task_generation_v2"
OLD = HERE.parent / "r1_formal" / "final_r1_evaluation_v1"


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    destination = HERE / "analysis_inputs"
    destination.mkdir()
    scope = load(HERE / "scope.json")
    old_attempts = load(OLD / "all_attempt_evaluations.json")["attempts"]
    sources = {}
    source_files = {}
    for task in sorted({s["task_id"] for s in scope}):
        root = RESEARCH / "templates" / task
        out = destination / "tasks" / task
        out.mkdir(parents=True)
        original = next(a for a in old_attempts if a["provider"] == "openai"
                        and a["task_id"] == task and a["attempt_order"] == 0)
        packet = load(OLD / original["packet"])
        (out / "task_definition.json").write_text(json.dumps(packet["task"], ensure_ascii=False, indent=2),
                                                encoding="utf-8")
        for path in [root / "blueprint.json", root / "metadata.json", root / "tac" / "task.md",
                     *(root / "tac" / "documents_R1").glob("*.md"),
                     *(root / "tac" / "grading").glob("*.json"), root / "tac" / "evaluator.py"]:
            if not path.is_file():
                continue
            relative = path.relative_to(root)
            target = out / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)
            assert sha(path) == sha(target)
            source_files[str(target.relative_to(destination))] = sha(target)
        assert sha(out / "blueprint.json") == packet["manifest"]["task_blueprint_sha256"]
        sources[task] = {
            "task_definition_source": str(Path(original["packet"]).as_posix()),
            "original_episode_id": original["episode_id"], "instance_seed": packet["manifest"]["instance_seed"],
            "blueprint_sha256": sha(out / "blueprint.json"),
            "costs_sha256": sha(out / "tac" / "grading" / "costs.json"),
            "directory_sha256": sha(out / "tac" / "documents_R1" / "directory.md"),
            "meaning": "Synthetic research task facts/roles, not real account credentials."}
    for folder in ("grading", "organization"):
        for path in (RESEARCH / folder).rglob("*"):
            if path.is_file() and path.suffix in (".py", ".json", ".md", ".csv"):
                target = destination / folder / path.relative_to(RESEARCH / folder)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(path, target)
                source_files[str(target.relative_to(destination))] = sha(target)
    (destination / "index.json").write_text(json.dumps({
        "task_count": len(sources), "tasks": sources, "copied_source_hashes": source_files,
        "task_and_grader_sources_readonly": True, "R_prime_computed": False,
        "source_published_commit": "823a12ae733ff790dd6910d6423c49731dc694ac",
        "new_episode_join": ["group", "task_id", "episode_id", "original_episode_id"],
        "conversation_evidence": [
            "api_io.jsonl", "tool_events.jsonl", "trace_bundle.json", "raw_chat.json",
            "account_map.json", "run_manifest.json", "workspace.json", "npc_inputs.jsonl"],
        "note": "The last name is optional; full NPC messages and records are also in api_io.jsonl. "
                "Do not infer approval solely from a reference or a private DAG."},
        ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Preserved all {len(sources)} task definitions and {len(source_files)} source files; no service/API calls.")


if __name__ == "__main__":
    main()
