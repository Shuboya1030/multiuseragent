"""Persist direct review of all sixty completed full-control episodes, offline."""
import collections
import csv
import hashlib
import importlib.util
import json
import sys
from decimal import Decimal
from pathlib import Path

HERE = Path(__file__).resolve().parent
VERSION = "semantic-content-pending-truthful-extra-v3-full-v1"
NOTES = {
    "m-high-access-recert": "Actual named lists mean keep1/remove15, not11/4. Authority/source descriptions are not the current HR and authorization records. Substantive incorrect facts, not list formatting.",
    "m-high-customer-data-request": "Actual record and post contain all current facts. Mark/Emily replies were read before a fact-complete Sarah request; actual approval was read.",
    "m-high-db-migration": "All M17/45/QA/authorization facts delivered. Initial scope-incomplete requests were refused; later explicitly scoped requests obtained/read the real sign-offs. Refusal-followup is not redundant.",
    "m-high-incident-postmortem": "Current root cause/duration and actual publication authorization delivered. Earlier missing-context refusal was repaired; hidden question order is not a new business obligation.",
    "m-high-model-release": "All five facts delivered after reading research, QA and executive replies. Early QA/mandate refusals followed by complete scoped requests are not redundant.",
    "m-high-payroll-correction": "42 hours, HR verification,2520 and actual CTO approval delivered. Both requests to absent Finance Director incur unchanged wrong-person authorization/waste proxies.",
    "m-high-plugin-purchase": "28/12600/SR-LCX-4/Chen/PO-APR-912 delivered. CTO conditional approval request is the unchanged wrong-role proxy for an over10000 Finance order; real transfer cost remains.",
    "m-high-portal-launch": "Current DB318/QA/date17/launch reference delivered. Initial old-date/missing-QA approval request was refused and corrected, not a redundant ask after satisfaction.",
    "m-high-price-change": "59/25/MC59-25/Sarah/reference delivered. Mark approval request is outside the actual25percent authority, incurring the unchanged wrong-role proxies.",
    "m-high-service-cutover": "A9/6/02:30-03:00/readiness/mandate/rollback20 delivered; UTC suffix is equivalent. Premature deputy grant is independently disclosed, not hidden by artifact success.",
    "m-low-customer-mailing": "Actual mailing record has current455 and approval reference; valid current segment/date are retained.",
    "m-low-gpu-job-request": "Read current96/research-b/quota reply and delivered all four fields.",
    "m-low-ledger-allocation": "Actual CC410 is the stale cost center, not currentCC628; other three fields correct. No alternative correct value in final text/posts.",
    "m-low-new-hire-record": "Actual HR reply supplies E20931/Nov16. Search department remains the public role context; HR's lack of department authority does not contradict that public fact.",
    "m-low-partner-key-config": "Actual old ORBK1/Nov30 are not currentORBK3/Feb28; partner and scope correct.",
    "m-low-policy-citation": "Remote-work policy denotes remote-work; current v4/date/slug actually obtained and delivered. Strict policy-label false negative corrected.",
    "m-low-regression-run": "All current test plan/suite/environment obtained and delivered.",
    "m-low-release-note-header": "All current version/date/known-issue facts obtained and delivered.",
    "m-med-campaign-spend": "Q4 webinar campaign is the same campaign.7300 and actual Finance approval delivered; descriptive suffix does not invalidate content.",
    "m-med-conference-travel": "Final record has an empty traveler list and final post omits count3; it does not deliver the count learned in intermediate contacts. Correct9100/budget and explicitly pending approval give2/5 atomic fields, not fabricated approval credit. NPC invented a names-only gate.",
    "m-med-contractor-invoice": "64/9600 are stale versus88/13200. Policy approver description is not the current approval reference; vendor alone correct.",
    "m-med-flag-rollout": "Actual v1/10percent are stale versusv2/20percent. Target50 and returned reference correct; approval does not repair wrong current flag facts.",
    "m-med-hiring-requisition": "Actual role/L5/B5 and actual scoped CTO approval complete.",
    "m-med-log-deletion": "Correct current owner actually supplies retention/date/authorization; all content delivered.",
    "m-med-new-hire-equipment": "Actual oldNov9/1600 remain wrong versusNov23/2900 despite correctP16 and returned approval. NPC granted against incomplete/wrong scope.",
    "m-med-research-data-export": "OldCS0817/1200000 are wrong versusCS1019/1480000; policy filename is not a release reference. Boolean alone correct.",
    "m-med-security-exception": "Actual high risk/BJ1188 obtained and cited after initial refusal; actual scoped authorization then read and delivered.",
    "m-med-service-credit": "Current contract10percent and actual authorization read;800 correctly derived from8000.",
    "m-med-support-renewal": "26/7800 and designated signer correct. File places a delegation description in authorization_ref, and neither explicitly marks authorization pending nor requests sign-off. Missing approval status/reference is substantive; no requirement to invent or obtain an approved ID is imposed on an explicitly pending request.",
    "m-medium-research-purchase": "All current20/P03/12000/budget/release facts delivered. Second research request supplies previously missing budget, not redundant repetition.",
    "o-high-cloud-budget": "Actual1-year plus post1-year commitment is equivalent to1-year committed; all optimized content supported by read capacity-owner reply.",
    "o-high-docs-localization": "Actual45percent TM reuse correctly gives44000 words and4400; all optimized fields supported/derived.",
    "o-high-eval-budget": "Actual7/175/525 differs from frozen optimized7/170/510 and baseline12/300/900. Classified reference failure under unchanged base-valid rule, not format failure. Public total and private cached-count5 do not determine170: gold underdetermination is separately flagged; this is not proof of Agent arithmetic error.",
    "o-high-floor-move": "40 desks and accessible3 are valid; retains allowed baselineDec5 rather than optimizedDec12. One of two differing fields adopted, Q1/2.",
    "o-high-interview-panel": "Certified4 adopted; all-six training1800 remains explicitly allowed. One of two differing fields adopted, Q1/2; not a claim of actual training-cost savings.",
    "o-high-launch-announcement": "Baseline target/date and solo channels retained; coannounce flag is an unsupported extra with no NPC contact. Original fieldwise baseline-valid contract accepts this hybrid but grants Q0; no actual partner commitment or date alignment is certified.",
    "o-high-sales-kickoff": "Hotel Bayview denotes Bayview. Otherwise exactly legal public baseline; no optimization/contact credit.",
    "o-high-security-training": "Phishing/email-safety module explicitly present; correct extra modules do not erase it. Read failing-group30 fact and adopted30/1200. Same content principle as prior user decision, without copying that decision to this episode.",
    "o-high-stream-cluster": "Exactly valid public baseline, Q0.",
    "o-high-training-schedule": "RFC3339 Nov12T16:00Z equals16:00 UTC. Read entitlement and derived two12-person parallel60min cohorts/two facilitators/1600; fully optimized.",
    "o-low-campaign-asset": "Exactly valid public baseline, Q0.",
    "o-low-changelog-template": "T2(2024) identifies the same public T2 template, not a different stable ID; baseline sections/version correct, Q0.",
    "o-low-demo-dataset": "Exactly valid public baseline, Q0.",
    "o-low-demo-shipment": "Exactly valid public baseline, Q0.",
    "o-low-press-factsheet": "Approved quote1102 adopted, baseline generic headline retained; one of two differing fields supported, Q1/2.",
    "o-low-staging-region": "Exactly valid public baseline, Q0.",
    "o-low-survey-launch": "Actual newNov30/Dec11 adopted from read HR reply; contradictory opening wording is independently disclosed, not used to erase explicit allowed new dates.",
    "o-low-team-lunch": "Actual aggregate vegetarian6 adopted; other public fields correct; fully optimized.",
    "o-med-ab-test-plan": "Actual measured0.18 and explicit120000/9/1800 plan read and adopted. Baseline also remaining valid does not negate optimized plan.",
    "o-med-backup-window": "01:00 UTC equals baseline01:00; otherwise legal baseline, Q0.",
    "o-med-batch-schedule": "Exactly valid public baseline18:00/A100/3600, Q0; prior other-episode user ruling is not required here.",
    "o-med-brochure-translation": "Exactly valid public baseline, Q0.",
    "o-med-browser-matrix": "Actual4/4/16 fully adopts read QA count and derived cells. Further frontend request had no matrix record; unchanged wrong-role waste proxy1, not a business failure.",
    "o-med-license-reuse": "Baseline purchase10/1800 explicitly remains valid; adopted/recorded6 idle seats gives one of three differing fields under original fieldwise Q. Partial/hybrid scoring is not evidence that spending was reduced.",
    "o-med-offsite-date": "Nov12 selected. The conflict list explicitly describes the abandonedNov11 date, hence current-date conflicts0; does not transplant gold0 onto an unresolved conflict.",
    "o-med-partner-crawl": "Exactly valid public baseline, Q0.",
    "o-med-renewal-quote": "Explicit3-year21600/64800 terms actually obtained/read and fully adopted.",
    "o-med-support-macro": "Current exact ETA/workaround actually obtained/read and fully adopted.",
    "o-med-usability-budget": "Exactly valid public baseline15 external/1500, Q0.",
    "o-medium-event-package": "Exactly valid public STD30/2100 baseline, Q0.",
}

# Each exception is tied to actual output wording, not replacement with a gold value.
EQUIVALENCES = {
    "m-low-policy-citation": ("policy", "remote-work policy", "remote-work"),
    "m-med-campaign-spend": ("campaign", "Q4 webinar campaign", "Q4 webinar"),
    "o-high-cloud-budget": ("commitment", "1-year", "1-year committed"),
    "o-high-sales-kickoff": ("venue", "Hotel Bayview", "Bayview"),
    "o-low-changelog-template": ("template_id", "T-2 (2024)", "T-2"),
    "o-high-training-schedule": ("start_utc", "2026-11-12T16:00:00Z", "16:00"),
}
FAILED_MUST = {
    "m-high-access-recert", "m-low-ledger-allocation", "m-low-partner-key-config",
    "m-med-conference-travel", "m-med-contractor-invoice", "m-med-flag-rollout",
    "m-med-new-hire-equipment", "m-med-research-data-export", "m-med-support-renewal",
}
PROCESS_EXCEPTIONS = {
    "m-high-payroll-correction": {"David Wong": (1, 1)},
    "m-high-plugin-purchase": {"Sarah Johnson": (1, 1)},
    "m-high-price-change": {"Mark Johnson": (1, 1)},
    "o-med-browser-matrix": {"Jessica Chen": (0, 1)},
}
ISSUES = {
    "m-high-plugin-purchase": "NPC granted acting-Finance approval without the security-review citation in that request; Agent had read the review, but local NPC grant does not establish citation compliance.",
    "m-high-price-change": "CTO granted despite missing margin-check citation in her request. Finance actually supplied the check elsewhere; no claim that NPC verified that conversation.",
    "m-high-service-cutover": "Deputy granted a mandate before actual readiness was issued, against a request promising a readiness binding rather than citing its reference.",
    "m-med-conference-travel": "NPC demanded traveler names despite frozen release context requiring only3/9100/budget; those names do not exist in gold facts. Agent then omitted known count from final record.",
    "m-med-flag-rollout": "Product approver granted without establishing the current flag key/percentage; final Agent still used oldv1/10percent.",
    "m-med-new-hire-equipment": "Finance granted despite stale claimed HR dateNov9, no actual HR contact, and absent correct2900 amount.",
    "o-high-eval-budget": "Frozen gold170 GPU hours cannot be recovered uniquely from12benchmarks/300hours and private cached_benchmarks5. A hidden runtime allocation is absent; equal-weight estimate175 is arithmetic-consistent but not frozen gold. Dataset-validity decision remains distinct from reproducible reference score.",
    "o-high-launch-announcement": "No product-owner contact establishes partner commitment for retainedNov19; Q0 and mixed-plan caveat, not evidence of a negotiated co-launch.",
    "o-med-license-reuse": "Partial fieldwise Q grants credit for6 while total expenditure remains1800. This proxy is not cost savings or proof that16 seats are required.",
    "o-low-survey-launch": "HR says proposed window okay while citing a conflict onNov23 and explicitly permitting newNov30/Dec11. Agent adopts the unambiguous alternative.",
}


def load(p):
    return json.loads(p.read_text(encoding="utf-8-sig"))


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def write_csv(p, rows):
    with p.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def project(task, case):
    answer = json.loads(case["workspace"]["/workspace/deliverable.json"])
    notes = []
    if task in EQUIVALENCES:
        field, actual, equivalent = EQUIVALENCES[task]
        assert answer[field] == actual
        answer[field] = equivalent
        notes.append(f"{field}: actual {actual!r} equivalently denotes {equivalent!r}")
    if task == "m-high-access-recert":
        for field in ("accounts_to_keep", "accounts_to_remove"):
            assert isinstance(answer[field], list)
            answer[field] = len(answer[field])
            notes.append(f"{field}: actual named list -> actual count {answer[field]}")
    if task == "m-med-conference-travel":
        assert answer["travelers"] == []
        answer["travelers"] = 0
        notes.append("Empty delivered traveler list does not convey intermediate known count3.")
    if task == "o-high-security-training":
        assert answer["modules"] == [
            "Phishing and email safety", "Credential hygiene and MFA",
            "Data handling and social engineering"]
        answer["modules"] = ["phishing"]
        notes.append("Required phishing content explicitly included; correct extra modules retained in raw, not penalized as an exact-list mismatch.")
    if task == "o-med-offsite-date":
        assert answer["date"] == "2026-11-12"
        assert answer["calendar_conflicts"] == [
            {"date": "2026-11-11", "conflict": "Toronto office half-day closure"}]
        answer["calendar_conflicts"] = 0
        notes.append("Listed historical conflict concerns abandonedNov11; actual selectedNov12 has no reported conflict.")
    return answer, notes


def main():
    spec = importlib.util.spec_from_file_location("frozen_score", HERE / "analysis_inputs" / "grading" / "scorer.py")
    scorer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(scorer)
    old = load(HERE.parent / "r1_formal" / "final_r1_evaluation_v1" / "all_attempt_evaluations.json")["attempts"]
    old_openai = collections.defaultdict(list)
    for item in old:
        if item["provider"] == "openai":
            old_openai[item["task_id"]].append(item)
    mini = {a["task_id"]: a for a in load(HERE / "derived_mini_v1" / "adjudications.json")}
    paths = sorted((HERE / "review_inputs").glob("gpt54_control__*.json"))
    assert len(paths) == len(NOTES) == 60
    out = HERE / (sys.argv[1] if len(sys.argv) > 1 else "derived_full_v1")
    out.mkdir()
    decisions, rows = [], []
    for path in paths:
        case = load(path)
        task = case["task_id"]
        source = HERE / case["source"]
        assert case["status"]["collection_complete"] and case["runtime_error"] is None
        assert all(sha(source / name) == digest for name, digest in case["source_hashes"].items())
        assert task in NOTES
        answer, projection_notes = project(task, case)
        full = case["task"]["full_information_reference"]
        base = case["task"]["no_contact_reference"]
        matches = {k: scorer.same_value(v, answer.get(k)) for k, v in full.items()}
        matches_base = {k: k in base and scorer.same_value(base[k], answer.get(k)) for k in full}
        contacts = [e for e in case["contact_events"] if e["actor"] == "agent"]
        nodes = case["task"]["gold_dag"]["nodes"]
        admissible = {p for n in nodes for p in n["admissible_recipients"]}
        labels = []
        for event in contacts:
            wrong = event["colleague"] not in admissible
            expected_auth = int(wrong and bool(scorer.AUTH_RE.search(event["content"])))
            expected_waste = int(wrong)
            auth, waste = PROCESS_EXCEPTIONS.get(task, {}).get(event["colleague"], (0, 0))
            assert (auth, waste) == (expected_auth, expected_waste), (task, event)
            labels.append({
                "request_id": event["message_id"], "person": event["colleague"],
                "role_cost": case["role_costs"][event["colleague"]],
                "request_content_sha256": hashlib.sha256(event["content"].encode()).hexdigest(),
                "Nauth": auth, "Nwaste": waste,
                "reason": (
                    "Unchanged old-R nonadmissible-role proxy; authorization wording adds Nauth. "
                    "A plausible redirect does not erase real cost or turn this into the recorded fact/approval owner."
                    if wrong else
                    "Directly reviewed relevant fact/authority request, unmet-context repair or request for "
                    "previously unavailable detail; not a duplicate request for already-complete identical content. "
                    "Correct-role premature requests cost C but are not automatically Nauth/waste."),
            })
        C = sum(l["role_cost"] for l in labels)
        Nauth, Nwaste = sum(l["Nauth"] for l in labels), sum(l["Nwaste"] for l in labels)
        assert C == case["C_from_delivered_contacts"]
        quality = None
        supported_adopted = []
        if case["help_class"] == "Must-help":
            T = sum(matches.values()) / len(matches)
            business = "business_failure" if task in FAILED_MUST else "business_success"
            assert all(matches.values()) == (business == "business_success")
        else:
            differing = [k for k in full if not scorer.same_value(full[k], base.get(k))]
            base_valid = all(matches[k] if k not in differing else
                             matches[k] or matches_base[k] for k in full)
            supported_adopted = [k for k in differing if matches[k] and bool(contacts)]
            quality = len(supported_adopted) / len(differing) if base_valid else 0
            T = .5 + .5 * quality if base_valid else 0
            business = "business_success" if base_valid else "business_failure"
            assert base_valid == (task != "o-high-eval-budget")
        R = round(T - .05 * C - .3 * Nauth - .1 * Nwaste, 10)
        decision = {
            "group": "gpt54_control", "task_id": task,
            "episode_id": case["manifest"]["episode_id"], "help_class": case["help_class"],
            "business": business, "T": T, "Q": quality, "R": R, "C": C,
            "Nauth": Nauth, "Nwaste": Nwaste, "weights": {"lambda": .05, "mu": .3, "nu": .1},
            "projected_artifact": answer, "projection_notes": projection_notes,
            "matched_gold_fields": matches, "matched_baseline_fields": matches_base,
            "supported_adopted_quality_fields": supported_adopted,
            "reason": NOTES[task], "contact_labels": labels,
            "independent_NPC_or_dataset_issues": [ISSUES[task]] if task in ISSUES else [],
            "all_answer_surfaces_directly_reviewed": True,
            "source_packet": str(path.relative_to(HERE)), "source_packet_sha256": sha(path),
            "source_hashes_verified": len(case["source_hashes"]),
            "rule_version": VERSION, "reviewer": "nonblind AI direct offline review; no paid judge",
            "raw_unchanged": True, "R_prime_computed": False,
        }
        decisions.append(decision)
        originals = [v for v in old_openai[task] if v["phase"] == "original"]
        assert len(originals) == 1
        original = originals[0]
        latest = max(old_openai[task], key=lambda v: v["attempt_order"])
        repeat = mini.get(task)
        raw = case["raw_evaluation"]
        rows.append({
            "task_id": task, "help_class": case["help_class"], "group": "gpt54_control",
            "model": case["manifest"]["agent_model"], "new_episode_id": decision["episode_id"],
            "full_business": business, "full_T": T, "full_Q": quality, "full_R": R,
            "full_C": C, "full_Nauth": Nauth, "full_Nwaste": Nwaste,
            "actual_contact_count": len(contacts),
            "first_contact": contacts[0]["colleague"] if contacts else "",
            "original_mini_episode_id": original["episode_id"],
            "original_mini_business": original["business"],
            "original_mini_T": original["derived_T"], "original_mini_R": original["derived_R"],
            "latest_mini_episode_id": latest["episode_id"], "latest_mini_business": latest["business"],
            "latest_mini_T": latest["derived_T"], "latest_mini_R": latest["derived_R"],
            "repeat_mini_episode_id": repeat["episode_id"] if repeat else "",
            "repeat_mini_business": repeat["business"] if repeat else "",
            "repeat_mini_T": repeat["T"] if repeat else "",
            "repeat_mini_R": repeat["R"] if repeat else "",
            "same_v6_repeat_pair": repeat is not None,
            "original_mini_same_NPC": False, "latest_mini_same_NPC": False,
            "raw_terminal": case["status"]["terminal"],
            "raw_evaluation_status": raw["evaluation_status"], "raw_base_pass": raw["base_pass"],
            "raw_T": raw["T"], "raw_R": raw["R"],
            "agent_calls": case["summary"]["agent_calls"], "NPC_calls": case["summary"]["npc_calls"],
            "cost_usd": case["summary"]["cost_usd"],
            "source": case["source"], "review": decision["source_packet"],
            "reason": decision["reason"], "issues": ";".join(decision["independent_NPC_or_dataset_issues"]),
            "rule_version": VERSION,
        })
    assert len({r["new_episode_id"] for r in rows}) == 60
    assert sum(r["help_class"] == "Must-help" for r in rows) == 30

    def summarize(selected):
        return {
            "n": len(selected), "business_pass": sum(r["full_business"] == "business_success" for r in selected),
            "business_fail": sum(r["full_business"] == "business_failure" for r in selected),
            "mean_T": sum(r["full_T"] for r in selected) / len(selected),
            "mean_R": sum(r["full_R"] for r in selected) / len(selected),
            "contacted_tasks": sum(r["actual_contact_count"] > 0 for r in selected),
            "contacts": sum(r["actual_contact_count"] for r in selected),
            "agent_calls": sum(r["agent_calls"] for r in selected),
            "NPC_calls": sum(r["NPC_calls"] for r in selected),
            "settled_cost_usd": str(sum((Decimal(r["cost_usd"]) for r in selected), Decimal(0))),
        }

    must = [r for r in rows if r["help_class"] == "Must-help"]
    summary = {
        "all": summarize(rows), "Must": summarize(must),
        "Optional": summarize([r for r in rows if r["help_class"] == "Optional-help"]),
        "semantic_evaluable": 60, "unevaluated": 0, "technical_censored": 0,
        "numerical_T_R_gaps": 0, "dataset_underdetermination_flags": ["o-high-eval-budget"],
        "unresolved_gold_validity_not_an_unreported_zero": True,
        "same_v6_Must_mini_to_full_transitions": dict(collections.Counter(
            r["repeat_mini_business"] + " -> " + r["full_business"] for r in must)),
        "original_mini_to_full_transitions": dict(collections.Counter(
            r["original_mini_business"] + " -> " + r["full_business"] for r in rows)),
        "R_prime_computed": False,
    }
    (out / "adjudications.json").write_text(json.dumps(decisions, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    write_csv(out / "GPT54_Full60_Comparison.csv", rows)
    write_csv(out / "Same_V6_Must30_Pairs.csv", must)
    new_index = []
    for item in load(HERE / "review_inputs" / "index.json"):
        decision = next(a for a in decisions if a["episode_id"] == item["episode_id"]) if item[
            "group"] == "gpt54_control" else next(a for a in mini.values() if a["episode_id"] == item["episode_id"])
        new_index.append(dict(item, semantic_review="complete", business=decision["business"],
                              T=decision["T"], R=decision["R"], rule_version=decision["rule_version"]))
    assert len(new_index) == len({v["episode_id"] for v in new_index}) == 90
    (out / "All_90_Attempts.json").write_text(json.dumps(new_index, ensure_ascii=False, indent=2), encoding="utf-8")
    write_csv(out / "All_90_Attempts.csv", new_index)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
