"""Freeze the authorized 30-mini/60-full queues and approved NPC implementation."""
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
FILES = HERE.parent
BASE = FILES / "r1_formal"
OTHER = Path(r"../r1_2026_11_02/provenance/independent")
FROZEN = OTHER / "r1_two_technical_reruns" / "frozen_stage"


def load(p):
    return json.loads(p.read_text(encoding="utf-8-sig"))


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    stage = HERE / "frozen_stage"
    stage.mkdir(exist_ok=True)
    for source in FROZEN.glob("*.py"):
        shutil.copy2(source, stage / source.name)
    runtime = stage / "guarded_npc_runtime_v4" / "frozen_runtime"
    runtime.mkdir(parents=True, exist_ok=True)
    for source in (FROZEN / "guarded_npc_runtime_v4" / "frozen_runtime").glob("*.py"):
        shutil.copy2(source, runtime / source.name)
    runner = stage / "runner"
    runner.mkdir(exist_ok=True)
    shutil.copy2(FROZEN / "two_runner" / "frozen_repair.py", runner / "frozen_repair.py")
    dataset = load(BASE / "final_r1_evaluation_v1" / "all_attempt_evaluations.json")["attempts"]
    original = sorted((a for a in dataset if a["provider"] == "openai" and a["attempt_order"] == 0),
                      key=lambda a: a["task_id"])
    assert len(original) == 60
    originals = []
    for a in original:
        packet = load(BASE / "final_r1_evaluation_v1" / a["packet"])
        originals.append({"task_id": a["task_id"], "help_class": packet["task"]["help_class"],
                          "original_episode_id": a["episode_id"], "original_run": a["run"],
                          "task_blueprint_sha256": packet["manifest"]["task_blueprint_sha256"],
                          "instance_seed": packet["manifest"]["instance_seed"]})
    scope = [{"group": "mini_repeat", "model": "gpt-5.4-mini-2026-03-17", **a}
             for a in originals if a["help_class"] == "Must-help"]
    scope += [{"group": "gpt54_control", "model": "gpt-5.4-2026-03-05", **a} for a in originals]
    assert len(scope) == 90 and len({(a["group"], a["task_id"]) for a in scope}) == 90
    (HERE / "scope.json").write_text(json.dumps(scope, ensure_ascii=False, indent=2), encoding="utf-8")
    (HERE / "source_freeze.json").write_text(json.dumps({
        "published_commit": "823a12ae733ff790dd6910d6423c49731dc694ac",
        "source_dataset_sha256": sha(BASE / "final_r1_evaluation_v1" / "all_attempt_evaluations.json"),
        "frozen_implementation_hashes": {str(p.relative_to(stage)): sha(p) for p in stage.rglob("*.py")},
        "source_cursor": str(FROZEN / "two_runner" / "stage" / "service_cursor.json"),
        "source_cursor_sha256": sha(FROZEN / "two_runner" / "stage" / "service_cursor.json"),
        "source_STOP_sha256": sha(BASE / "repair61_v1" / "STOP_REQUESTED"),
        "seed_policy": "Original task instance_seed retained; no API random seed added.",
        "NPC_condition": "controlled_rest_conversational_repair_v6; differs from original formal NPC",
        "agent_parameter_policy": {"reasoning_effort": "none", "max_completion_tokens": 2048,
                                   "tool_choice": "auto", "parallel_tool_calls": False,
                                   "temperature": "omitted as in original", "steps": 64,
                                   "max_input_token_bound": 32768},
        "price_source": "https://developers.openai.com/api/docs/models/gpt-5.4",
        "full_prices_per_million": {"input": "2.50", "cached_input": "0.25", "output": "15.00"},
        "budget": "Single shared historical USD20 ledger; preserve original five unknown reservations.",
        "paid_probes_or_extra_pilots": 0, "automatic_second_attempts": 0,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print("Frozen 90 slots: mini Must repeat30, GPT-5.4 control60; no service/model calls.")


if __name__ == "__main__":
    main()
