"""Print bounded batches of actual answers and complete contact content offline."""
import json
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
paths = sorted((root / "review_inputs").glob("gpt54_control__*.json"))
for number in range(int(sys.argv[1]), int(sys.argv[2]) + 1):
    case = json.loads(paths[number - 1].read_text(encoding="utf-8"))
    print("\n===", number, case["task_id"], "===")
    print("GOLD", json.dumps(case["task"]["full_information_reference"]))
    if case["help_class"] != "Must-help":
        print("BASE", json.dumps(case["task"]["no_contact_reference"]))
    print("WORK", json.dumps(case["workspace"], ensure_ascii=False))
    print("ALL_AGENT_TEXT", json.dumps(case["all_assistant_text"], ensure_ascii=False))
    print("POSTS", json.dumps([t["arguments"] for t in case["public_posts"]], ensure_ascii=False))
    for event in case["contact_events"]:
        print("EVENT", json.dumps({k: event[k] for k in (
            "actor", "colleague", "content", "message_id")}, ensure_ascii=False))
    print("READ_IDS", [[m.get("id") for m in t["result"]] for t in case["read_tools"]
                       if isinstance(t.get("result"), list)])
    print("C", case["C_from_delivered_contacts"])
    print("RAW", json.dumps({k: case["raw_evaluation"].get(k)
                            for k in ("T", "R", "errors")}))
