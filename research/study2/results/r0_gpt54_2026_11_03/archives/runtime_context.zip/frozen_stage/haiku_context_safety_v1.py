"""Provider-counted Haiku input safety, separate from cumulative monetary reservation."""
import copy
import json
import os
from pathlib import Path
import sys
import uuid

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import natural_npc_comparison as natural
rest = natural.rest
OriginalLedger = rest.Ledger
MODEL = "claude-haiku-5-5"
VERSION = "haiku-provider-count-v1"
MARGIN = 4096
SOURCES = {
    "model": "[REDACTED_RUNTIME_ENDPOINT]/docs/en/models/haiku-5-5/overview",
    "counting": "[REDACTED_RUNTIME_ENDPOINT]/docs/en/build-with-claude/token-counting",
    "counter_api": "[REDACTED_RUNTIME_ENDPOINT]/docs/en/api/messages/count_tokens",
    "models_api": "[REDACTED_RUNTIME_ENDPOINT]/docs/en/api/models/retrieve",
}
PRE_RESERVE_CHECK = None


class SafetyError(rest.RestError):
    def __init__(self, message, kind):
        super().__init__(message)
        self.failure_kind = kind


def counter_body(request):
    allowed = {"model", "messages", "system", "tools", "tool_choice", "thinking",
               "max_tokens", "output_config"}
    rest.require(set(request) <= allowed and request["model"] == MODEL, "Unsupported counting input")
    rest.require(request.get("thinking") == {"type": "disabled"}, "Thinking policy changed")
    rest.require(request.get("output_config") == {"effort": "low"}, "Agent effort policy changed")
    return copy.deepcopy({k: v for k, v in request.items() if k not in ("max_tokens", "output_config")})


def input_bound(estimate, request, config, model_info):
    rest.require(type(estimate) is int and estimate > 0, "Invalid provider token count")
    rest.require(model_info["id"] == MODEL and type(model_info["max_input_tokens"]) is int
                 and type(model_info["max_tokens"]) is int, "Unverified model limits")
    limit = config["max_input_token_bound"]
    maximum = request["max_tokens"]
    bound = estimate + MARGIN
    if bound > limit:
        raise SafetyError("Provider-counted input plus 4096-token safety margin exceeds study input cap",
                          "local_context_limit")
    if bound + maximum > model_info["max_input_tokens"]:
        raise SafetyError("Input safety bound plus reserved output exceeds official model context",
                          "local_context_limit")
    rest.require(0 < maximum <= model_info["max_tokens"], "Output exceeds model limit")
    # Keep approved base-price tier; never silently cross Haiku's 100K pricing boundary.
    rest.require(bound <= 100000, "Unapproved long-context price tier")
    return bound


class Counter:
    def __init__(self, http, output):
        self.http, self.output = http, Path(output)
        self.info = None

    def request(self, method, route, body=None):
        ident = str(uuid.uuid4())
        rest.append(self.output / "token_count_io.jsonl", dict(stage="request", id=ident,
            endpoint="https://api.anthropic.com/v1/" + route, method=method, request=body,
            timestamp=rest.timestamp(), generation=False, documented_cost_usd="0"))
        try:
            response = self.http.json(method, "https://api.anthropic.com/v1/" + route,
                {"x-api-key": os.environ["ANTHROPIC_API_KEY"], "anthropic-version": "2023-06-01"}, body)
        except rest.HttpFailure as error:
            rest.append(self.output / "token_count_io.jsonl", dict(stage="error", id=ident,
                status=error.status, details=error.details, timestamp=rest.timestamp()))
            raise
        rest.append(self.output / "token_count_io.jsonl", dict(stage="response", id=ident,
            response=response, timestamp=rest.timestamp(), documented_cost_usd="0"))
        return response

    def model_info(self):
        if self.info is None:
            self.info = self.request("GET", "models/" + MODEL)
            rest.require(self.info.get("id") == MODEL and self.info.get("lifecycle") != "retired",
                         "Model identity/lifecycle mismatch")
        return self.info

    def count(self, request, config):
        info = self.model_info()
        projected = counter_body(request)
        result = self.request("POST", "messages/count_tokens", projected)
        bound = input_bound(result.get("input_tokens"), request, config, info)
        metadata = dict(version=VERSION, model=MODEL, estimated_input_tokens=result["input_tokens"],
            margin_tokens=MARGIN, input_token_bound=bound, study_input_cap_tokens=config["max_input_token_bound"],
            model_context_tokens=info["max_input_tokens"], reserved_output_tokens=request["max_tokens"],
            serialized_request_bytes=len(json.dumps(request, ensure_ascii=False).encode("utf-8")),
            request_sha256=rest.config_digest(request), counted_input_sha256=rest.config_digest(projected),
            excluded_generation_controls=["max_tokens", "output_config"], full_history_and_tools_preserved=True)
        rest.append(self.output / "token_bounds.jsonl", metadata)
        return bound, metadata


class Ledger(OriginalLedger):
    def __init__(self, path, config):
        super().__init__(path, config)
        self.bounds = {}
        self.counter = None

    def reserve(self, role, request):
        if role != "agent" or request["model"] != MODEL:
            return super().reserve(role, request)
        if self.counter is None:
            self.counter = Counter(rest.Http(), self.config["token_count_receipts_dir"])
        bound, metadata = self.counter.count(request, self.config)
        if PRE_RESERVE_CHECK is not None:
            PRE_RESERVE_CHECK()
        prices = self.config["role_prices_per_million"]["agent"]
        maximum = request["max_tokens"]
        multiplier = 2
        amount = (bound * rest.positive(prices["input"]) * multiplier
                  + maximum * rest.positive(prices["output"])) / 1_000_000
        if sum(self.charges.values(), rest.Decimal(0)) + amount > self.cap:
            raise SafetyError("Batch safety budget exhausted", "shared_budget_exhausted")
        call = str(uuid.uuid4())
        self.charges[call] = amount
        self.bounds[call] = metadata
        rest.append(self.path, dict(event="reserve", id=call, role=role, amount_usd=str(amount),
            input_bound=bound, model=MODEL, prices_per_million=prices, input_price_multiplier=multiplier,
            input_bound_kind=VERSION, input_estimate=metadata["estimated_input_tokens"],
            safety_margin_tokens=MARGIN, timestamp=rest.timestamp()))
        return call, bound

    def settle(self, call, role, usage, bound, maximum):
        super().settle(call, role, usage, bound, maximum)
        if call in self.bounds:
            rest.append(Path(self.config["token_count_receipts_dir"]) / "token_bound_validation.jsonl",
                dict(call_id=call, actual_input_tokens=usage["prompt_tokens"],
                     observed_within_reserved_bound=usage["prompt_tokens"] <= bound, **self.bounds[call]))


def infrastructure_scope(error, last_request_role=None, unknown=False):
    kind, message = error.get("failure_kind"), error.get("message", "").lower()
    if kind in ("local_context_limit", "context_limit") or (
            "input byte/token safety bound exceeded" in message and not unknown):
        return "episode"
    if kind == "shared_budget_exhausted" or "budget" in message:
        return "shared"
    if kind in ("provider_authentication", "provider_rate_limit", "provider_quota"):
        return "provider" if last_request_role == "agent" else "shared"
    if unknown:
        return "provider" if last_request_role == "agent" else "shared"
    return "shared"
