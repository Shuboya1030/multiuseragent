"""Serialized, checkpointed R1 execution. One initial attempt per provider/task, no retries."""
import argparse
import base64
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import urllib.parse

BASE = Path(__file__).resolve().parent
ROOT = Path(__file__).resolve().parents[1] / "task_inputs"
OLD = BASE.parent / "r1_local_services" / "deployment_20261027"
sys.path[:0] = [str(ROOT / "runtime"), str(BASE)]
import rest_runner as rest
from initialize_progress import atomic, publish
from audit_episode import audit

MODELS = {"openai": rest.MODEL, "anthropic": "claude-haiku-5-5", "kimi": "kimi-k2.6"}
STAGE = BASE / "execution_stage_v7"
DOCKER = r"[REDACTED_LOCAL_PATH]"


def progress_update(action, phase, provider=None, task=None, summary=None, running=False):
    p = rest.load(BASE / "progress.json")
    ledger = [json.loads(line) for line in (BASE / "shared_budget" / "cost_ledger.jsonl").read_text(
        encoding="utf-8").splitlines()]
    settled = {r["id"]: r for r in ledger if r["event"] == "settle"}
    unknown = [r for r in ledger if r["event"] == "reserve" and r["id"] not in settled]
    paid = sum((rest.Decimal(r["amount_usd"]) for r in settled.values()), rest.Decimal(0))
    retained = sum((rest.Decimal(r["amount_usd"]) for r in unknown), rest.Decimal(0))
    p.update(phase=phase, current_action=action, settled_cost_usd=str(paid),
             retained_unknown_reservations_usd=str(retained), cumulative_cost_usd=str(paid + retained),
             unsettled_reservations=len(unknown), blockers=[])
    if task:
        rows = p["tasks"] if phase == "formal" else p["pilots"]
        row = next(r for r in rows if r.get("provider") == provider and r["task_id"] == task)
        if running:
            row.update(state="running", note="真实Agent执行；不是NPC前测或材料审核。")
            row["npc_backend"] = p.get("active_npc_backend", "controlled_rest_roleplay")
            p["provider_execution_status"][provider].update(
                status=phase + "_running", npc_backend=row["npc_backend"])
            if phase == "formal":
                p["provider_execution_status"][provider]["formal_gate_passed"] = True
        if summary:
            row.update(state=summary["state"], terminal=summary["terminal"],
                evaluation_status=(summary["evaluation"] or {}).get("evaluation_status", "not_scored"),
                strict_success=summary["strict_success"],
                unknown=summary["state"] == "needs_review", error=summary.get("error"),
                trace=str(output_path(provider, task, phase).relative_to(BASE)),
                input_tokens=sum(u["input_tokens"] for u in summary["usage_by_role"].values()),
                output_tokens=sum(u["output_tokens"] for u in summary["usage_by_role"].values()),
                cost_usd=summary["cost_usd"], summary=summary, note="真实独立评分；pilot不混正式。")
            row["npc_backend"] = rest.load(output_path(provider, task, phase) / "run_manifest.json")["npc_backend"]
    publish(p)


def output_path(provider, task, phase):
    return BASE / ("formal_episodes_v1" if phase == "formal" else "provider_pilots_v1") / provider / task


def config_for(provider, task, phase):
    directory = STAGE / phase / provider / task
    c = rest.load(BASE / "execution_stage_v3" / "m-high-service-cutover" / "config.json")
    c.update(agent_model=MODELS[provider], phase="full" if phase == "formal" else "pilot",
        full_collection_authorized=phase == "formal", pilot_tasks=list(rest.PILOTS),
        role_prices_per_million={"agent": rest.PRICE_BOOK[MODELS[provider]], "npc": rest.PRICE_BOOK[rest.MODEL]},
        readiness_file=str(directory / "readiness.json"), batch_dir=str(directory / "batch"),
        provider_approval_ref=rest.load(BASE / "execution_stage_v3" / "approval.json")["authorization_ref"],
        pilot_gate_policy="per_provider_remaining_two", npc_backend=rest.guarded_npc.BACKEND,
        npc_method_authorization_file=str(BASE / "guarded_npc_runtime_v4" / "authorization.json"))
    return c, directory


def pilot_dirs(provider):
    parent = BASE / "pilot_episodes_v3" if provider == "openai" else BASE / "provider_pilots_v1" / provider
    selection = STAGE / "provider_pilot_selection.json"
    overrides = rest.load(selection).get(provider, {}) if selection.exists() else {}
    return [overrides.get(task, str(parent / task)) for task in rest.PILOTS[1:]]


def snapshots():
    return {rest.digest(path): str(path) for path in
        (BASE / "execution_rpc_v5" / "source_before.json", BASE / "provider_runtime_v1" / "source_before.json",
         BASE / "npc_context_runtime_v3" / "source_before.json",
         BASE / "npc_boundary_guard_v1" / "source_before.json",
         BASE / "guarded_npc_runtime_v4" / "source_before.json")}


def owned_services():
    owned = rest.load(OLD / "owned_container_identities.json")
    for row in owned:
        result = subprocess.run([DOCKER, "inspect", "--format",
            '{{.State.Running}}|{{.Image}}|{{index .Config.Labels "com.docker.compose.project"}}',
            row["id"]], check=True, capture_output=True, text=True).stdout.strip().split("|")
        rest.require(result == ["true", row["image_id"], "study21-r1-544e03c2"], "Service ownership drift")


def prepare(c, provider, task, phase, directory, run):
    directory.mkdir(parents=True)
    rest.save(directory / "config.json", c)
    owned_services()
    cursor_path = STAGE / "service_cursor.json"
    if cursor_path.exists():
        cursor = rest.load(cursor_path)
    else:
        setup = rest.load(BASE / "execution_stage_v3" / "o-medium-event-package" / "runtime_setup.json")
        cursor = {"channel_id": setup["new_channel_id"],
                  "run": str(BASE / "pilot_episodes_v3" / "o-medium-event-package")}
    previous = Path(cursor["run"])
    rest.require(rest.episode_status(previous)["collection_complete"] is True, "Previous export not sealed")
    prior_raw = rest.load(previous / "raw_chat.json")["channels"].get(cursor["channel_id"], [])
    service = rest.Services(c, task, rest.Http(), None, directory, "nonpaid-clean-setup")
    admin = service.login("R1_OPERATOR_USERNAME", "R1_ROCKETCHAT_ADMIN_PASSWORD")
    username = "r1_v4_" + ("f" if phase == "formal" else "p") + "_" + provider + "_" + task
    if c.get("authorized_rerun"):
        username += "_" + c["authorized_rerun"]["attempt_id"].replace("-", "_")
    os.environ[c["agent_username_env"]] = username
    found = service.rpc("GET", "users.list", headers=admin,
        params={"query": json.dumps({"username": username})})["users"]
    rest.require(not found, "Account already exists; inspect checkpoint rather than duplicate")
    created = service.rpc("POST", "users.create", {
        "username": username, "name": username, "email": username + "@example.invalid",
        "password": os.environ[c["agent_password_env"]], "roles": ["user"],
        "verified": True, "joinDefaultChannels": False}, headers=admin)["user"]
    rest.append(directory / "setup_checkpoints.jsonl", {"stage": "account_created", "id": created["_id"]})
    service.headers = admin
    channel = service.rpc("GET", "channels.info", params={"roomName": "engineering"})["channel"]
    rest.require(channel["_id"] == cursor["channel_id"], "Current channel not owned by prior episode")
    live = service.history(channel["_id"], "channels.history")
    rest.require({m["_id"]: m for m in live if not m.get("t")} ==
                 {m["_id"]: m for m in prior_raw if not m.get("t")}, "Prior channel archive mismatch")
    rest.save(directory / "prior_channel_archive.json", {"room_id": channel["_id"], "messages": live})
    archived = "archive-r1-" + rest.load(previous / "run_manifest.json")["episode_id"].replace("-", "")[:24]
    service.rpc("POST", "channels.rename", {"roomId": channel["_id"], "name": archived})
    rest.append(directory / "setup_checkpoints.jsonl", {"stage": "prior_channel_archived", "name": archived})
    members = [username] + ["r1_npc_" + p["npc_id"] for p in rest.load(ROOT / "organization" / "roster.json")]
    new_channel = service.rpc("POST", "channels.create", {"name": "engineering", "members": members})["channel"]
    rest.append(directory / "setup_checkpoints.jsonl", {"stage": "channel_created", "id": new_channel["_id"]})
    packet = ROOT / "templates" / task / "tac" / "documents_R0"
    try:
        inventory = service.public()
    except rest.HttpFailure as error:
        if error.status != 404:
            raise
        credentials = (os.environ[c["owncloud_username_env"]] + ":" + os.environ[c["owncloud_password_env"]]).encode()
        headers = {"Authorization": "Basic " + base64.b64encode(credentials).decode("ascii")}
        url = c["owncloud_url"] + "/remote.php/webdav/Documents/Study21V2/" + task + "/"
        service.http.request("MKCOL", url, headers)
        for path in packet.glob("*.md"):
            service.http.request("PUT", url + urllib.parse.quote(path.name, safe=""), headers,
                                 body=path.read_bytes())
        inventory = service.public()
    rest.require(inventory == sorted(p.name for p in packet.glob("*.md")), "Packet inventory differs")
    rest.require(all(service.public(p.name) == p.read_text(encoding="utf-8")
                     for p in packet.glob("*.md") if p.name != "directory.md"),
                 "Non-directory business documents drifted")
    credentials = (os.environ[c["owncloud_username_env"]] + ":" + os.environ[c["owncloud_password_env"]]).encode()
    headers = {"Authorization": "Basic " + base64.b64encode(credentials).decode("ascii")}
    url = c["owncloud_url"] + "/remote.php/webdav/Documents/Study21V2/" + task + "/directory.md"
    service.http.request("PUT", url, headers, body=(packet / "directory.md").read_bytes())
    rest.require(all(service.public(p.name) == p.read_text(encoding="utf-8") for p in packet.glob("*.md")),
                 "Packet public contents differ")
    rest.require(service.history(new_channel["_id"], "channels.history") == [], "New channel not empty")
    old_ready = rest.load(OLD / "readiness.json")
    decision = BASE / "execution_stage_v2" / "user_review_decision.json"
    ready = {flag: old_ready[flag] for flag in rest.READINESS}
    ready.update(method=rest.METHOD, task_id=task, configuration_sha256=rest.config_digest(c),
        source_manifest_sha256=rest.digest(ROOT / "artifact_manifest.json"),
        rocketchat_url=c["rocketchat_url"], owncloud_url=c["owncloud_url"],
        service_instance=old_ready["service_instance"], material_review_passed=False,
        material_review={"status": "not_required_by_user_amendment",
            "authorization_ref": c["material_review_authorization_ref"],
            "decision_file": str(decision), "decision_sha256": rest.digest(decision)},
        npc_release_preflight_passed=True,
        npc_preflight_scope="Guarded v4: 9 High + 4 pricing real style-model/contract probes, synthetic message transport; not Agent episodes.",
        npc_evidence=[str(BASE / "guarded_npc_runtime_v4" / "validation.json")],
        channel_delivery_ready=True, metadata_schema_validated=True,
        schema_evidence="Unchanged schema/task hashes; material_audit_v3/schema_report.json",
        provider_approval_file=str(BASE / "execution_stage_v3" / "approval.json"),
        pilot_source_snapshots=snapshots(), pilot_run_dirs=pilot_dirs(provider))
    rest.save(directory / "readiness.json", ready)
    rest.save(directory / "preparation.json", {"username": username, "agent_id": created["_id"],
        "channel_id": new_channel["_id"], "packet_verified": True,
        "no_model_calls": True, "timestamp": rest.timestamp()})
    atomic(cursor_path, json.dumps({"channel_id": new_channel["_id"], "run": str(run)}, indent=2))


def execute(provider, task, phase):
    c, directory = config_for(provider, task, phase)
    run = output_path(provider, task, phase)
    if directory.exists():
        rest.require((directory / "preparation.json").exists(), "Partial setup; manual checkpoint recovery required")
        rest.require(rest.load(directory / "config.json") == c and not run.exists(),
                     "Existing attempt/output; never replay")
        os.environ[c["agent_username_env"]] = rest.load(directory / "preparation.json")["username"]
    else:
        lock = Path(c["ledger_dir"]) / "exclusive.lock"
        with lock.open("x", encoding="utf-8") as file:
            file.write("Nonpaid isolated setup; no parallel experiments./n")
        try:
            prepare(c, provider, task, phase, directory, run)
        finally:
            lock.unlink()
    rest.validate(c, task, live=True)
    progress_update(f"真实Agent执行：{provider}/{task}；任务审核已停止。", phase, provider, task, running=True)
    captured = []
    original = rest.Services

    class Capture(original):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            captured.append(self)

    rest.Services = Capture
    try:
        rest.run(c, task, run)
    finally:
        rest.Services = original
    status = rest.load(run / "status.json")
    if not status["collection_complete"] and status["terminal"] != "runtime_error":
        error = rest.load(run / "collection_error.json")
        if error["message"] == "HTTP request failed: status 429":
            progress_update(f"{provider}/{task} Agent已结束；等待一次冷却后只读导出，不重发模型。", phase)
            time.sleep(61)
            lock = Path(c["ledger_dir"]) / "exclusive.lock"
            with lock.open("x", encoding="utf-8") as file:
                file.write("Original live receipts; one read-only export recovery, no model replay./n")
            try:
                trace = captured[0].collect()
                rest.save(run / "trace_bundle.json", trace)
                rest.save(run / "collection_recovery.json", {
                    "original_status_sha256": rest.digest(run / "status.json"), "episode_id": trace["episode_id"],
                    "collection_complete": True, "read_only": True, "model_calls_replayed": 0,
                    "messages_reposted": 0, "raw_chat_sha256": rest.digest(run / "raw_chat.json"),
                    "trace_bundle_sha256": rest.digest(run / "trace_bundle.json"), "timestamp": rest.timestamp()})
            finally:
                lock.unlink()
    summary = audit(c, task, run)
    if c["npc_backend"] == rest.guarded_npc.BACKEND and summary["complete"] and summary["terminal"] != "runtime_error":
        from verify_guarded_result import verify
        summary = verify(c, task, run, summary)
    progress_update(f'{provider}/{task}完成：{summary["state"]}；真实独立评分，失败不重跑。',
                    phase, provider, task, summary)
    print("EPISODE_COMPLETE", json.dumps(summary, ensure_ascii=False), flush=True)
    return summary


def main(args):
    rest.verify_source()
    STAGE.mkdir(exist_ok=True)
    audit_record = rest.load(BASE / "guarded_npc_runtime_v4" / "audit_numeric_v2.json")
    rest.require(audit_record["source_sha256"] == rest.digest(ROOT / "artifact_manifest.json"), "Runtime pin drift")
    validation = rest.load(BASE / "guarded_npc_runtime_v4" / "validation.json")
    rest.require(validation["pass"] is True and validation["source_sha256"] == audit_record["source_sha256"]
                 and len(validation["cases"]) == 13 and all(c["pass"] is True for c in validation["cases"]),
                 "Actual NPC context-regression evidence incomplete")
    order = []
    providers = list(MODELS)
    for i, path in enumerate(sorted((ROOT / "templates").glob("*/blueprint.json"))):
        rotated = providers[i % 3:] + providers[:i % 3]
        order += [{"task_id": path.parent.name, "provider": p, "model": MODELS[p]} for p in rotated]
    manifest = {"source_sha256": audit_record["source_sha256"], "order": order,
                "formal_target": 180, "budget_shared": True, "retry": False}
    batch = STAGE / "formal_schedule.json"
    if batch.exists():
        rest.require(rest.load(batch) == manifest, "Frozen schedule changed")
    else:
        rest.save(batch, manifest)
    controller_lock = STAGE / "execution_controller.lock"
    with controller_lock.open("x", encoding="utf-8") as file:
        file.write("Single controller; do not remove without auditing process/checkpoint./n")
    try:
        if args.phase == "pilot":
            execute(args.provider, args.task, "pilot")
        else:
            completed = 0
            for slot in order:
                if slot["provider"] != args.provider:
                    continue
                p = rest.load(BASE / "progress.json")
                row = next(t for t in p["tasks"] if t["provider"] == args.provider and t["task_id"] == slot["task_id"])
                if row["state"] != "pending":
                    continue
                time.sleep(65)
                summary = execute(args.provider, slot["task_id"], "formal")
                completed += 1
                if summary["state"] == "infrastructure_error" or completed >= args.limit:
                    break
    except (rest.RestError, OSError, KeyError, ValueError, subprocess.SubprocessError) as error:
        rest.append(STAGE / "controller_errors.jsonl", {
            "error_type": type(error).__name__, "message": str(error), "timestamp": rest.timestamp()})
        progress_update("执行技术阻塞：" + str(error), "blocked")
        raise
    finally:
        controller_lock.unlink()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--provider", choices=MODELS, default="openai")
    parser.add_argument("--phase", choices=("pilot", "formal"), default="formal")
    parser.add_argument("--task", choices=rest.PILOTS[1:])
    parser.add_argument("--limit", type=int, default=10)
    args = parser.parse_args()
    rest.require(args.limit > 0 and (args.phase != "pilot" or args.task), "Invalid execution scope")
    main(args)
