"""Durable serial account-wide RPM3 pacing; never retry a generation request."""
from contextlib import contextmanager
import datetime as dt
import email.utils
import json
import msvcrt
from pathlib import Path
import time
import urllib.error
import uuid
import sys

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import natural_npc_comparison as natural
rest = natural.rest
OriginalHttp = rest.Http
ENDPOINT = "https://api.moonshot.ai/v1/chat/completions"
VERSION = "kimi-account-rpm3-v1"
MIN_INTERVAL = 21.0
PRE_SEND_CHECK = None


def retry_seconds(headers, now):
    value = headers.get("retry-after")
    if value is None:
        return 0.0
    try:
        seconds = float(value)
    except ValueError:
        parsed = email.utils.parsedate_to_datetime(value)
        rest.require(parsed.tzinfo is not None, "Ambiguous Retry-After date")
        seconds = parsed.timestamp() - now
    rest.require(seconds == seconds and abs(seconds) != float("inf"), "Invalid Retry-After")
    return max(0.0, seconds)


class Pacer:
    def __init__(self, directory, clock=time.time, sleep=time.sleep):
        self.directory, self.clock, self.sleep = Path(directory), clock, sleep
        self.log = self.directory / "kimi_account_pacing_v1.jsonl"

    def rows(self):
        return [json.loads(l) for l in self.log.read_text(encoding="utf-8").splitlines()] if self.log.exists() else []

    @contextmanager
    def slot(self):
        with (self.directory / "kimi_account_request.lock").open("a+b") as lock:
            if lock.tell() == 0:
                lock.write(b"0")
                lock.flush()
            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
            try:
                rows = self.rows()
                sent = [r["sent_at_epoch"] for r in rows if r["event"] == "send"]
                pauses = [r["not_before_epoch"] for r in rows if r["event"] == "cooldown"]
                target = max([sent[-1] + MIN_INTERVAL if sent else 0] + pauses)
                while self.clock() < target:
                    if PRE_SEND_CHECK is not None:
                        PRE_SEND_CHECK()
                    self.sleep(min(1.0, target - self.clock()))
                if PRE_SEND_CHECK is not None:
                    PRE_SEND_CHECK()
                now, ident = self.clock(), str(uuid.uuid4())
                rest.append(self.log, dict(event="send", id=ident, version=VERSION,
                    sent_at_epoch=now, actual_send_utc=dt.datetime.fromtimestamp(
                        now, dt.timezone.utc).isoformat(), min_interval_seconds=MIN_INTERVAL,
                    no_automatic_retry=True))
                yield ident
            finally:
                lock.seek(0)
                msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)

    def receipt(self, ident, status, headers):
        now = self.clock()
        rest.append(self.log, dict(event="response", id=ident, status=status,
            headers=headers, received_at_epoch=now))
        if status == 429 or "retry-after" in headers:
            delay = max(MIN_INTERVAL, retry_seconds(headers, now))
            rest.append(self.log, dict(event="cooldown", id=ident,
                not_before_epoch=now + delay, reason="Provider response; no original request replay"))


class HeaderRecorder:
    def __init__(self, opener, owner):
        self.opener, self.owner = opener, owner

    def capture(self, response):
        self.owner.kimi_status = response.code
        self.owner.kimi_headers = {
            k.lower(): v for k, v in response.headers.items()
            if k.lower() == "retry-after" or k.lower().startswith("x-ratelimit-")
            or k.lower() in ("x-request-id", "request-id")}

    def open(self, request, **kwargs):
        try:
            response = self.opener.open(request, **kwargs)
        except urllib.error.HTTPError as error:
            if request.full_url == ENDPOINT:
                self.capture(error)
            raise
        if request.full_url == ENDPOINT:
            self.capture(response)
        return response


class Http(OriginalHttp):
    def __init__(self):
        super().__init__()
        self.kimi_status, self.kimi_headers = None, {}
        self.opener = HeaderRecorder(self.opener, self)

    def request(self, method, url, headers=None, value=None, body=None):
        if url != ENDPOINT:
            return super().request(method, url, headers, value, body)
        rest.require(method == "POST" and value["model"] == "kimi-k2.6", "Unexpected Kimi request")
        pacer = Pacer(BASE / "shared_budget")
        with pacer.slot() as ident:
            self.kimi_status, self.kimi_headers = None, {}
            try:
                return super().request(method, url, headers, value, body)
            finally:
                pacer.receipt(ident, self.kimi_status, self.kimi_headers)


def seed_history():
    log = BASE / "shared_budget" / "kimi_account_pacing_v1.jsonl"
    if log.exists():
        return
    old = []
    for path in BASE.rglob("api_io.jsonl"):
        for line in path.read_text(encoding="utf-8").splitlines():
            row = json.loads(line)
            if row["stage"] == "request" and row.get("request", {}).get("model") == "kimi-k2.6":
                old.append((dt.datetime.fromisoformat(row["timestamp"]).timestamp(), row["call_id"]))
    for timestamp, ident in sorted(set(old)):
        rest.append(log, dict(event="send", id=ident, sent_at_epoch=timestamp,
            seeded_from_existing_actual_request=True, source="Historical Kimi API logs; same approved account"))
