"""Initialize the authorized stage and atomically publish progress without any API calls."""
import csv
import datetime as dt
import io
import json
import os
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = Path.cwd() / "research" / "study2" / "task_generation_v2"
AUTH = "assignment:741f367f-a37b-48de-a57d-1e7bbe84ade4:call_VbmpEMe2PpVvH8LTjgPEzF5d"


def atomic(path, content):
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("x", encoding="utf-8", newline="") as file:
        file.write(content)
        file.flush()
        os.fsync(file.fileno())
    os.replace(temp, path)


def publish(progress):
    progress["updated_at"] = dt.datetime.now(dt.timezone.utc).isoformat()
    states = ("pending", "running", "success", "task_failure", "needs_review",
              "infrastructure_error", "blocked", "skipped")
    counts = {s: sum(t["state"] == s for t in progress["tasks"]) for s in states}
    denominator = counts["success"] + counts["task_failure"]
    progress["formal_counts"] = counts
    progress["formal_success_rate"] = counts["success"] / denominator if denominator else None
    progress["formal_success_rate_denominator"] = denominator
    progress["formal_success_coverage"] = counts["success"] / progress["formal_target"]
    progress["by_model"] = {}
    for model in sorted({t.get("model", "gpt-5.4-mini-2026-03-17") for t in progress["tasks"]}):
        selected = [t for t in progress["tasks"] if t.get("model", "gpt-5.4-mini-2026-03-17") == model]
        c = {s: sum(t["state"] == s for t in selected) for s in states}
        d = c["success"] + c["task_failure"]
        progress["by_model"][model] = {"target": len(selected), "counts": c,
                                      "success_rate": c["success"] / d if d else None,
                                      "success_rate_denominator": d}
    progress["by_class"] = {}
    progress["by_model_and_npc_backend"] = {}
    for task in progress["tasks"]:
        if task["state"] in ("pending", "blocked", "skipped"):
            continue
        key = task["model"] + " / " + task.get("npc_backend", "controlled_rest_roleplay")
        group = progress["by_model_and_npc_backend"].setdefault(key, {"counts": {s: 0 for s in states}})
        group["counts"][task["state"]] += 1
    for group in progress["by_model_and_npc_backend"].values():
        c = group["counts"]
        d = c["success"] + c["task_failure"]
        group.update(success_rate=c["success"] / d if d else None, success_rate_denominator=d)
    for cls in ("Must-help", "Optional-help"):
        tasks = [t for t in progress["tasks"] if t["help_class"] == cls]
        c = {s: sum(t["state"] == s for t in tasks) for s in states}
        d = c["success"] + c["task_failure"]
        progress["by_class"][cls] = {"counts": c, "success_rate": c["success"] / d if d else None,
                                    "success_rate_denominator": d}
    atomic(BASE / "progress.json", json.dumps(progress, ensure_ascii=False, indent=2) + "\n")
    stream = io.StringIO(newline="")
    columns = ("order", "provider", "model", "task_id", "help_class", "state", "terminal", "evaluation_status",
               "strict_success", "unknown", "error", "trace", "input_tokens", "output_tokens", "cost_usd", "npc_backend")
    writer = csv.DictWriter(stream, fieldnames=columns)
    writer.writeheader()
    writer.writerows({k: t.get(k) for k in columns} for t in progress["tasks"])
    atomic(BASE / "tasks.csv", stream.getvalue())
    rate = ("尚无正式评分" if denominator == 0 else
            f'{counts["success"]}/{denominator} = {100 * counts["success"] / denominator:.1f}%')
    lines = ["# R1 正式阶段进度", "", f'更新时间：{progress["updated_at"]}',
             f'阶段：{progress["phase"]}；批次：{progress["batch_id"]}',
             f'目标：{progress["formal_target"]}个正式episode（每模型60任务），pilot另计。新阶段API总帽USD20，所有角色共用；历史账本不合并。',
             f'累计描述性成功率：{rate}。分母仅success+task_failure；待审/基础设施错误不计。NPC机制变更后不得将此混合累计值用于模型能力比较；下表按机制分层。',
             f'状态计数：{json.dumps(counts, ensure_ascii=False)}',
             f'新阶段预算占用（结算+未知调用最坏预留）：USD {progress["cumulative_cost_usd"]}；未决预留：{progress["unsettled_reservations"]}。',
             f'已结算：USD {progress.get("settled_cost_usd", "待核算")}；保留的未知调用预留：USD {progress.get("retained_unknown_reservations_usd", "待核算")}。',
             f'当前事项：{progress["current_action"]}', "",
             "## Pilot（与正式批次分开）", "",
             "| 模型 | task | 状态 | 说明 |", "|---|---|---|---|"]
    lines += [f'| {p.get("model", "历史原mini")} | {p["task_id"]} | {p["state"]} | {p["note"]} |' for p in progress["pilots"]]
    lines += ["", "## 分模型正式统计", "", "| 模型 | success | task failure | 待审 | infra | 成功率分母 |",
              "|---|---:|---:|---:|---:|---:|"]
    lines += [f'| {model} | {value["counts"]["success"]} | {value["counts"]["task_failure"]} | '
              f'{value["counts"]["needs_review"]} | {value["counts"]["infrastructure_error"]} | '
              f'{value["success_rate_denominator"]} |' for model, value in progress["by_model"].items()]
    lines += ["", "## 模型与NPC机制分层（研究比较使用分层口径）", "",
              "| 模型 / NPC机制 | success | task failure | 待审 | infra | 分母 |", "|---|---:|---:|---:|---:|---:|"]
    lines += [f'| {key} | {g["counts"]["success"]} | {g["counts"]["task_failure"]} | '
              f'{g["counts"]["needs_review"]} | {g["counts"]["infrastructure_error"]} | '
              f'{g["success_rate_denominator"]} |' for key, g in progress["by_model_and_npc_backend"].items()]
    lines += ["", "## 正式任务", "", "| 顺序 | 模型 | task | 类别 | 状态 | 评估/错误 |",
              "|---:|---|---|---|---|---|"]
    lines += [f'| {t["order"]} | {t.get("model", "原mini")} | {t["task_id"]} | {t["help_class"]} | {t["state"]} | '
              f'{t.get("evaluation_status") or t.get("error") or ""} |' for t in progress["tasks"]]
    atomic(BASE / "progress.md", "\n".join(lines) + "\n")


if __name__ == "__main__":
    assert not (BASE / "progress.json").exists(), "Do not overwrite a running stage"
    tasks = []
    for order, path in enumerate(sorted((ROOT / "templates").glob("*/blueprint.json")), 1):
        bp = json.loads(path.read_text(encoding="utf-8"))
        tasks.append({"order": order, "task_id": bp["task_id"], "help_class": bp["help_class"],
                      "instance_seed": bp["instance_seed"], "state": "pending", "terminal": None,
                      "evaluation_status": None, "strict_success": None, "unknown": None, "error": None,
                      "trace": None, "input_tokens": 0, "output_tokens": 0, "cost_usd": "0"})
    assert len(tasks) == 60
    authorization = {
        "authorization_ref": AUTH,
        "user_request": "正式开始R1实验吧，我希望能进行过程中定期report 任务跑了哪些，任务成功失败率。你想想怎么跑这个实验",
        "budget_selection": "授权新阶段合计 USD 20", "budget_usd": "20",
        "scope": "Remaining two pilots, independent formal 60 initial attempts, necessary NPC tests and all independent judges",
        "presentation": "full-list-context-v2", "automatic_retries": False,
        "history_excluded": "Prior USD3 Agent/NPC ledger and USD0.10 D1 ledger remain archived and linked, not reset"}
    atomic(BASE / "authorization.json", json.dumps(authorization, ensure_ascii=False, indent=2) + "\n")
    publish({"phase": "preparation", "batch_id": "r1-formal-stage-20261028",
             "configuration_sha256": None, "authorization_ref": AUTH, "formal_target": 60,
             "current_action": "审计并修复Optional metadata根因，验证完整schema与材料/D1/D2准入。",
             "budget_usd": "20", "cumulative_cost_usd": "0", "unsettled_reservations": 0,
             "pilots": [
                 {"task_id": "m-low-ledger-allocation", "state": "task_failure",
                  "note": "Historical authorized full-list pilot; complete/scored, excluded from new stage billing and formal denominator."},
                 {"task_id": "o-medium-event-package", "state": "pending", "note": "Awaiting material admission and actual live checks."},
                 {"task_id": "m-high-service-cutover", "state": "pending", "note": "Awaiting material admission and actual live checks."}],
             "tasks": tasks, "blockers": []})
    print("Atomic preparation progress baseline persisted; 60 formal tasks pending, historical pilot separate; API calls=0.")
