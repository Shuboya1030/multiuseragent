"""Checkpoint a failed pre-ownership setup, retaining the same60 attempt IDs."""
from pathlib import Path
import runtime as r

root = r.ROOT
assert not (root / "episodes").exists()
assert not list(root.rglob("api_io.jsonl"))
queue = r.rest.load(root / "queue.json")
assert len(queue) == 60 and queue[0]["state"] == "preparing"
assert all(s["state"] == "pending" for s in queue[1:])
baseline = r.rest.load(root / "baseline.json")
assert r.budget() == baseline["budget"]
first = root / "stage" / "r0_gpt54" / queue[0]["task_id"]
assert sorted(p.name for p in first.iterdir()) == ["config.json"]
assert r.rest.load(first / "config.json")["condition"] == "R0"
proof = {
    "reason": "Docker desktop-linux daemon absent; owned_services first inspect failed before any login/setup/model request",
    "model_calls_before_recovery": 0,
    "service_mutations_before_failure": 0,
    "original_attempt_ids_retained": [s["attempt_id"] for s in queue],
    "config_only_checkpoint_sha256": r.rest.digest(first / "config.json"),
    "installed_engine_and_only_exact_owned_containers_started": True,
    "no_download_or_extra_probe_or_second_attempt": True,
    "budget": r.budget(),
    "timestamp": r.rest.timestamp(),
}
r.rest.save(root / "zero_call_recovery.json", proof)
first.rename(first.with_name(first.name + "__zero_call_checkpoint"))
(root / "controller.finished.json").rename(root / "controller.zero_call_finished.json")
(root / "offline_validation.json").rename(root / "offline_validation.before_zero_call_recovery.json")
print("Preserved zero-call failure checkpoint and original60 IDs; ready for same first setup")
