"""Preserve the second zero-request initialization failure, without deleting locks."""
import runtime as r

root = r.ROOT
assert not (root / "controller.lock").exists()
assert not (root / "episodes").exists()
assert not list(root.rglob("api_io.jsonl"))
proof = r.rest.load(root / "zero_call_recovery.json")
assert r.budget() == proof["budget"]
queue = r.rest.load(root / "queue.json")
empty_queue_repaired = queue == []
if empty_queue_repaired:
    # The pre-gate exception published the uninitialized global queue, not new attempts.
    signed_scope = r.rest.load(r.TOP / "scope.json")
    assert len(signed_scope) == len(proof["original_attempt_ids_retained"]) == 60
    assert len(set(proof["original_attempt_ids_retained"])) == 60
    r.rest.save(root / "queue.before_zero_call_gate_recovery.json", queue)
    queue = [{**slot, "attempt_id": ident, "state": "blocked_controller"}
             for slot, ident in zip(signed_scope, proof["original_attempt_ids_retained"])]
assert [s["attempt_id"] for s in queue] == proof["original_attempt_ids_retained"]
assert all(s["state"] == "blocked_controller" for s in queue)
assert not (root / "stage" / "r0_gpt54" / queue[0]["task_id"]).exists()
error = r.rest.load(root / "controller_error.json")
assert "prior_shared_gate.json" in error["message"]
r.rest.save(root / "gate_recovery_checkpoint.json", {
    "failed_operation": "Exclusive creation of already preserved prior_shared_gate.json",
    "model_calls": 0, "no_inflight_generation": True,
    "prior_gate_receipt_sha256": r.rest.digest(root / "prior_shared_gate.json"),
    "attempt_ids_retained": True, "budget": r.budget(),
    "empty_error_published_queue_restored_from_signed_scope_and_original_ids": empty_queue_repaired,
    "repair": "Versioned immutable gate/error/finish receipts; same pre-first-request scope",
    "network_policy": "Only original localhost services and api.openai.com; no external dependencies or CDN",
    "timestamp": r.rest.timestamp(),
})
(root / "controller_error.json").rename(root / "controller_error.zero_call_gate_failure.json")
(root / "offline_validation.json").rename(root / "offline_validation.before_gate_recovery.json")
r.batch.atomic(root / "queue.json", r.json.dumps(queue, ensure_ascii=False, indent=2))
print("Verified no in-flight calls; retained all gates/locks/60 IDs and baseline budget")
