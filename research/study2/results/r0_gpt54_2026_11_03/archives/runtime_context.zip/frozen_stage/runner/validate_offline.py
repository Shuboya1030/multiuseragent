"""R0 public-surface and full-wire fixtures; no service or paid calls."""
import copy
import json
import os
from pathlib import Path
import tempfile

import runtime as r
import controller as c


def main():
    r.rest.verify_source()
    scope = r.rest.load(r.TOP / "scope.json")
    assert len(scope) == len({s["task_id"] for s in scope}) == 60
    assert all(s["group"] == "r0_gpt54" and s["model"] == r.FULL for s in scope)
    before = r.budget()
    assert len(before["unknown"]) == 5 and r.rest.Decimal(before["occupied_usd"]) < 20
    old = r.TOP.parent / "r1_openai_repeat_and_full_v1"
    full = {s["task_id"]: s for s in r.rest.load(old / "derived_full_v1" / "All_90_Attempts.json")
            if s["group"] == "gpt54_control"}
    assert r.rest.digest(r.ROOT / "frozen_repair.py") == r.rest.digest(
        old / "frozen_stage" / "runner" / "frozen_repair.py")
    with tempfile.TemporaryDirectory(prefix="r0_offline_") as temporary:
        output = Path(temporary)
        for slot in scope:
            task = slot["task_id"]
            folder = r.rest.ROOT / "templates" / task
            assert r.rest.digest(folder / "blueprint.json") == slot["task_blueprint_sha256"]
            basic = folder / "tac" / "documents_R0"
            rich = folder / "tac" / "documents_R1"
            assert sorted(p.name for p in basic.glob("*.md")) == sorted(p.name for p in rich.glob("*.md"))
            assert all(p.read_bytes() == (rich / p.name).read_bytes()
                       for p in basic.glob("*.md") if p.name != "directory.md")
            directory = (basic / "directory.md").read_text(encoding="utf-8")
            definition = r.rest.load(folder / "blueprint.json")
            names = definition["candidate_pool"]
            assert [s[3:] for s in directory.splitlines() if s.startswith("## ")] == names
            service = object.__new__(r.Services)
            service.files = {}
            service.people = {n: {"username": n.replace(" ", "_")} for n in names}
            service.public = lambda name=None: (
                (basic / name).read_text(encoding="utf-8") if name
                else sorted(p.name for p in basic.glob("*.md")))
            assert service.dispatch("read_file", {"path": "/packet/directory.md"}) == directory
            assert service.dispatch("list_files", {"path": "/packet"}) == service.public()
            assert all(set(p) == {"name", "username"}
                       for p in service.dispatch("list_colleagues", {}))
            cfg = c.configuration({**slot, "attempt_id": "offline-fixture"}, output)
            assert cfg["condition"] == "R0" and cfg["agent_model"] == r.FULL
            first = next(p["request"] for p in r.frozen.batch_lines(
                old / full[task]["source"] / "api_io.jsonl")
                if p["stage"] == "request" and p["role"] == "agent")
            instruction = (Path(slot["original_run"]) / "public_instruction.md").read_text(encoding="utf-8")
            messages = r.rest.initial_messages(instruction, directory)
            expected = copy.deepcopy(first)
            expected["messages"] = messages
            assert first["messages"][0] == messages[0]
            assert first["tools"] == r.rest.TOOLS
            assert first["model"] == r.FULL and first["reasoning_effort"] == "none"
            assert messages[1]["content"].split("\n\nVISIBLE CANDIDATE DIRECTORY\n")[0] == instruction
            cfg["openai_key_env"] = "R0_OFFLINE_FAKE"
            os.environ["R0_OFFLINE_FAKE"] = "nonsecret-offline-fixture"
            if not (output / "first_actual_agent_request.json").exists():
                r.rest.save(output / "first_actual_agent_request.json", {"offline_fixture": True})

            class HTTP:
                def json(self, method, url, headers, request):
                    assert request == expected, "Only directory changes from full R1 wire"
                    return {"model": r.FULL, "service_tier": "default",
                            "usage": {"prompt_tokens": 1000, "completion_tokens": 10},
                            "choices": [{"finish_reason": "stop",
                                         "message": {"role": "assistant", "content": "fixture"}}]}

            class Ledger:
                def reserve(self, role, request):
                    return "offline", 32768

                def settle(self, call, role, usage, bound, maximum):
                    assert maximum == 2048

            r.Model(cfg, HTTP(), Ledger(), output).complete("agent", messages, r.rest.TOOLS)
        os.environ.pop("R0_OFFLINE_FAKE")
        cfg = c.configuration({**scope[0], "attempt_id": "fixture"}, output)
        ledger = r.Ledger(output / "fixture_ledger.jsonl", cfg)
        ledger.charges["fixture"] = r.rest.Decimal("0.1")
        ledger.settle("fixture", "agent", {
            "prompt_tokens": 1000, "completion_tokens": 10,
            "prompt_tokens_details": {"cached_tokens": 400}}, 32768, 2048)
        assert r.frozen.batch_lines(ledger.path)[0]["amount_usd"] == "0.00175"
    assert before == r.budget()
    for path, expected in r.rest.load(r.TOP / "source_freeze.json")["r1_new90_source_hashes"].items():
        assert r.rest.digest(Path(path)) == expected
    r.rest.save(r.ROOT / "offline_validation.json", {
        "passed": True, "runtime_sha256": r.rest.digest(r.ROOT / "runtime.py"),
        "controller_sha256": r.rest.digest(r.ROOT / "controller.py"),
        "R0_surface_cases": 60, "full_R1_wire_only_directory_changed": 60,
        "NPC_v6_unchanged": True, "shared_ledger_untouched": True,
        "no_external_or_paid_calls": True, "budget": before,
        "timestamp": r.rest.timestamp()})
    print("R0 offline validation passed:60 full-wire and public-tool surfaces; zero calls")


if __name__ == "__main__":
    main()
