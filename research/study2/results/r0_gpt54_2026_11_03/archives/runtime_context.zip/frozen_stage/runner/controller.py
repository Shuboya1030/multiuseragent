"""One serial controller, exactly 30 mini repeats and 60 GPT-5.4 controls."""
import ctypes
from ctypes import wintypes
import hashlib
import json
import msvcrt
import os
from pathlib import Path, PurePosixPath
import sys
import uuid

import runtime as r

ROOT, rest, batch = r.ROOT, r.rest, r.batch
QUEUE = []


def atomic(path, value):
    batch.atomic(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def publish(action):
    atomic(ROOT / "queue.json", QUEUE)
    atomic(ROOT / "progress.json", {
        "updated": rest.timestamp(), "pid": os.getpid(), "action": action,
        "counts": {g: {s: sum(x["group"] == g and x["state"] == s for x in QUEUE)
                        for s in sorted({x["state"] for x in QUEUE})}
                   for g in ("r0_gpt54",)},
        "budget": r.budget(), "slots": QUEUE, "STOP": str(ROOT / "STOP_REQUESTED"),
        "historical_180_or_243_not_modified": True, "R_prime_computed": False})


def gate():
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, wintypes.LPVOID,
                                  wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
    kernel.CreateFileW.restype = wintypes.HANDLE
    path = r.SOURCE_BASE / "shared_budget" / "exclusive.lock"
    handle = kernel.CreateFileW(str(path), 0xC0000000, 0, None, 3, 0x80, None)
    if handle == ctypes.c_void_p(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())
    fd = msvcrt.open_osfhandle(handle, os.O_RDWR)
    try:
        before = os.read(fd, 4096)
        expected = b"R0_GPT54_STOPPED:" if (ROOT / "zero_call_recovery.json").exists() else b"OPENAI90_STOPPED:"
        rest.require(before.startswith(expected),
                     "Shared account marker changed; do not overwrite")
        receipt = ROOT / "prior_shared_gate.json"
        if receipt.exists():
            receipt = ROOT / ("prior_shared_gate.recovery." + uuid.uuid4().hex + ".json")
        rest.save(receipt, {"content": before.decode()})
        os.lseek(fd, 0, os.SEEK_SET)
        os.write(fd, f"R0_GPT54_ACTIVE pid={os.getpid()}\n".encode())
        os.ftruncate(fd, os.lseek(fd, 0, os.SEEK_CUR))
        os.fsync(fd)
        return fd
    except BaseException:
        os.close(fd)
        raise


def configuration(slot, directory):
    config, _ = batch.config_for("openai", slot["task_id"], "formal")
    config.update(
        condition="R0", agent_model=slot["model"], authorization_ref=r.AUTH[slot["group"]],
        npc_model=r.MINI, npc_backend=r.BACKEND,
        npc_method_authorization_file=str(ROOT / "authorization.json"),
        readiness_file=str(directory / "repeat_readiness.json"),
        batch_dir=str(directory / "batch"),
        ledger_dir=str(r.SOURCE_BASE / "shared_budget"),
        token_count_receipts_dir=str(directory / "input_receipts"),
        authorized_rerun={"attempt_id": slot["attempt_id"],
                          "original_episode_id": slot["original_episode_id"]},
        role_prices_per_million={"agent": rest.PRICE_BOOK[slot["model"]],
                                 "npc": rest.PRICE_BOOK[r.MINI]},
    )
    rest.require(config["condition"] == "R0" and config["max_agent_steps"] == 64
                 and config["max_agent_output_tokens"] == 2048
                 and config["max_npc_output_tokens"] == 1024
                 and config["max_input_token_bound"] == 32768
                 and rest.positive(config["budget_usd"]) == rest.Decimal(20),
                 "Original research limits changed")
    return config


def episode(slot, config, output):
    output.mkdir(parents=True)
    old = rest.load(Path(slot["original_run"]) / "run_manifest.json")
    instruction = (Path(slot["original_run"]) / "public_instruction.md").read_text(encoding="utf-8")
    rest.require(instruction == rest.public_instruction(
        (rest.ROOT / "templates" / slot["task_id"] / "tac" / "task.md").read_text(encoding="utf-8"), config),
        "Original public task changed")
    rest.require(rest.digest(rest.ROOT / "templates" / slot["task_id"] / "blueprint.json")
                 == slot["task_blueprint_sha256"], "Original task facts changed")
    ident = str(uuid.uuid4())
    manifest = {k: config[k] for k in (
        "method", "phase", "authorization_ref", "budget_usd", "agent_model", "npc_model",
        "prices_per_million", "max_agent_steps", "max_npc_calls", "max_agent_output_tokens",
        "max_npc_output_tokens", "max_input_token_bound")}
    manifest.update(
        episode_id=ident, task_id=slot["task_id"], original_episode_id=slot["original_episode_id"],
        group=slot["group"], condition="R0", presentation=rest.PRESENTATION,
        original_npc_backend=old["npc_backend"], npc_backend=r.BACKEND,
        npc_implementation_sha256=rest.digest(ROOT / "frozen_repair.py"),
        npc_policy_sha256=hashlib.sha256(r.frozen.NPC_POLICY.encode()).hexdigest(),
        runner_sha256=rest.digest(Path(rest.__file__)), overlay_sha256=rest.digest(ROOT / "runtime.py"),
        controller_sha256=rest.digest(Path(__file__)), configuration_sha256=rest.config_digest(config),
        role_prices_per_million=config["role_prices_per_million"],
        task_blueprint_sha256=slot["task_blueprint_sha256"], instance_seed=slot["instance_seed"],
        api_random_seed="not_set_as_in_original", temperature="omitted_as_in_original",
        reasoning_effort="none", tool_choice="auto", parallel_tool_calls=False,
        complete_history_and_tools=True, no_automatic_retry=True,
        independent_repeat_not_replacement=True, published_originals_readonly=True,
        service_instance=rest.load(config["readiness_file"])["service_instance"], started=rest.timestamp())
    rest.save(output / "run_manifest.json", manifest)
    (output / "public_instruction.md").write_text(instruction, encoding="utf-8")
    slot.update(episode_id=ident, state="running", output=str(output))
    publish("Starting " + slot["group"] + "/" + slot["task_id"])
    services = r.Services(config, slot["task_id"], rest.Http(),
                          r.Model(config, rest.Http(),
                                  r.Ledger(r.SOURCE_BASE / "shared_budget" / "cost_ledger.jsonl", config),
                                  output), output, ident)
    terminal, complete = "not_started", False
    try:
        services.bootstrap()
        terminal = rest.agent_loop(services.model, services, config, output, instruction)
    except (rest.RestError, OSError, ValueError, KeyError, TypeError, IndexError) as error:
        terminal = "runtime_error"
        rest.save(output / "runtime_error.json", {
            "error_type": type(error).__name__, "message": str(error),
            "failure_kind": getattr(error, "failure_kind", "runtime_error"),
            "timestamp": rest.timestamp(), "no_replay": True})
    finally:
        rest.save(output / "workspace.json", services.files)
        (output / "workspace").mkdir()
        for path, contents in services.files.items():
            (output / "workspace" / PurePosixPath(path).name).write_text(contents, encoding="utf-8")
        try:
            rest.save(output / "trace_bundle.json", services.collect())
            complete = True
        except (rest.RestError, OSError, ValueError, KeyError, TypeError) as error:
            rest.save(output / "collection_error.json",
                      {"error_type": type(error).__name__, "message": str(error), "complete": False})
        rest.save(output / "status.json", {"terminal": terminal, "collection_complete": complete,
                                           "submitted": services.submitted, "finished": rest.timestamp()})
    if services.bootstrapped:
        summary = batch.audit(config, slot["task_id"], output)
    else:
        summary = {"state": "infrastructure_error", "episode_id": ident, "terminal": terminal,
                   "complete": complete, "note": "No fabricated evaluation for incomplete bootstrap"}
    rest.save(output / "controller_summary.json", summary)
    return summary


def preservation():
    baseline = rest.load(ROOT / "baseline.json")
    for path, spec in baseline["shared_prefixes"].items():
        raw = Path(path).read_bytes()[:spec["bytes"]]
        rest.require(hashlib.sha256(raw).hexdigest() == spec["sha256"], "Historical prefix changed")
    rest.require(set(r.budget()["unknown"]) >= set(baseline["budget"]["unknown"]),
                 "Historical unknown reservation released")
    for path, sha in baseline["source_hashes"].items():
        rest.require(rest.digest(Path(path)) == sha, "Read-only source changed")
    receipt = ROOT / "preservation_validation.json"
    if receipt.exists():
        receipt = ROOT / ("preservation_validation." + uuid.uuid4().hex + ".json")
    rest.save(receipt, {
        "source_hashes": len(baseline["source_hashes"]), "historical_prefixes_preserved": True,
        "original_unknown_reservations_preserved": True, "budget": r.budget(), "timestamp": rest.timestamp()})


def main():
    global QUEUE
    recovering = (ROOT / "zero_call_recovery.json").exists()
    if recovering:
        QUEUE = rest.load(ROOT / "queue.json")
        rest.require(len(QUEUE) == 60, "Zero-call recovery must retain the signed60 queue")
    rest.verify_source()
    validation = rest.load(ROOT / "offline_validation.json")
    rest.require(validation["passed"] and validation["runtime_sha256"] == rest.digest(ROOT / "runtime.py")
                 and validation["controller_sha256"] == rest.digest(Path(__file__)),
                 "Offline validation absent or changed")
    rest.require((not (ROOT / "queue.json").exists() or recovering) and not (ROOT / "STOP_REQUESTED").exists(),
                 "Existing attempt state; never automatically restart")
    rest.require(rest.load(r.SOURCE_BASE / "progress.json")["active_controller"]["status"] == "stopped",
                 "Historical controller not stopped")
    with (ROOT / "controller.lock").open("x", encoding="utf-8") as file:
        file.write(json.dumps({"pid": os.getpid(), "stop_file": str(ROOT / "STOP_REQUESTED")}))
    fd = None
    try:
        fd = gate()
        budget = r.budget()
        rest.require(len(budget["unknown"]) == 5, "Unknown call set changed since approval")
        if recovering:
            proof = rest.load(ROOT / "zero_call_recovery.json")
            rest.require(proof["model_calls_before_recovery"] == 0 and r.budget() == proof["budget"],
                         "Zero-call recovery proof/budget changed")
            rest.require(not (ROOT / "episodes").exists(), "Never recover/replay a model attempt")
            QUEUE = rest.load(ROOT / "queue.json")
            rest.require(len(QUEUE) == 60 and all(s["state"] in ("pending", "preparing", "blocked_controller") for s in QUEUE),
                         "Recovery is only pre-first-request setup")
            rest.require([s["attempt_id"] for s in QUEUE] == proof["original_attempt_ids_retained"],
                         "Never allocate replacement attempts during zero-call recovery")
            for slot in QUEUE:
                slot["state"] = "pending"
        frozen = rest.load(r.TOP / "source_freeze.json")
        prefixes = {}
        for name in ("cost_ledger.jsonl", "kimi_account_pacing_v1.jsonl",
                     "rest_rate_pacing.jsonl", "chat_post_pacing.jsonl"):
            path = r.SOURCE_BASE / "shared_budget" / name
            prefixes[str(path)] = {"bytes": path.stat().st_size, "sha256": rest.digest(path)}
        hashes = rest.load(r.SOURCE_BASE / "final_r1_evaluation_v1" / "freeze.json")["source_hashes"]
        hashes.update(rest.load(r.TOP / "source_freeze.json")["r1_new90_source_hashes"])
        hashes[str(r.CURSOR)] = rest.digest(r.CURSOR)
        hashes[str(r.SOURCE_BASE / "final_r1_evaluation_v1" / "all_attempt_evaluations.json")] = \
            rest.digest(r.SOURCE_BASE / "final_r1_evaluation_v1" / "all_attempt_evaluations.json")
        if not recovering:
            rest.save(ROOT / "baseline.json",
                      {"shared_prefixes": prefixes, "source_hashes": hashes, "budget": budget})
            QUEUE = [{**slot, "attempt_id": str(uuid.uuid4()), "state": "pending"}
                     for slot in rest.load(r.TOP / "scope.json")]
        rest.require(len(QUEUE) == len({(s["group"], s["task_id"]) for s in QUEUE}) == 60,
                     "Authorized scope mismatch")
        authorization = {
            "groups": r.AUTH, "max_total_episodes": 60, "attempts_per_slot": 1,
            "r0_gpt54_all": 60, "cap_usd": 20,
            "extra_pilots_or_probes": 0, "R_prime_computed": False,
            "NPC_backend": r.BACKEND, "configuration": frozen}
        if not recovering:
            rest.save(ROOT / "authorization.json", authorization)
            (ROOT / "stage").mkdir()
            rest.save(ROOT / "stage" / "service_cursor.json", rest.load(r.CURSOR))
        r.install()
        publish("Prepared 60 authorized R0 slots")
        for position, slot in enumerate(QUEUE):
            r.stop_check()
            directory = ROOT / "stage" / slot["group"] / slot["task_id"]
            output = ROOT / "episodes" / slot["group"] / slot["task_id"]
            rest.require(not directory.exists() and not output.exists(), "Never replace an attempt")
            slot["state"] = "preparing"
            publish("Preparing " + slot["group"] + "/" + slot["task_id"])
            config = configuration(slot, directory)
            batch.prepare(config, slot["group"], slot["task_id"], "formal", directory, output)
            old_ready = rest.load(directory / "readiness.json")
            rest.save(directory / "repeat_readiness.json", {
                "service_instance": old_ready["service_instance"], "NPC_backend": r.BACKEND,
                "nonpaid_local_isolation_verified": True,
                "old_guarded_preflight_not_new_validation": True,
                "original_public_task_and_directory_unchanged": True})
            result = episode(slot, config, output)
            slot.update(state=result["state"], result=result)
            rest.append(ROOT / "results.jsonl", {"group": slot["group"], "task_id": slot["task_id"], **result})
            publish("Terminated " + slot["group"] + "/" + slot["task_id"])
            print("EPISODE_COMPLETE", json.dumps({
                "group": slot["group"], "task_id": slot["task_id"], "episode_id": slot["episode_id"],
                "terminal": result["terminal"], "state": result["state"],
                "agent_calls": result.get("agent_calls"), "NPC_calls": result.get("npc_calls"),
                "cost_usd": result.get("cost_usd")}), flush=True)
            if position == 2 and result["state"] != "infrastructure_error":
                rest.save(ROOT / "first_three_admission.json", {
                    "passed": True, "scope": [s["task_id"] for s in QUEUE[:3]],
                    "not_three_business_passes": True, "no_extra_attempts": True,
                    "budget": r.budget(), "timestamp": rest.timestamp()})
            if result["state"] == "infrastructure_error":
                raise r.frozen.RepairError("Stop after recorded infrastructure error; no automatic retry",
                                           "episode_infrastructure_error")
        preservation()
        publish("All 60 R0 attempts terminated; semantic review pending")
        rest.save(ROOT / "completion.json", {"all_60_terminal": True, "budget": r.budget()})
    except (rest.RestError, OSError, ValueError, KeyError, TypeError, IndexError) as error:
        receipt = ROOT / "controller_error.json"
        if receipt.exists():
            receipt = ROOT / ("controller_error." + uuid.uuid4().hex + ".json")
        rest.save(receipt, {
            "message": str(error), "error_type": type(error).__name__,
            "failure_kind": getattr(error, "failure_kind", "controller_error"), "timestamp": rest.timestamp(),
            "no_automatic_retry": True})
        for slot in QUEUE:
            if slot["state"] in ("pending", "preparing"):
                slot.update(state="blocked_controller", block_reason=str(error))
        publish("Controller stopped: " + str(error))
        if (ROOT / "baseline.json").exists():
            preservation()
        raise
    finally:
        if fd is not None:
            os.lseek(fd, 0, os.SEEK_SET)
            os.write(fd, b"R0_GPT54_STOPPED: inspect own queue; never replay./n")
            os.ftruncate(fd, os.lseek(fd, 0, os.SEEK_CUR))
            os.fsync(fd)
            os.close(fd)
        receipt = ROOT / "controller.finished.json"
        if receipt.exists():
            receipt = ROOT / ("controller.finished." + uuid.uuid4().hex + ".json")
        (ROOT / "controller.lock").rename(receipt)


if __name__ == "__main__":
    main()
