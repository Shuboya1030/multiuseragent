"""Fix the pacing boundary race without changing the persistent account limit."""
from contextlib import contextmanager
import datetime as dt
import msvcrt
import uuid

import kimi_account_pacing_v1 as original

VERSION = "kimi-account-rpm3-v2-clock-boundary"


class Pacer(original.Pacer):
    @contextmanager
    def slot(self):
        with (self.directory / "kimi_account_request.lock").open("a+b") as lock:
            if lock.tell() == 0:
                lock.write(b"0")
                lock.flush()
            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
            try:
                rows = self.rows()
                sent = [r["sent_at_epoch"] for r in rows if r["event"] == "send"]
                pauses = [r["not_before_epoch"] for r in rows if r["event"] == "cooldown"]
                target = max([max(sent) + original.MIN_INTERVAL if sent else 0] + pauses)
                while True:
                    if original.PRE_SEND_CHECK is not None:
                        original.PRE_SEND_CHECK()
                    now = self.clock()
                    remaining = target - now
                    if remaining <= 0:
                        break
                    self.sleep(min(1.0, remaining))
                ident = str(uuid.uuid4())
                original.rest.append(self.log, dict(
                    event="send", id=ident, version=VERSION,
                    sent_at_epoch=now,
                    actual_send_utc=dt.datetime.fromtimestamp(now, dt.timezone.utc).isoformat(),
                    min_interval_seconds=original.MIN_INTERVAL, no_automatic_retry=True))
                yield ident
            finally:
                lock.seek(0)
                msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)


def install():
    original.Pacer = Pacer
    original.VERSION = VERSION
