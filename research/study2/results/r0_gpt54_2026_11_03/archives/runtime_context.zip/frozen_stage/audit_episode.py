"""Independent frozen artifact grader and request/delivery/usage audit; no model calls."""
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = Path(__file__).resolve().parents[1] / "task_inputs"
sys.path[:0] = [str(ROOT / "runtime"), str(BASE)]
import rest_runner as rest


def audit(config, task, run):
    rows = [json.loads(line) for line in (run / "api_io.jsonl").read_text(
        encoding="utf-8").splitlines()] if (run / "api_io.jsonl").exists() else []
    requests = [r for r in rows if r["stage"] == "request"]
    agents = [r["request"] for r in requests if r["role"] == "agent"]
    expected = rest.initial_messages((run / "public_instruction.md").read_text(encoding="utf-8"),
        (ROOT / "templates" / task / "tac" / "documents_R0" / "directory.md").read_text(encoding="utf-8"))
    if config["agent_model"] == "claude-haiku-5-5":
        native = rest.provider_adapters.build_request(config["agent_model"], expected, rest.TOOLS).body
        presented = bool(agents) and all(r["system"] == native["system"]
            and r["messages"][0] == native["messages"][0] and r["tools"] == native["tools"] for r in agents)
    else:
        presented = bool(agents) and all(r["messages"][:2] == expected and r["tools"] == rest.TOOLS for r in agents)
    rest.save(run / "actual_input_audit.json", {
        "complete_public_directory_present": presented, "all_agent_requests_retain_directory": presented,
        "initial_messages_sha256": rest.config_digest(expected), "agent_requests": len(agents)})
    status = rest.episode_status(run)
    tools = [json.loads(line) for line in (run / "tool_events.jsonl").read_text(
        encoding="utf-8").splitlines()] if (run / "tool_events.jsonl").exists() else []
    delivery = False
    evaluation = None
    if status["collection_complete"]:
        raw, account = rest.load(run / "raw_chat.json"), rest.load(run / "account_map.json")
        posts = [t for t in tools if t["tool"] == "post_message" and not t["is_error"]]
        delivery = any(any(m["_id"] == p["result"]["message_id"] and m["u"]["_id"] == account["agent_id"]
            and "/workspace/deliverable.json" in m["msg"] for messages in raw["channels"].values()
            for m in messages) for p in posts)
        bundle = rest.load(run / "trace_bundle.json")
        if (run / "private_evidence_reviews.json").exists():
            bundle["evidence_reviews"] = rest.load(run / "private_evidence_reviews.json")
        rest.save(run / "reviewed_trace_bundle.json", bundle)
        env = dict(os.environ, STUDY2_TRACE_PATH=str(run / "reviewed_trace_bundle.json"),
            STUDY2_DELIVERABLE_PATH=str(run / "workspace" / "deliverable.json"),
            STUDY2_RESULT_PATH=str(run / "evaluation.json"), PYTHONDONTWRITEBYTECODE="1")
        result = subprocess.run([sys.executable, str(ROOT / "templates" / task / "tac" / "evaluator.py")],
            env=env, capture_output=True, text=True)
        if result.returncode:
            rest.save(run / "grader_error.json", {"returncode": result.returncode,
                "stderr": result.stderr, "decision": "needs_review; no result invented"})
        else:
            evaluation = rest.load(run / "evaluation.json")
    ledger = [json.loads(line) for line in (Path(config["ledger_dir"]) / "cost_ledger.jsonl").read_text(
        encoding="utf-8").splitlines()]
    settled = {r["id"]: r for r in ledger if r["event"] == "settle"}
    reserves = {r["id"]: r for r in ledger if r["event"] == "reserve"}
    ids = {r["call_id"] for r in requests}
    usage = {"agent": {"input_tokens": 0, "output_tokens": 0},
             "npc": {"input_tokens": 0, "output_tokens": 0}}
    for r in requests:
        if r["call_id"] in settled:
            u = settled[r["call_id"]]["usage"]
            usage[r["role"]]["input_tokens"] += u["prompt_tokens"]
            usage[r["role"]]["output_tokens"] += u["completion_tokens"]
    strict = None if not evaluation or evaluation["evaluation_status"] != "scored" else (
        evaluation["base_pass"] is True and delivery and status["submitted"] is True)
    infrastructure = not status["collection_complete"] or status["terminal"] == "runtime_error" or not presented
    state = ("infrastructure_error" if infrastructure else "needs_review" if strict is None
             else "success" if strict else "task_failure")
    summary = {"task_id": task, "model": config["agent_model"], "phase": config["phase"],
        "episode_id": rest.load(run / "run_manifest.json")["episode_id"], "state": state,
        "terminal": status["terminal"], "complete": status["collection_complete"],
        "strict_success": strict if not infrastructure else None, "channel_delivery_passed": delivery,
        "evaluation": evaluation, "actual_directory_verified": presented, "usage_by_role": usage,
        "agent_calls": len(agents), "npc_calls": len(requests) - len(agents),
        "unknown_usage_call_ids": sorted(ids - settled.keys()),
        "cost_usd": str(sum((rest.Decimal((settled.get(i) or reserves[i])["amount_usd"]) for i in ids),
                           rest.Decimal(0))), "no_automatic_retry": True}
    rest.save(run / "episode_audit.json", summary)
    return summary
