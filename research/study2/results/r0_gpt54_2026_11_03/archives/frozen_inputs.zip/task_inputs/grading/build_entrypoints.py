"""Export private, post-agent grading entry points. Never mount them in OpenHands."""
import json
import pathlib
import shutil
import sys

R = pathlib.Path(__file__).resolve().parents[1]

TAC_EVALUATOR = '''"""Private post-agent evaluator for {task_id}. Not an agent runtime file."""
import json
import os
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'grading'))
from scorer import score_bundle


def evaluate():
    bp = json.loads((HERE / 'grading' / 'blueprint_private.json').read_text(encoding='utf-8'))
    costs = json.loads((HERE / 'grading' / 'costs.json').read_text(encoding='utf-8'))
    bundle = json.loads(pathlib.Path(os.environ['STUDY2_TRACE_PATH']).read_text(encoding='utf-8'))
    answer_path = pathlib.Path(os.environ['STUDY2_DELIVERABLE_PATH'])
    if answer_path.exists():
        answer = json.loads(answer_path.read_text(encoding='utf-8'))
    else:
        print('No deliverable was submitted', file=sys.stderr)
        answer = None
    return score_bundle(bp, answer, bundle, costs)


def grade_checkpoints(trajectory=''):
    from scoring import Result, Checkpoint
    result = evaluate()
    if result['evaluation_status'] != 'scored':
        raise ValueError('Private evidence adjudication required before checkpoint scoring')
    checkpoints = [
        Checkpoint(1, int(result['submitted'])),
        Checkpoint(2, int(result['base_pass'])),
        Checkpoint(1, int(result['process']['all_nodes_satisfied'])),
        Checkpoint(1, int(result['process']['order_ok'])),
    ]
    if result['help_class'] == 'Optional-help':
        checkpoints.append(Checkpoint(2, int(round(2 * result['quality_score']))))
    return Result(checkpoints)


if __name__ == '__main__':
    result = evaluate()
    with pathlib.Path(os.environ['STUDY2_RESULT_PATH']).open('x', encoding='utf-8') as output:
        json.dump(result, output, ensure_ascii=False, indent=2)
        output.write('\\n')
'''


def write_if_changed(path, text):
    content = text.encode("utf-8")
    if not path.exists() or path.read_bytes() != content:
        path.write_bytes(content)


def main():
    sys.path.insert(0, str(R / "grading"))
    from scorer import costs_from_roster, GRADER_VERSION
    costs = costs_from_roster(json.loads((R / "organization" / "roster.json").read_text(encoding="utf-8")))
    count = 0
    for d in sorted((R / "templates").iterdir()):
        bp = json.loads((d / "blueprint.json").read_text(encoding="utf-8"))
        bp["output_contract"]["grading_implemented"] = True
        bp["output_contract"]["grader"] = {
            "version": GRADER_VERSION, "module": "grading/scorer.py",
            "tac_entry": "tac/evaluator.py", "execution_boundary": "private_post_agent",
            "release_evidence": "content_bound_private_adjudication",
        }
        encoded = json.dumps(bp, ensure_ascii=False, indent=2) + "\n"
        write_if_changed(d / "blueprint.json", encoded)
        g = d / "tac" / "grading"
        g.mkdir(parents=True, exist_ok=True)
        write_if_changed(g / "blueprint_private.json", encoded)
        write_if_changed(g / "costs.json", json.dumps(costs, indent=2) + "\n")
        source = R / "grading" / "scorer.py"
        target = g / "scorer.py"
        if not target.exists() or target.read_bytes() != source.read_bytes():
            shutil.copyfile(source, target)
        write_if_changed(d / "tac" / "evaluator.py", TAC_EVALUATOR.format(task_id=bp["task_id"]))
        count += 1
    print("Private grading entry points written for", count, "tasks; run export_tasks.py next")


if __name__ == "__main__":
    main()
