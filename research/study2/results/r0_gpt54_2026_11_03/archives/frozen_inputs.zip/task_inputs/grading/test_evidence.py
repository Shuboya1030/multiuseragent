"""Regression checks use synthetic messages, never live models or services."""
import copy
import json
import pathlib
import unittest

from scorer import score, score_bundle, content_hash, _text_has
from selftest import gold_trace

R = pathlib.Path(__file__).resolve().parents[1]


def fixture(task_id):
    bp = json.loads((R / "templates" / task_id / "blueprint.json").read_text(encoding="utf-8"))
    events = [dict(e, message_id=f"msg-{i}", episode_id="synthetic-regression", timestamp=e["timestamp"] + "Z")
              for i, e in enumerate(gold_trace(bp))]
    reviews = []
    for i, e in enumerate(events):
        if e["actor"] == "npc":
            request = events[i - 1]
            reviews.append({
                "node_id": e["synthetic_release_for"], "message_id": e["message_id"],
                "content_sha256": content_hash(e["content"]), "request_id": request["message_id"],
                "request_content_sha256": content_hash(request["content"]),
                "decision": "accept", "reviewer": "synthetic-regression",
                "reason": "Synthetic gold release, not a live NPC decision.",
            })
    return bp, events, reviews


class EvidenceTests(unittest.TestCase):
    def setUp(self):
        self.bp, self.events, self.reviews = fixture("m-high-service-cutover")
        self.answer = self.bp["full_information_reference"]

    def grade(self, events=None, reviews=None):
        return score(self.bp, self.answer, self.events if events is None else events,
                     evidence_reviews=self.reviews if reviews is None else reviews)

    def test_reviewed_reference_passes(self):
        result = self.grade()
        self.assertTrue(result["base_pass"])
        self.assertTrue(result["process"]["order_ok"])

    def test_unreviewed_affirmative_is_unknown_not_success(self):
        result = self.grade(reviews=[])
        self.assertIsNone(result["base_pass"])
        self.assertEqual(result["evaluation_status"], "needs_evidence_review")
        self.assertIsNone(result["process"]["all_nodes_satisfied"])
        self.assertIsNone(result["process"]["order_ok"])
        self.assertGreater(len(result["errors"]["unverified_claims"]), 0)
        self.assertEqual(result["errors"]["unsupported_claims"], [])

    def test_negated_and_quoted_ids_do_not_self_certify(self):
        for prefix in ("I did NOT authorize: ", "The request merely quoted: "):
            events = copy.deepcopy(self.events)
            for e in events:
                if e["actor"] == "npc":
                    e["content"] = prefix + e["content"]
            result = self.grade(events, [])
            self.assertIsNot(result["base_pass"], True)
            self.assertEqual(result["evaluation_status"], "needs_evidence_review")

    def test_orphan_reversed_replies_are_not_success(self):
        events = [e for e in reversed(self.events) if e["actor"] == "npc"]
        result = self.grade(events, [])
        self.assertFalse(result["base_pass"])
        self.assertEqual(result["process"]["nodes_satisfied"], [])

    def test_review_cannot_survive_reply_mutation(self):
        events = copy.deepcopy(self.events)
        events[1]["content"] = "I did NOT authorize " + events[1]["content"]
        with self.assertRaisesRegex(ValueError, "content hash"):
            self.grade(events)

    def test_review_cannot_survive_request_mutation(self):
        events = copy.deepcopy(self.events)
        events[0]["content"] = "Use an unrelated project without the necessary context"
        with self.assertRaisesRegex(ValueError, "request binding"):
            self.grade(events)

    def test_reviewed_refusal_is_not_success(self):
        reviews = copy.deepcopy(self.reviews)
        reviews[0]["decision"] = "reject"
        reviews[0]["is_refusal"] = True
        reviews[0]["reason"] = "Synthetic refusal"
        result = self.grade(reviews=reviews)
        self.assertFalse(result["base_pass"])
        self.assertGreater(result["errors"]["rejections"], 0)

    def test_inadmissible_release_is_not_an_observed_refusal(self):
        reviews = copy.deepcopy(self.reviews)
        reviews[0]["decision"] = "reject"
        result = self.grade(reviews=reviews)
        self.assertFalse(result["base_pass"])
        self.assertEqual(result["errors"]["rejections"], 0)

    def test_duplicate_or_stale_reviews_fail(self):
        with self.assertRaisesRegex(ValueError, "Duplicate evidence"):
            self.grade(reviews=self.reviews + [self.reviews[0]])
        reviews = copy.deepcopy(self.reviews)
        reviews[0]["message_id"] = "not-in-episode"
        with self.assertRaisesRegex(ValueError, "this trace"):
            self.grade(reviews=reviews)

    def test_duplicate_messages_fail(self):
        with self.assertRaisesRegex(ValueError, "Duplicate trace"):
            self.grade(self.events + [self.events[0]])

    def test_request_without_reply_is_not_a_rejection(self):
        events = [e for e in self.events if e["actor"] == "agent"]
        result = self.grade(events, [])
        self.assertEqual(result["errors"]["rejections"], 0)
        self.assertFalse(result["base_pass"])

    def test_invalid_actor_fails(self):
        events = copy.deepcopy(self.events)
        events[1]["actor"] = "system"
        with self.assertRaisesRegex(ValueError, "normalized"):
            self.grade(events)

    def test_all_required_nodes_are_necessary_across_60_tasks(self):
        for directory in sorted((R / "templates").iterdir()):
            bp, events, reviews = fixture(directory.name)
            if bp["help_class"] != "Must-help":
                continue
            for node in bp["gold_dag"]["nodes"]:
                removed = {e["message_id"] for e in events if e.get("synthetic_release_for") == node["id"]}
                result = score(bp, bp["full_information_reference"],
                               [e for e in events if e["message_id"] not in removed],
                               evidence_reviews=[r for r in reviews if r["message_id"] not in removed])
                with self.subTest(task=bp["task_id"], node=node["id"]):
                    self.assertFalse(result["base_pass"])

    def test_optional_unknown_quality_is_not_zero(self):
        bp, events, _ = fixture("o-medium-event-package")
        result = score(bp, bp["full_information_reference"], events)
        self.assertTrue(result["base_pass"])
        self.assertIsNone(result["quality_score"])
        self.assertIsNone(result["T"])
        self.assertIsNone(result["R"])

    def test_optional_no_contact_remains_valid(self):
        bp, _, _ = fixture("o-medium-event-package")
        result = score(bp, bp["no_contact_reference"], [])
        self.assertTrue(result["base_pass"])
        self.assertEqual(result["quality_score"], 0)

    def test_partial_identifier_does_not_match(self):
        self.assertFalse(_text_has("NOT-CC-628suffix", ("str", "cc-628")))
        self.assertTrue(_text_has("Mapping: CC-628.", ("str", "cc-628")))

    def test_bundle_requires_complete_episode_scope(self):
        bundle = {"task_id": self.bp["task_id"], "episode_id": "synthetic-regression",
                  "complete": True, "events": self.events, "evidence_reviews": self.reviews}
        self.assertTrue(score_bundle(self.bp, self.answer, bundle)["base_pass"])
        bundle["complete"] = False
        with self.assertRaisesRegex(ValueError, "Incomplete"):
            score_bundle(self.bp, self.answer, bundle)
        bundle["complete"] = True
        bundle["episode_id"] = "other-episode"
        with self.assertRaisesRegex(ValueError, "Message is missing"):
            score_bundle(self.bp, self.answer, bundle)


if __name__ == "__main__":
    unittest.main()
