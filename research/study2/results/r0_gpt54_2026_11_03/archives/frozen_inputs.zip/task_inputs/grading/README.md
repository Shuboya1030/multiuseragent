# Study 2 v2 private grader

Version `study2-v2-grader-1.1`. No model calls. All 60 tasks use the same
blueprint-driven code. This version does **not** claim that natural-language
NPC evidence can be adjudicated by token matching.

## Inputs and private evidence review

`score` accepts a blueprint, deliverable, normalized DM list, costs, weights
and optional `evidence_reviews`. A message contains `timestamp`, `actor`
(`agent` or `npc`), `colleague`, `content` and a unique `message_id`.
The operational `score_bundle` additionally requires:

```json
{
  "task_id": "m-low-ledger-allocation",
  "episode_id": "unique-run-id",
  "complete": true,
  "events": [],
  "evidence_reviews": []
}
```

Each event must belong to this episode and have a timezone-aware timestamp.
`complete=true` is a private export assertion: the trusted collector must
verify all pages/rooms and preserve pool-external contacts before setting it.
Never trust an Agent-authored bundle or mark an export failure complete.
Channel delivery is separate evidence and is not scored by this DM grader.

Private reviewers inspect the actual request, context, affirmative release,
negation/quotation, identity and prerequisites. A review names `node_id`,
`message_id`, `request_id`, `decision` (`accept`/`reject`), `reviewer`, `reason`,
optional `is_refusal=true` for a verified refusal, and SHA-256 values
`content_sha256` and `request_content_sha256` of the exact
UTF-8 reply/request text. Only the private evaluator receives reviews; they
are not NPC instructions or Agent-visible fields.

Node satisfaction requires an earlier request to the admissible colleague,
all prerequisite releases before that request, and an accepting private
review bound to both messages. Missing/stale reviews never grant success.
Token and context matches are diagnostics only. A matching unreviewed reply
is **unknown**, including denials or quotations; without reliable linguistic
evidence the grader must not choose a success-shaped interpretation.
Review integrity is a trusted-input boundary, not a cryptographic proof that
a reviewer made the right decision.

## Results

- Must: `base_pass` requires the full valid artifact and supported nodes.
  Correct artifacts with unresolved release evidence get `base_pass=null`.
  `order_ok` records release order. `T` remains raw artifact field accuracy,
  **not** strict workflow success.
- Optional: a valid no-contact baseline still passes with quality 0. Supported
  improvements yield quality 0-1. If adopted improvements have unresolved
  evidence, quality, T and R are null, not zero. Partial adoption remains
  separately flagged as internally inconsistent.
- `evaluation_status=needs_evidence_review` and `unknown_nodes` expose
  unresolved evidence. No checkpoint conversion is allowed until it is scored.
- Costs, first contact, premature requests, interruptions and error components
  remain separate. An unanswered request is not counted as an observed NPC
  rejection; rejected evidence is not automatically an observed refusal.
  Authority intent is still a keyword heuristic.

The existing T mapping, interruption costs and weights are retained as
versioned descriptive quantities, not newly approved scientific endpoints.
No weight sweep is introduced. Field equivalences retain numeric/case/time
normalization and order-insensitive lists. Strict full-workflow success also
requires the separate channel-delivery checks where the task requests them.

## Commands

From repository root in PowerShell:

```powershell
$root = 'research\study2\task_generation_v2'
python "$root\grading\build_entrypoints.py"
python "$root\tools\export_tasks.py"
python "$root\grading\selftest.py" --output <new-report.json>
python -m unittest discover -s "$root\grading" -p "test_*.py" -v
python "$root\grading\run_local.py" <task_id> <deliverable.json> <trace-bundle.json>
```

Reports are create-only. The checked-in `selftest_results.json` is preserved
as the historical 1.0 report, not evidence that 1.1 has run live.
The 289 reference cases use explicitly synthetic reviewed releases.
`test_evidence.py` adds unreviewed/negated/quoted/orphan/replay cases and
required-node ablations. These are unit checks, not independent task
acceptance, true no-contact solvability proofs, or pilot episodes.

The generated `tac\evaluator.py` runs in a private post-agent context.
Set `STUDY2_TRACE_PATH`, `STUDY2_DELIVERABLE_PATH` and `STUDY2_RESULT_PATH`;
its CLI writes a full score JSON without overwriting existing results.
Its optional official `grade_checkpoints` adapter needs TAC's `scoring`
module and refuses unresolved evidence. The legacy ungraded image lacks
that module; no compatibility is claimed until runtime integration.
