"""Exercise the generated private entry point without TAC services or model calls."""
import importlib.util
import json
import os
import pathlib
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from test_evidence import fixture

R = pathlib.Path(__file__).resolve().parents[1]


class PrivateEntrypointTests(unittest.TestCase):
    def test_generated_cli_scores_complete_bundle_and_refuses_overwrite(self):
        bp, events, reviews = fixture("m-low-ledger-allocation")
        entrypoint = R / "templates" / bp["task_id"] / "tac" / "evaluator.py"
        with tempfile.TemporaryDirectory(prefix="study2-grader-") as temp:
            root = pathlib.Path(temp)
            answer, trace, result = root / "answer.json", root / "trace.json", root / "result.json"
            answer.write_text(json.dumps(bp["full_information_reference"]), encoding="utf-8")
            trace.write_text(json.dumps({
                "task_id": bp["task_id"], "episode_id": "synthetic-regression",
                "complete": True, "events": events, "evidence_reviews": reviews,
            }), encoding="utf-8")
            env = dict(os.environ, STUDY2_TRACE_PATH=str(trace), STUDY2_DELIVERABLE_PATH=str(answer),
                       STUDY2_RESULT_PATH=str(result), PYTHONDONTWRITEBYTECODE="1")
            process = subprocess.run([sys.executable, str(entrypoint)], env=env, capture_output=True, text=True)
            self.assertEqual(process.returncode, 0, process.stderr)
            saved = result.read_bytes()
            self.assertTrue(json.loads(saved)["base_pass"])
            repeated = subprocess.run([sys.executable, str(entrypoint)], env=env, capture_output=True, text=True)
            self.assertNotEqual(repeated.returncode, 0)
            self.assertEqual(result.read_bytes(), saved)

    def test_generated_entrypoint_rejects_incomplete_export(self):
        entrypoint = R / "templates" / "m-low-ledger-allocation" / "tac" / "evaluator.py"
        spec = importlib.util.spec_from_file_location("private_test_evaluator", entrypoint)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        with tempfile.TemporaryDirectory(prefix="study2-incomplete-") as temp:
            root = pathlib.Path(temp)
            trace, answer = root / "trace.json", root / "answer.json"
            trace.write_text(json.dumps({"complete": False}), encoding="utf-8")
            answer.write_text("{}", encoding="utf-8")
            with patch.dict(os.environ, {"STUDY2_TRACE_PATH": str(trace), "STUDY2_DELIVERABLE_PATH": str(answer)}):
                with self.assertRaisesRegex(ValueError, "Incomplete"):
                    module.evaluate()


if __name__ == "__main__":
    unittest.main()
