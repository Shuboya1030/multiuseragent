"""Offline post-agent grading from a complete, episode-scoped trace bundle."""
import argparse
import json
import pathlib
import sys

from scorer import score_bundle, costs_from_roster

R = pathlib.Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("task_id", choices=sorted(p.name for p in (R / "templates").iterdir() if p.is_dir()))
    parser.add_argument("deliverable", type=pathlib.Path)
    parser.add_argument("trace_bundle", type=pathlib.Path)
    args = parser.parse_args()
    bp = json.loads((R / "templates" / args.task_id / "blueprint.json").read_text(encoding="utf-8"))
    costs = costs_from_roster(json.loads((R / "organization" / "roster.json").read_text(encoding="utf-8")))
    bundle = json.loads(args.trace_bundle.read_text(encoding="utf-8"))
    if args.deliverable.exists():
        answer = json.loads(args.deliverable.read_text(encoding="utf-8"))
    else:
        print("No deliverable was submitted", file=sys.stderr)
        answer = None
    print(json.dumps(score_bundle(bp, answer, bundle, costs), indent=2))


if __name__ == "__main__":
    main()
