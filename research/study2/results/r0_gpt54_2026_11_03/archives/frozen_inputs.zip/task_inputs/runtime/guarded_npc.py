"""Versioned deterministic disclosure; the LLM selects only a bounded speaking style."""
import importlib.util
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("npc_frozen_value_matcher", ROOT / "grading" / "scorer.py")
scorer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(scorer)
BACKEND = "controlled_rest_guarded_v4"
STYLES = {
    "concise": "Here is what I can share.",
    "friendly": "Thanks for checking. Here is what I can share.",
    "formal": "I checked the records I hold.",
}


def context_present(request, context):
    normalized = scorer._norm_str(request)
    target = scorer._norm_str(context)
    if re.search(r"\b(?:not|incorrect|wrong|instead of|rather than)\s+" + re.escape(target) + r"(?!\w)", normalized):
        return False
    numeric = scorer._num(context)
    if numeric is not None:
        # Exclude numbers embedded in dates, clocks and identifiers.
        return any(scorer.same_value(numeric, match.group()) for match in
                   re.finditer(r"(?<![\w.:\-])\d[\d,]*(?:\./d+)?(?![/w.:]|-/d)", request))
    return all(scorer._text_has(request, token)
               for token in (scorer._tokens(context) or scorer._words(context)))


def plan(blueprint, person, request, released):
    nodes = blueprint["gold_dag"]["nodes"]
    own = [r for r in blueprint["hidden_information"] if r["holder"] == person]
    allowed, facts = [], {}
    for record in own:
        if not record["facts"]:
            continue
        bindings = [node for node in nodes if record["id"] in node["information_ids"]
                    and person in node["admissible_recipients"]]
        if len(bindings) != 1:
            raise ValueError("Record must have exactly one frozen DAG binding")
        node = bindings[0]
        if not set(node["requires"]) <= set(released) or not all(
                context_present(request, context) for context in record["required_context"]):
            continue
        for key, value in record["facts"].items():
            if key in facts and facts[key] != value:
                raise ValueError("Conflicting eligible record fields")
            facts[key] = value
        allowed.append(record["id"])
    completed = [node["id"] for node in nodes if node["information_ids"]
                 and set(node["information_ids"]) <= set(allowed)
                 and set(node["requires"]) <= set(released)]
    if facts:
        body = "Authorized record:\n" + json.dumps(facts, ensure_ascii=False, sort_keys=True)
    else:
        routes = []
        for record in own:
            if not record["facts"]:
                match = re.search(r"\bsay\s+(.*?)(?:;|$)", record["release_rule"], re.I)
                if match:
                    routes.append(match.group(1).rstrip("."))
        body = ("Routing note: " + "; ".join(routes) + ".") if routes else (
            "I cannot release a task-local record without the required context and prior records.")
    return {"record_ids": allowed, "completed_nodes": completed, "body": body,
            "mode": "release" if facts else "routing_or_refusal"}


def render(style, decision):
    return STYLES[style] + "\n" + decision["body"]
