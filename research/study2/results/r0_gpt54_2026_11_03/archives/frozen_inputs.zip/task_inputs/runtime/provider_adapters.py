"""Provider wire translation. No transport or environment access.

Call build_request(model, messages, tools), supply credentials in the caller, then
normalize_response(model, decoded_json). NPC routing remains the caller's job.
All outputs are detached copies. Errors must abort the decision, not be retried
as an empty assistant response. Prices/budget enforcement are outside this module.
Keep the complete normalized assistant in Claude history, including its private
_anthropic_content metadata: validated native blocks replay in their exact order.
The metadata is never sent as a field and is rejected for other providers/roles.
"""

from copy import deepcopy
from dataclasses import dataclass
import json
from typing import Any


OPENAI_MODEL = "gpt-5.4-mini-2026-03-17"
CLAUDE_MODEL = "claude-haiku-5-5"
KIMI_MODEL = "kimi-k2.6"
MAX_TOKENS = 2048


class AdapterError(ValueError):
    """Malformed/unsupported input or provider output; never a usable decision."""


@dataclass(frozen=True)
class NativeRequest:
    endpoint: str
    required_env: str
    headers: dict[str, str]
    body: dict[str, Any]


@dataclass(frozen=True)
class NormalizedResponse:
    model: str
    assistant: dict[str, Any]
    usage: dict[str, Any]
    native_response: dict[str, Any]


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise AdapterError(message)


def _model(model: str) -> None:
    _require(model in (OPENAI_MODEL, CLAUDE_MODEL, KIMI_MODEL),
             f"Unsupported exact model ID: {model!r}")


def _count(value: Any, label: str) -> int:
    _require(type(value) is int and value >= 0,
             f"{label} must be a nonnegative integer")
    return value


def _validate_token_counters(value: dict[str, Any], prefix: str = "usage") -> None:
    for key, item in value.items():
        label = f"{prefix}.{key}"
        if key.endswith("_tokens"):
            _count(item, label)
        elif isinstance(item, dict):
            _validate_token_counters(item, label)


def _arguments(value: Any) -> dict[str, Any]:
    _require(isinstance(value, str), "Function arguments must be JSON text")
    try:
        result = json.loads(value)
    except (ValueError, TypeError) as exc:
        raise AdapterError("Invalid function arguments JSON") from exc
    _require(isinstance(result, dict), "Function arguments must encode an object")
    return result


def _calls(value: Any) -> list[dict[str, Any]]:
    _require(isinstance(value, list), "tool_calls must be a list")
    seen = set()
    for call in value:
        _require(isinstance(call, dict) and call.get("type") == "function",
                 "Only function tool calls are supported")
        ident = call.get("id")
        _require(isinstance(ident, str) and bool(ident) and ident not in seen,
                 "Missing or duplicate tool call ID")
        seen.add(ident)
        function = call.get("function")
        _require(isinstance(function, dict), "Missing function")
        _require(isinstance(function.get("name"), str) and bool(function["name"]),
                 "Missing function name")
        _arguments(function.get("arguments"))
    return value


def _claude_blocks(blocks: Any) -> tuple[str | None, list[dict[str, Any]]]:
    _require(isinstance(blocks, list) and bool(blocks), "Missing Claude content")
    text, calls = [], []
    for block in blocks:
        _require(isinstance(block, dict), "Invalid Claude block")
        kind = block.get("type")
        if kind == "text":
            _require(isinstance(block.get("text"), str), "Invalid text block")
            text.append(block["text"])
        elif kind == "tool_use":
            _require(isinstance(block.get("input"), dict), "Invalid tool input")
            calls.append({"id": block.get("id"), "type": "function",
                          "function": {"name": block.get("name"),
                                       "arguments": json.dumps(block["input"],
                                                               ensure_ascii=False)}})
        else:
            raise AdapterError(f"Unsupported Claude block: {kind!r}")
    _calls(calls)
    return "".join(text) if text else None, calls


def _check_claude_metadata(msg: dict[str, Any]) -> None:
    text, native_calls = _claude_blocks(msg["_anthropic_content"])
    _require(msg.get("content") == text, "Claude metadata/content mismatch")
    calls = _calls(msg.get("tool_calls", []))
    _require(len(calls) == len(native_calls), "Claude metadata/tool count mismatch")
    for canonical, native in zip(calls, native_calls):
        _require(canonical["id"] == native["id"] and
                 canonical["function"]["name"] == native["function"]["name"] and
                 _arguments(canonical["function"]["arguments"]) ==
                 _arguments(native["function"]["arguments"]),
                 "Claude metadata/tool call mismatch")


def build_request(
    model: str, messages: list[dict[str, Any]], tools: list[dict[str, Any]]
) -> NativeRequest:
    """Build a request; headers never include an API key.

    The caller must enforce its input-token bound (32768), shared budget, and
    NPC model pin. This module cannot count model tokens using the stdlib.
    """
    _model(model)
    _require(isinstance(messages, list) and bool(messages), "Messages required")
    _require(isinstance(tools, list), "Tools must be a list")
    messages, tools = deepcopy(messages), deepcopy(tools)
    for tool in tools:
        _require(isinstance(tool, dict) and tool.get("type") == "function",
                 "Only function tools are supported")
        fn = tool.get("function")
        _require(isinstance(fn, dict) and isinstance(fn.get("name"), str)
                 and bool(fn["name"]) and isinstance(fn.get("parameters"), dict),
                 "Tool requires name and parameters schema")
        _require(set(tool) <= {"type", "function"} and
                 set(fn) <= {"name", "description", "parameters", "strict"},
                 "Unsupported tool definition fields")
    for msg in messages:
        _require(isinstance(msg, dict), "Message must be an object")
        role = msg.get("role")
        _require(role in ("system", "user", "assistant", "tool"),
                 "Unsupported message role")
        allowed = {"role", "content", "tool_calls"} if role == "assistant" else (
            {"role", "content", "tool_call_id"} if role == "tool" else {"role", "content"})
        if model == CLAUDE_MODEL and role == "assistant":
            allowed.add("_anthropic_content")
        _require(set(msg) <= allowed, "Unsupported message fields")
        content = msg.get("content")
        _require(isinstance(content, str) or (role == "assistant" and content is None),
                 "Only text message content (or null assistant content) supported")
        if "tool_calls" in msg:
            _calls(msg["tool_calls"])
        if "_anthropic_content" in msg:
            _check_claude_metadata(msg)
        if role == "tool":
            _require(isinstance(msg.get("tool_call_id"), str)
                     and bool(msg["tool_call_id"]), "Tool result requires call ID")
    if model != CLAUDE_MODEL:
        body = {"model": model, "messages": messages}
        if model == KIMI_MODEL:
            body.update(thinking={"type": "disabled"}, max_tokens=MAX_TOKENS)
            endpoint, env = "https://api.moonshot.ai/v1/chat/completions", "MOONSHOT_API_KEY"
        else:
            body["max_completion_tokens"] = MAX_TOKENS
            endpoint, env = "https://api.openai.com/v1/chat/completions", "OPENAI_API_KEY"
            body["parallel_tool_calls"] = False
        if tools:
            body.update(tools=tools, tool_choice="auto")
        return NativeRequest(endpoint, env, {"Content-Type": "application/json"}, body)

    system: list[dict[str, Any]] = []
    converted: list[dict[str, Any]] = []
    pending: set[str] = set()
    for msg in messages:
        role, text = msg["role"], msg.get("content")
        if role == "system":
            _require(not converted, "Claude system messages must precede conversation")
            system.append({"type": "text", "text": text})
            continue
        if role == "tool":
            ident = msg["tool_call_id"]
            _require(ident in pending, "Orphan or duplicate tool result")
            pending.remove(ident)
            blocks = [{"type": "tool_result", "tool_use_id": ident, "content": text}]
            native_role = "user"
        else:
            _require(not pending, "Unresolved tool calls before next message")
            native_role = role
            blocks = [] if text is None else [{"type": "text", "text": text}]
            if role == "assistant":
                for call in msg.get("tool_calls", []):
                    pending.add(call["id"])
                    blocks.append({"type": "tool_use", "id": call["id"],
                                   "name": call["function"]["name"],
                                   "input": _arguments(call["function"]["arguments"])})
                if "_anthropic_content" in msg:
                    blocks = msg["_anthropic_content"]
            _require(bool(blocks), "Empty assistant without content or tool calls")
        if converted and converted[-1]["role"] == native_role:
            converted[-1]["content"].extend(blocks)
        else:
            converted.append({"role": native_role, "content": blocks})
    _require(not pending, "Request ends with unresolved tool calls")
    _require(bool(converted) and converted[0]["role"] == "user",
             "Claude conversation must start with user")
    body = {"model": model, "messages": converted, "max_tokens": MAX_TOKENS,
            "thinking": {"type": "disabled"}, "output_config": {"effort": "low"}}
    if system:
        body["system"] = system
    if tools:
        native_tools = []
        for tool in tools:
            fn = tool["function"]
            _require(not fn.get("strict"), "Claude strict tool mapping is unsupported")
            item = {"name": fn["name"], "input_schema": fn["parameters"]}
            if "description" in fn:
                item["description"] = fn["description"]
            native_tools.append(item)
        body["tools"] = native_tools
        body["tool_choice"] = {"type": "auto", "disable_parallel_tool_use": True}
    return NativeRequest("https://api.anthropic.com/v1/messages", "ANTHROPIC_API_KEY",
                         {"Content-Type": "application/json",
                          "anthropic-version": "2023-06-01"}, body)


def normalize_response(model: str, response: dict[str, Any]) -> NormalizedResponse:
    """Normalize one complete, non-streaming response; reject multi-tool decisions.

    usage.native retains all provider usage, native_response the entire response.
    Missing optional cache/reasoning counters are reported as None, not invented.
    """
    _model(model)
    _require(isinstance(response, dict), "Response must be an object")
    response = deepcopy(response)
    _require("error" not in response and response.get("type") != "error",
             f"Provider API error: {response.get('error', response.get('message'))!r}")
    _require(response.get("model") == model, "Missing model or exact model ID drift")
    usage = response.get("usage")
    _require(isinstance(usage, dict), "Missing usage object")
    _validate_token_counters(usage)
    cached = cache_write = reasoning = None
    if model == CLAUDE_MODEL:
        prompt = _count(usage.get("input_tokens"), "input_tokens")
        completion = _count(usage.get("output_tokens"), "output_tokens")
        if "cache_read_input_tokens" in usage:
            cached = _count(usage["cache_read_input_tokens"], "cache_read_input_tokens")
            prompt += cached
        if "cache_creation_input_tokens" in usage:
            cache_write = _count(usage["cache_creation_input_tokens"],
                                 "cache_creation_input_tokens")
            prompt += cache_write
        total = prompt + completion
        _require(response.get("type") == "message" and response.get("role") == "assistant",
                 "Not an assistant message")
        stop = response.get("stop_reason")
        _require(stop in ("end_turn", "tool_use"), f"Unsupported Claude stop: {stop!r}")
        blocks = response.get("content")
        text, calls = _claude_blocks(blocks)
        _require((stop == "tool_use") == bool(calls), "Stop/tool content mismatch")
        assistant = {"role": "assistant", "content": text,
                     "_anthropic_content": deepcopy(blocks)}
        if calls:
            assistant["tool_calls"] = calls
    else:
        prompt = _count(usage.get("prompt_tokens"), "prompt_tokens")
        completion = _count(usage.get("completion_tokens"), "completion_tokens")
        total = _count(usage.get("total_tokens"), "total_tokens")
        _require(total == prompt + completion, "Inconsistent total usage")
        for key, field in (("prompt_tokens_details", "cached_tokens"),
                           ("completion_tokens_details", "reasoning_tokens")):
            if key in usage:
                _require(isinstance(usage[key], dict), f"Invalid {key}")
                if field in usage[key]:
                    value = _count(usage[key][field], field)
                    _require(value <= (prompt if field == "cached_tokens" else completion),
                             f"{field} exceeds parent usage")
                    if field == "cached_tokens":
                        cached = value
                    else:
                        reasoning = value
        for field, existing, bound in (("cached_tokens", cached, prompt),
                                       ("reasoning_tokens", reasoning, completion)):
            if field in usage:
                value = _count(usage[field], field)
                _require(value <= bound, f"{field} exceeds parent usage")
                _require(existing is None or value == existing,
                         f"Conflicting native {field} counters")
                if field == "cached_tokens":
                    cached = value
                else:
                    reasoning = value
        choices = response.get("choices")
        _require(isinstance(choices, list) and len(choices) == 1,
                 "Expected exactly one response choice")
        choice = choices[0]
        _require(isinstance(choice, dict), "Invalid choice")
        stop = choice.get("finish_reason")
        _require(stop in ("stop", "tool_calls"), f"Unsupported finish_reason: {stop!r}")
        assistant = choice.get("message")
        _require(isinstance(assistant, dict) and assistant.get("role") == "assistant",
                 "Missing assistant message")
        _require(not assistant.get("refusal"), "Provider refusal")
        _require(not assistant.get("reasoning_content") and not assistant.get("reasoning"),
                 "Unexpected reasoning content with thinking disabled")
        _require(isinstance(assistant.get("content"), str) or
                 assistant.get("content") is None, "Unsupported assistant content")
        _require(not (set(assistant) - {"role", "content", "tool_calls", "refusal",
                                      "reasoning_content", "reasoning"}),
                 "Unsupported assistant fields")
        _require((stop == "tool_calls") == bool(assistant.get("tool_calls")),
                 "Stop/tool content mismatch")
        assistant = {key: assistant[key] for key in ("role", "content", "tool_calls") if key in assistant}
    calls = _calls(assistant.get("tool_calls", []))
    _require(len(calls) <= 1, "Multiple tool calls: controller supports only one")
    _require(bool(calls) or bool(assistant.get("content")), "Empty assistant decision")
    return NormalizedResponse(model, assistant,
                              {"prompt_tokens": prompt, "completion_tokens": completion,
                               "total_tokens": total, "cached_tokens": cached,
                               "cache_creation_tokens": cache_write,
                               "reasoning_tokens": reasoning, "native": usage},
                              response)
