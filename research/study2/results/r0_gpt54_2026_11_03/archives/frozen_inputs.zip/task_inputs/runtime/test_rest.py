"""Synthetic REST tests: no network, paid models, containers or real pilot episodes."""
import copy
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from urllib.parse import parse_qs, urlsplit
import urllib.error

import rest_runner as rest


class FakeHttp:
    def __init__(self, task):
        self.task = task
        self.roster = rest.load(rest.ROOT / "organization" / "roster.json")
        self.users = [{"_id": "u-" + r["npc_id"], "username": r["npc_id"], "name": r["name"]} for r in self.roster]
        self.rooms, self.messages = {}, {}
        self.sequence = 0

    def json(self, method, url, headers=None, value=None):
        parsed = urlsplit(url)
        route, query = parsed.path.split("/api/v1/")[1], parse_qs(parsed.query)
        if route == "login":
            return {"status": "success", "data": {"userId": "u-" + value["user"], "authToken": "synthetic-token"}}
        if route in ("users.list", "im.list"):
            key, rows = ("users", self.users) if route == "users.list" else ("ims", list(self.rooms.values()))
            offset = int(query["offset"][0])
            return {"success": True, key: rows[offset:offset + 100], "offset": offset, "total": len(rows)}
        if route == "im.create":
            room = "room-" + value["username"]
            self.rooms[room] = {"_id": room, "usernames": ["agent", value["username"]]}
            return {"success": True, "room": {"rid": room}}
        if route == "chat.postMessage":
            self.sequence += 1
            message = {"_id": "m" + str(self.sequence), "rid": value["roomId"], "msg": value["text"],
                       "u": {"_id": headers["X-User-Id"]},
                       "ts": "2026-01-01T00:00:" + str(self.sequence).zfill(2) + "+00:00"}
            self.messages.setdefault(value["roomId"], []).append(message)
            return {"success": True, "message": message}
        if route in ("im.history", "channels.history"):
            rows = self.messages.get(query["roomId"][0], [])
            latest = query.get("latest", [None])[0]
            rows = [m for m in rows if latest is None or m["ts"] <= latest]
            return {"success": True, "messages": sorted(rows, key=lambda x: x["ts"], reverse=True)[:100]}
        if route == "channels.info":
            return {"success": True, "channel": {"_id": "engineering"}}
        raise AssertionError("Unexpected synthetic endpoint: " + route)

    def request(self, method, url, headers=None):
        directory = rest.ROOT / "templates" / self.task / "tac" / "documents_R1"
        if method == "PROPFIND":
            base = "/remote.php/webdav/Documents/Study21V2/" + self.task + "/"
            hrefs = [base] + [base + p.name for p in directory.glob("*.md")]
            return ('<d:multistatus xmlns:d="DAV:">' + "".join(
                "<d:response><d:href>" + href + "</d:href></d:response>" for href in hrefs)
                + "</d:multistatus>").encode()
        return (directory / urlsplit(url).path.rsplit("/", 1)[1]).read_bytes()


class ScriptedModel:
    def __init__(self, person):
        self.calls = iter([
            ("list_files", {"path": "/packet"}),
            ("read_file", {"path": "/packet/directory.md"}),
            ("list_colleagues", {}),
            ("send_message", {"person": person, "message": "Synthetic contact without hidden values"}),
            ("read_messages", {"person": person}),
            ("write_file", {"path": "/workspace/deliverable.json", "content": "{}"}),
            ("post_message", {"channel": "engineering", "message": "Synthetic /workspace/deliverable.json"}),
            ("submit", {}),
        ])
        self.initial_messages = None

    def complete(self, role, messages, tools=None):
        if role == "npc":
            return {"role": "assistant", "content": "Synthetic response; not a real NPC rule test."}
        if self.initial_messages is None:
            self.initial_messages = copy.deepcopy(messages)
        name, args = next(self.calls)
        return {"role": "assistant", "tool_calls": [{"id": name, "type": "function",
                "function": {"name": name, "arguments": json.dumps(args)}}]}


class RestTests(unittest.TestCase):
    def config(self):
        return rest.load(Path(rest.__file__).with_name("rest_config.json"))

    def test_npc_clock_boundary_rejects_wrong_time_without_certifying_other_conditions(self):
        records = rest.load(rest.ROOT / "templates" / "m-high-service-cutover" / "blueprint.json")["hidden_information"]
        response = "Readiness QA-A9-62."
        invalid = "Atlas A-9, 6 replicas, window 01:00-01:30 UTC, rollback 20 minutes."
        issues = rest.npc_clock_boundary_issues(records, "Liu Qiang", invalid, response)
        self.assertEqual([i["record_id"] for i in issues], ["H2"])
        self.assertEqual(issues[0]["missing_clock_context"], ["02:30"])
        self.assertEqual(rest.npc_clock_boundary_issues(
            records, "Liu Qiang", invalid, "Please supply the current window."), [])
        self.assertEqual(rest.npc_clock_boundary_issues(
            records, "Liu Qiang", "A-9, 6 replicas, window 2:30-3:00 UTC, rollback 20.", response), [])
        # A substring such as 12:30 is not the required 02:30.
        self.assertTrue(rest.npc_clock_boundary_issues(
            records, "Liu Qiang", "A-9, 6 replicas, 12:30, rollback 20.", response))

    def test_npc_boundary_violation_is_persisted_before_post_and_not_returned_to_agent(self):
        class InvalidNpc:
            def complete(self, *args):
                return {"role": "assistant", "content": "Readiness QA-A9-62."}

        with tempfile.TemporaryDirectory() as temp:
            service = rest.Services(self.config(), "m-high-service-cutover", None, InvalidNpc(), temp, "synthetic")
            service.post = lambda *args: self.fail("Unsafe NPC response was posted")
            request = {"_id": "request-1", "rid": "room",
                       "msg": "Atlas A-9, 6 replicas, window 01:00-01:30 UTC, rollback 20 minutes."}
            with self.assertRaises(rest.NpcProtocolError) as error:
                service.respond("Liu Qiang", request)
            self.assertEqual(error.exception.failure_kind, "npc_protocol_violation")
            log = rest.load(Path(temp) / "npc_protocol_violations.jsonl")
            self.assertIs(log["posted"], False)
            self.assertEqual(log["request_id"], request["_id"])
            self.assertEqual(log["unpublished_response"], "Readiness QA-A9-62.")
            self.assertEqual(service.parents, {})

    def test_post_accepts_only_logged_trailing_ascii_whitespace_normalization(self):
        with tempfile.TemporaryDirectory() as temp:
            service = rest.Services(self.config(), rest.PILOTS[0], None, None, temp, "synthetic")
            service.headers = {"X-User-Id": "agent"}
            message = {"_id": "m1", "u": {"_id": "agent"}, "rid": "room", "msg": "record"}
            service.rpc = lambda *args, **kwargs: {"message": message}
            self.assertEqual(service.post("room", "record\n\n"), message)
            log = rest.load(Path(temp) / "message_transport_normalizations.jsonl")
            self.assertEqual(log["message_id"], "m1")
            self.assertEqual(log["requested_length"] - log["stored_length"], 2)
            for expected, actual in (("record", "changed"), ("record", " record"),
                                     ("record\u00a0", "record")):
                service.post_times.clear()
                message["msg"] = actual
                with self.assertRaisesRegex(rest.RestError, "identity/content mismatch"):
                    service.post("room", expected)
            message["msg"] = "record"
            message["u"]["_id"] = "other"
            service.post_times.clear()
            with self.assertRaisesRegex(rest.RestError, "identity/content mismatch"):
                service.post("room", "record\n")

    def test_native_agent_and_fixed_npc_use_distinct_endpoints_and_prices(self):
        config = self.config()
        config.update(agent_model="claude-haiku-5-5", allow_paid_calls=True,
                      authorization_ref="synthetic", budget_usd=1,
                      role_prices_per_million={"agent": rest.PRICE_BOOK["claude-haiku-5-5"],
                                               "npc": rest.PRICE_BOOK[rest.MODEL]})
        calls = []

        class FakeProvider:
            def json(self, method, url, headers, body):
                calls.append((url, body))
                if body["model"] == "claude-haiku-5-5":
                    self_assert = headers["x-api-key"] == "synthetic-only"
                    if not self_assert:
                        raise AssertionError("Wrong native credential routing")
                    return {"model": body["model"], "type": "message", "role": "assistant",
                            "stop_reason": "end_turn", "content": [{"type": "text", "text": "done"}],
                            "usage": {"input_tokens": 10, "output_tokens": 5}}
                return {"model": rest.MODEL, "service_tier": "default",
                        "choices": [{"finish_reason": "stop",
                                     "message": {"role": "assistant", "content": "done"}}],
                        "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}}

        with tempfile.TemporaryDirectory() as temp, patch.dict(os.environ, {
                "ANTHROPIC_API_KEY": "synthetic-only", config["openai_key_env"]: "synthetic-only"}):
            ledger = rest.Ledger(Path(temp) / "ledger.jsonl", config)
            model = rest.OpenAI(config, FakeProvider(), ledger, temp)
            model.complete("agent", [{"role": "user", "content": "public"}], rest.TOOLS)
            model.complete("npc", [{"role": "user", "content": "private"}])
            rows = [json.loads(line) for line in (Path(temp) / "ledger.jsonl").read_text().splitlines()]
            settled = {row["role"]: row["amount_usd"] for row in rows if row["event"] == "settle"}
            self.assertEqual(rest.Decimal(settled["agent"]), rest.Decimal("0.0000035"))
            self.assertEqual(rest.Decimal(settled["npc"]), rest.Decimal("0.000030"))
            self.assertEqual(calls[0][0], "https://api.anthropic.com/v1/messages")
            self.assertEqual(calls[1][0], "https://api.openai.com/v1/chat/completions")
            self.assertEqual(calls[1][1]["model"], rest.MODEL)
            self.assertNotIn("reasoning_effort", calls[0][1])
            self.assertEqual(calls[1][1]["service_tier"], "default")

    def test_native_prices_are_required_and_pinned(self):
        config = self.config()
        config["agent_model"] = "claude-haiku-5-5"
        with self.assertRaisesRegex(rest.RestError, "role prices"):
            rest.validate(config, rest.PILOTS[0])
        config["role_prices_per_million"] = {"agent": {"input": 0.1, "output": 0.5},
                                           "npc": {"input": 0.1, "output": 0.5}}
        with self.assertRaisesRegex(rest.RestError, "price drift"):
            rest.validate(config, rest.PILOTS[0])

    def test_quota_context_and_rate_errors_remain_distinct(self):
        self.assertEqual(rest.HttpFailure(429, {"code": "insufficient_quota"}).failure_kind, "provider_quota")
        self.assertEqual(rest.HttpFailure(429, {"message": "TPM rate limit"}).failure_kind, "provider_rate_limit")
        self.assertEqual(rest.HttpFailure(400, {"code": "context_length_exceeded"}).failure_kind, "context_limit")

    def test_public_instruction_only_rebinds_service_locators(self):
        config = self.config()
        config.update(owncloud_url="http://127.0.0.1:18092", rocketchat_url="http://127.0.0.1:13000")
        for task in rest.PILOTS:
            with self.subTest(task=task):
                source = (rest.ROOT / "templates" / task / "tac" / "task.md").read_text(encoding="utf-8")
                rendered = rest.public_instruction(source, config)
                self.assertEqual(rendered, source.replace("OwnCloud: [REDACTED_RUNTIME_ENDPOINT]",
                                                         "OwnCloud: " + config["owncloud_url"])
                                 .replace("RocketChat: [REDACTED_RUNTIME_ENDPOINT]",
                                          "RocketChat: " + config["rocketchat_url"]))
                self.assertNotIn("CC-628", rendered)
        source = "OwnCloud: http://localhost:8092\nRocketChat: http://localhost:3000\n"
        for invalid in (source.replace("OwnCloud:", "Files:"), source + "OwnCloud: http://localhost:8093\n"):
            with self.subTest(invalid=invalid), self.assertRaisesRegex(rest.RestError, "exactly one"):
                rest.public_instruction(invalid, config)

    def test_default_run_rejected_before_http_or_output(self):
        with tempfile.TemporaryDirectory() as temp, patch.object(rest, "Http") as http:
            with self.assertRaisesRegex(rest.RestError, "Paid calls disabled"):
                rest.run(self.config(), rest.PILOTS[0], Path(temp) / "not-created")
            http.assert_not_called()
            self.assertFalse((Path(temp) / "not-created").exists())

    def test_whitelist_and_snapshot_gates(self):
        config = self.config()
        other = next(p.name for p in (rest.ROOT / "templates").iterdir() if p.name not in rest.PILOTS)
        with self.assertRaisesRegex(rest.RestError, "whitelist"):
            rest.validate(config, other)
        config["agent_model"] = "unapproved"
        with self.assertRaisesRegex(rest.RestError, "snapshot"):
            rest.validate(config, rest.PILOTS[0])

    def test_full_collection_not_implicitly_authorized(self):
        config = self.config()
        config["phase"] = "full"
        with self.assertRaisesRegex(rest.RestError, "Full collection"):
            rest.validate(config, rest.PILOTS[0])

    def test_user_reviewed_amendment_does_not_forge_original_gate(self):
        config = self.config()
        with self.assertRaisesRegex(rest.RestError, "material_review_passed"):
            rest.validate_material_policy(config, {"material_review_passed": False})
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "decision.json"
            rest.save(path, {
                "policy": "user_reviewed_protocol_amendment",
                "authorization_ref": "explicit-user-decision",
                "user_instruction": "你不用检查tasks了，我都已经审核过那些task了啊",
                "original_section_14_pass_claimed": False,
            })
            config.update(material_review_policy="user_reviewed_protocol_amendment",
                          material_review_authorization_ref="explicit-user-decision")
            ready = {"material_review_passed": False, "material_review": {
                "status": "not_required_by_user_amendment",
                "authorization_ref": "explicit-user-decision",
                "decision_file": str(path), "decision_sha256": rest.digest(path)}}
            rest.validate_material_policy(config, ready)
            ready["material_review_passed"] = True
            with self.assertRaisesRegex(rest.RestError, "must not claim"):
                rest.validate_material_policy(config, ready)
            ready["material_review_passed"] = False
            path.write_text("{}", encoding="utf-8")
            with self.assertRaisesRegex(rest.RestError, "record drift"):
                rest.validate_material_policy(config, ready)

    def test_single_task_authorization_cannot_run_other_planned_pilots(self):
        config = self.config()
        config["pilot_tasks"] = [rest.PILOTS[0]]
        rest.validate(config, rest.PILOTS[0])
        for task in rest.PILOTS[1:]:
            with self.subTest(task=task), self.assertRaisesRegex(rest.RestError, "authorization"):
                rest.validate(config, task)

    def test_tool_paths_and_arguments_never_read_host_or_private_data(self):
        with tempfile.TemporaryDirectory() as temp:
            service = rest.Services(self.config(), rest.PILOTS[0], None, None, temp, "synthetic")
            for path in ("/packet/../blueprint.json", "/private/scorer.py", "/workspace/NUL",
                         "[REDACTED_LOCAL_PATH]", "/workspace/../answer.json", "/workspace/a/b.json"):
                with self.subTest(path=path), self.assertRaises(rest.ToolError):
                    service.dispatch("read_file", {"path": path})
            with self.assertRaises(rest.ToolError):
                service.dispatch("write_purchase_request", {"answer": "secret"})

    def test_batch_budget_covers_both_roles_and_survives_reload(self):
        config = self.config()
        config["budget_usd"] = "0.01"
        request = {"model": rest.MODEL, "max_completion_tokens": 1024}
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "ledger.jsonl"
            ledger = rest.Ledger(path, config)
            call, bound = ledger.reserve("agent", request)
            with self.assertRaisesRegex(rest.RestError, "budget"):
                ledger.reserve("npc", request)
            ledger.settle(call, "agent", {"prompt_tokens": 1, "completion_tokens": 1}, bound, 1024)
            reloaded = rest.Ledger(path, config)
            reloaded.reserve("npc", request)
            self.assertEqual(len(reloaded.charges), 2)

    def test_unknown_usage_retains_full_reservation(self):
        config = self.config()
        config["budget_usd"] = 1
        with tempfile.TemporaryDirectory() as temp:
            ledger = rest.Ledger(Path(temp) / "ledger.jsonl", config)
            call, bound = ledger.reserve("npc", {"model": rest.MODEL, "max_completion_tokens": 1})
            original = ledger.charges[call]
            with self.assertRaises(rest.RestError):
                ledger.settle(call, "npc", {"prompt_tokens": bound + 1, "completion_tokens": 1}, bound, 1)
            self.assertEqual(ledger.charges[call], original)

    def test_pagination_requires_total_and_progress(self):
        with tempfile.TemporaryDirectory() as temp:
            service = rest.Services(self.config(), rest.PILOTS[0], None, None, temp, "synthetic")
            with patch.object(service, "rpc", return_value={"users": []}):
                with self.assertRaisesRegex(rest.RestError, "total"):
                    service.pages("users.list", "users")
            page = [{"_id": str(i), "ts": "2026-01-01T00:00:00+00:00"} for i in range(100)]
            with patch.object(service, "rpc", return_value={"messages": page}):
                with self.assertRaisesRegex(rest.RestError, "cursor stalled"):
                    service.history("synthetic-room")
            self.assertTrue((Path(temp) / "chat_pages.jsonl").exists())

    def test_history_collects_more_than_one_page(self):
        with tempfile.TemporaryDirectory() as temp:
            service = rest.Services(self.config(), rest.PILOTS[0], None, None, temp, "synthetic")
            rows = [{"_id": str(i), "ts": "2026-01-01T00:" + str(i // 60).zfill(2)
                     + ":" + str(i % 60).zfill(2) + "+00:00"} for i in range(180)]
            def pages(method, route, params):
                selected = [r for r in rows if params.get("latest") is None or r["ts"] <= params["latest"]]
                return {"messages": sorted(selected, key=lambda r: r["ts"], reverse=True)[:100]}
            with patch.object(service, "rpc", side_effect=pages):
                self.assertEqual(len(service.history("synthetic")), 180)

    def test_failed_bootstrap_cannot_certify_complete_trace(self):
        with tempfile.TemporaryDirectory() as temp:
            service = rest.Services(self.config(), rest.PILOTS[0], None, None, temp, "synthetic")
            with self.assertRaisesRegex(rest.RestError, "bootstrap incomplete"):
                service.collect()

    def test_api_client_default_paid_gate_precedes_transport(self):
        with tempfile.TemporaryDirectory() as temp:
            from unittest.mock import Mock
            http, ledger = Mock(), Mock()
            client = rest.OpenAI(self.config(), http, ledger, temp)
            with self.assertRaisesRegex(rest.RestError, "disabled"):
                client.complete("agent", [])
            http.json.assert_not_called()
            ledger.reserve.assert_not_called()

    def test_provider_mismatch_truncation_and_missing_usage_stop(self):
        from unittest.mock import Mock
        for issue in ("model", "length", "usage", "tier", "missing_tier"):
            with self.subTest(issue=issue), tempfile.TemporaryDirectory() as temp:
                config = self.config()
                config.update(allow_paid_calls=True, authorization_ref="SYNTHETIC", budget_usd=1)
                ledger = rest.Ledger(Path(temp) / "costs.jsonl", config)
                response = {"model": rest.MODEL, "service_tier": "default",
                            "usage": {"prompt_tokens": 1, "completion_tokens": 1},
                            "choices": [{"finish_reason": "stop",
                                         "message": {"role": "assistant", "content": "synthetic"}}]}
                if issue == "model":
                    response["model"] = "drifted"
                elif issue == "length":
                    response["choices"][0]["finish_reason"] = "length"
                elif issue == "usage":
                    response.pop("usage")
                elif issue == "tier":
                    response["service_tier"] = "priority"
                else:
                    response.pop("service_tier")
                http = Mock()
                http.json.return_value = response
                client = rest.OpenAI(config, http, ledger, temp)
                with patch.dict(os.environ, {"OPENAI_API_KEY": "fake-secret"}), self.assertRaises(rest.RestError):
                    client.complete("agent", [])
                self.assertEqual(http.json.call_count, 1)
                self.assertNotIn("fake-secret", (Path(temp) / "api_io.jsonl").read_text(encoding="utf-8"))
                self.assertGreater(sum(ledger.charges.values()), 0)

    def test_api_client_explicitly_requests_standard_tier(self):
        from unittest.mock import Mock
        with tempfile.TemporaryDirectory() as temp:
            config = self.config()
            config.update(allow_paid_calls=True, authorization_ref="SYNTHETIC", budget_usd=1)
            ledger = rest.Ledger(Path(temp) / "costs.jsonl", config)
            http = Mock()
            http.json.return_value = {"model": rest.MODEL, "service_tier": "default",
                                     "usage": {"prompt_tokens": 1, "completion_tokens": 1},
                                     "choices": [{"finish_reason": "stop",
                                                  "message": {"role": "assistant", "content": "synthetic"}}]}
            with patch.dict(os.environ, {"OPENAI_API_KEY": "fake-secret"}):
                reply = rest.OpenAI(config, http, ledger, temp).complete("agent", [])
            self.assertEqual(http.json.call_args.args[3]["service_tier"], "default")
            self.assertEqual(reply["content"], "synthetic")

    def test_corrupt_persisted_ledger_is_not_a_free_budget(self):
        config = self.config()
        config["budget_usd"] = 1
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "ledger.jsonl"
            rest.append(path, {"event": "settle", "id": "missing", "amount_usd": "-1"})
            with self.assertRaisesRegex(rest.RestError, "ledger"):
                rest.Ledger(path, config)

    def test_full_phase_also_requires_real_pilot_audit(self):
        config = self.config()
        with tempfile.TemporaryDirectory() as temp:
            config.update(phase="full", full_collection_authorized=True, allow_paid_calls=True,
                          authorization_ref="SYNTHETIC", budget_usd=1, batch_dir=str(Path(temp) / "batch"),
                          readiness_file=str(Path(temp) / "ready.json"))
            ready = {flag: True for flag in rest.READINESS}
            ready.update(method=rest.METHOD, task_id=rest.PILOTS[0], service_instance="SYNTHETIC",
                         configuration_sha256=rest.config_digest(config),
                         source_manifest_sha256=rest.digest(rest.ROOT / "artifact_manifest.json"),
                         rocketchat_url=config["rocketchat_url"], owncloud_url=config["owncloud_url"])
            rest.save(config["readiness_file"], ready)
            with self.assertRaisesRegex(rest.RestError, "Pilot audit"):
                rest.validate(config, rest.PILOTS[0], live=True)

    def test_room_mutation_does_not_create_successful_empty_export(self):
        with tempfile.TemporaryDirectory() as temp:
            service = rest.Services(self.config(), rest.PILOTS[0], None, None, temp, "synthetic")
            service.bootstrapped = True
            with patch.object(service, "pages", side_effect=[[], [{"_id": "unexpected"}]]):
                with self.assertRaisesRegex(rest.RestError, "inventory changed"):
                    service.collect()
            self.assertFalse((Path(temp) / "raw_chat.json").exists())

    def test_http_does_not_follow_redirects_or_retry_and_hide_errors(self):
        from unittest.mock import Mock
        with self.assertRaisesRegex(rest.RestError, "redirect"):
            rest.NoRedirect().redirect_request(None, None, 302, "", {}, "[REDACTED_RUNTIME_ENDPOINT]")
        http = rest.Http()
        http.opener = Mock()
        http.opener.open.side_effect = urllib.error.HTTPError("http://127.0.0.1", 401, "fake-secret", {}, None)
        with self.assertRaisesRegex(rest.RestError, "status 401") as error:
            http.request("GET", "http://127.0.0.1")
        self.assertNotIn("fake-secret", str(error.exception))
        self.assertEqual(http.opener.open.call_count, 1)

    def test_readiness_binds_actual_configuration(self):
        config = self.config()
        with tempfile.TemporaryDirectory() as temp:
            config.update(allow_paid_calls=True, authorization_ref="SYNTHETIC", budget_usd=1,
                          batch_dir=str(Path(temp) / "batch"), readiness_file=str(Path(temp) / "ready.json"))
            rest.save(config["readiness_file"], {"method": rest.METHOD, "task_id": rest.PILOTS[0],
                                                 "configuration_sha256": "stale"})
            with self.assertRaisesRegex(rest.RestError, "configuration drift"):
                rest.validate(config, rest.PILOTS[0], live=True)

    def test_three_distinct_tasks_synthetic_controller_integration(self):
        for task in rest.PILOTS:
            with self.subTest(task=task), tempfile.TemporaryDirectory() as temp:
                root = Path(temp)
                config = self.config()
                config.update(allow_paid_calls=True, authorization_ref="SYNTHETIC_TEST_ONLY",
                              budget_usd=1, batch_dir=str(root / "batch"),
                              readiness_file=str(root / "ready.json"))
                roster = rest.load(rest.ROOT / "organization" / "roster.json")
                config["npc_accounts"] = {p["name"]: {"username_env": p["npc_id"] + "_USER",
                                                    "password_env": p["npc_id"] + "_PASS"} for p in roster}
                env = {"TAC_AGENT_USERNAME": "agent", "TAC_AGENT_PASSWORD": "fake-secret",
                       "TAC_OWNCLOUD_USERNAME": "agent", "TAC_OWNCLOUD_PASSWORD": "fake-secret",
                       "OPENAI_API_KEY": "fake-secret"}
                for p in roster:
                    env[p["npc_id"] + "_USER"], env[p["npc_id"] + "_PASS"] = p["npc_id"], "fake-secret"
                ready = {flag: True for flag in rest.READINESS}
                ready.update(method=rest.METHOD, task_id=task, service_instance="SYNTHETIC",
                             configuration_sha256=rest.config_digest(config),
                             source_manifest_sha256=rest.digest(rest.ROOT / "artifact_manifest.json"),
                             rocketchat_url=config["rocketchat_url"], owncloud_url=config["owncloud_url"])
                rest.save(root / "ready.json", ready)
                pool = rest.load(rest.ROOT / "templates" / task / "blueprint.json")["candidate_pool"]
                person = next(p["name"] for p in roster if p["name"] not in pool)
                fake_model = ScriptedModel(person)
                with patch.dict(os.environ, env), patch.object(rest, "verify_source"), \
                     patch.object(rest, "Http", return_value=FakeHttp(task)), \
                     patch.object(rest, "OpenAI", return_value=fake_model):
                    self.assertEqual(rest.run(config, task, root / "run"), 0)
                    with self.assertRaises(FileExistsError):
                        rest.run(config, task, root / "second-attempt")
                bundle = rest.load(root / "run" / "trace_bundle.json")
                self.assertTrue(bundle["complete"])
                self.assertEqual(len(bundle["events"]), 2)
                self.assertEqual({e["colleague"] for e in bundle["events"]}, {person})
                self.assertEqual(bundle["events"][1]["in_reply_to"], bundle["events"][0]["message_id"])
                self.assertEqual(rest.load(root / "run" / "workspace" / "deliverable.json"), {})
                self.assertEqual(rest.load(root / "run" / "status.json")["task_success"], "not_scored")
                spec = importlib.util.spec_from_file_location("private_rest_test_grader",
                                                              rest.ROOT / "grading" / "scorer.py")
                grader = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(grader)
                result = grader.score_bundle(rest.load(rest.ROOT / "templates" / task / "blueprint.json"), {}, bundle)
                self.assertEqual(result["task_id"], task)
                self.assertFalse(result["base_pass"])
                initial = json.dumps(fake_model.initial_messages)
                self.assertNotIn("Task-local private records", initial)
                directory = (rest.ROOT / "templates" / task / "tac" / "documents_R1"
                             / "directory.md").read_text(encoding="utf-8")
                self.assertEqual(fake_model.initial_messages, rest.initial_messages(
                    (root / "run" / "public_instruction.md").read_text(encoding="utf-8"), directory))
                self.assertNotIn("discover its directory yourself", initial)
                self.assertEqual(rest.load(root / "run" / "directory_presentation.json")["content"], directory)
                for file in (root / "run").glob("*.json*"):
                    self.assertNotIn("fake-secret", file.read_text(encoding="utf-8"))


    def test_full_list_preserves_entire_public_directory_for_all_tasks(self):
        for path in (rest.ROOT / "templates").glob("*/tac/documents_R1/directory.md"):
            with self.subTest(path=path):
                directory = path.read_text(encoding="utf-8")
                messages = rest.initial_messages("TASK", directory)
                self.assertEqual(messages[1]["content"], "TASK\n\nVISIBLE CANDIDATE DIRECTORY\n" + directory)
                self.assertNotIn("discover its directory yourself", messages[0]["content"])
        with self.assertRaisesRegex(rest.RestError, "empty"):
            rest.initial_messages("TASK", "")

    def test_pilot_formal_and_judge_share_one_immutable_stage_budget(self):
        with tempfile.TemporaryDirectory() as temp:
            common = {"ledger_dir": str(Path(temp) / "shared"), "budget_usd": 20,
                      "authorization_ref": "SYNTHETIC"}
            a = dict(common, batch_dir=str(Path(temp) / "pilot"))
            b = dict(common, batch_dir=str(Path(temp) / "formal"))
            self.assertEqual(rest.ledger_directory(a), rest.ledger_directory(b))
            for change in ({"budget_usd": 21}, {"authorization_ref": "different"}):
                with self.assertRaisesRegex(rest.RestError, "Shared stage"):
                    rest.ledger_directory(dict(b, **change))

    def test_rerun_preserves_original_marker_parent_and_shared_budget(self):
        with tempfile.TemporaryDirectory() as temp:
            batch, parent = Path(temp) / "batch", Path(temp) / "parent"
            batch.mkdir()
            parent.mkdir()
            identity = {"budget_usd": 3, "configuration_sha256": "old", "source_manifest_sha256": "old"}
            rest.save(batch / "batch_manifest.json", identity)
            (batch / "task.attempt").write_text(str(parent), encoding="utf-8")
            for name in ("api_io.jsonl", "tool_events.jsonl", "workspace.json", "raw_chat.json",
                         "trace_bundle.json", "evaluation.json", "pilot_audit.json"):
                rest.save(parent / name, {})
            rest.save(parent / "run_manifest.json", dict(identity, task_id="task"))
            rest.save(parent / "status.json", {"collection_complete": True})
            archive = {p.name: rest.digest(p) for p in parent.iterdir()}
            config = {"phase": "pilot", "pilot_tasks": ["task"], "authorized_rerun": {
                "authorization_ref": "SYNTHETIC", "attempt_id": "full-list-v2",
                "parent_run_dir": str(parent), "parent_artifacts_sha256": archive}}
            current = dict(identity, configuration_sha256="new", source_manifest_sha256="new")
            marker = rest.attempt_marker(config, "task", batch, current)
            self.assertEqual(marker.name, "task.attempt.full-list-v2")
            with self.assertRaisesRegex(rest.RestError, "budget"):
                rest.attempt_marker(config, "task", batch, dict(current, budget_usd=4))
            marker.touch()
            with self.assertRaisesRegex(rest.RestError, "already attempted"):
                rest.attempt_marker(config, "task", batch, current)
            self.assertEqual((batch / "task.attempt").read_text(encoding="utf-8"), str(parent))
            self.assertEqual(rest.load(batch / "batch_manifest.json"), identity)


if __name__ == "__main__":
    unittest.main()
