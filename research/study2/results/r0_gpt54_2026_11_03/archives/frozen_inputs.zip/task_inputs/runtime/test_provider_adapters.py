"""Synthetic provider adapter tests; never make network calls."""

from copy import deepcopy
import unittest

from provider_adapters import (
    AdapterError, CLAUDE_MODEL, KIMI_MODEL, OPENAI_MODEL,
    build_request, normalize_response,
)


TOOL = {"type": "function", "function": {
    "name": "read_file", "description": "Read a file",
    "parameters": {"type": "object", "properties": {"path": {"type": "string"}}}}}
CALL = {"id": "call_1", "type": "function",
        "function": {"name": "read_file", "arguments": '{"path":"目录/a.txt"}'}}
DIRECTORY = "Full initial user request\n/owncloud\n  a.txt\n  hidden-policy.txt\nEND"


def claude():
    return {"type": "message", "role": "assistant", "model": CLAUDE_MODEL,
            "content": [{"type": "text", "text": "first"},
                        {"type": "tool_use", "id": "call_1", "name": "read_file",
                         "input": {"path": "目录/a.txt"}},
                        {"type": "text", "text": "last"}],
            "stop_reason": "tool_use",
            "usage": {"input_tokens": 10, "output_tokens": 5,
                      "cache_read_input_tokens": 7, "cache_creation_input_tokens": 3,
                      "provider_extra": {"preserved": True}}}


def chat(model=KIMI_MODEL):
    return {"model": model, "choices": [{"finish_reason": "tool_calls",
            "message": {"role": "assistant", "content": "reading",
                        "tool_calls": [deepcopy(CALL)]}}],
            "usage": {"prompt_tokens": 20, "completion_tokens": 5, "total_tokens": 25,
                      "prompt_tokens_details": {"cached_tokens": 7},
                      "completion_tokens_details": {"reasoning_tokens": 0}}}


class AdapterTests(unittest.TestCase):
    def test_requests_and_full_directory(self):
        messages = [{"role": "system", "content": "rules"},
                    {"role": "user", "content": DIRECTORY}]
        original = deepcopy(messages)
        for model in (OPENAI_MODEL, KIMI_MODEL, CLAUDE_MODEL):
            with self.subTest(model=model):
                req = build_request(model, messages, [TOOL])
                self.assertEqual(req.body["model"], model)
                self.assertNotIn("temperature", req.body)
                self.assertNotIn("top_p", req.body)
                self.assertNotIn("top_k", req.body)
                self.assertNotIn("service_tier", req.body)
                self.assertNotIn("reasoning_effort", req.body)
                self.assertFalse(any("key" in key.lower() for key in req.headers))
                if model == CLAUDE_MODEL:
                    self.assertEqual(req.body["messages"][0]["content"][0]["text"],
                                     DIRECTORY)
                    self.assertEqual(req.body["system"][0]["text"], "rules")
                    self.assertEqual(req.body["tools"][0]["input_schema"],
                                     TOOL["function"]["parameters"])
                    self.assertEqual(req.headers["anthropic-version"], "2023-06-01")
                    self.assertEqual(req.body["thinking"], {"type": "disabled"})
                    self.assertEqual(req.body["output_config"], {"effort": "low"})
                    self.assertEqual(req.body["max_tokens"], 2048)
                    self.assertEqual(req.body["tool_choice"],
                                     {"type": "auto", "disable_parallel_tool_use": True})
                else:
                    self.assertEqual(req.body["messages"], messages)
                if model == KIMI_MODEL:
                    self.assertEqual(req.endpoint,
                                     "https://api.moonshot.ai/v1/chat/completions")
                    self.assertEqual(req.required_env, "MOONSHOT_API_KEY")
                    self.assertNotIn("parallel_tool_calls", req.body)
                    self.assertEqual(req.body["tool_choice"], "auto")
                    self.assertEqual(req.body["thinking"], {"type": "disabled"})
        self.assertEqual(messages, original)

    def test_tool_loops_preserve_order_and_content(self):
        messages = [{"role": "system", "content": "one"},
                    {"role": "system", "content": "two"},
                    {"role": "user", "content": DIRECTORY},
                    {"role": "assistant", "content": "read", "tool_calls": [CALL]},
                    {"role": "tool", "tool_call_id": "call_1", "content": "full result"},
                    {"role": "user", "content": "continue"},
                    {"role": "assistant", "content": "done"},
                    {"role": "user", "content": "next"}]
        req = build_request(CLAUDE_MODEL, messages, [TOOL])
        self.assertEqual([x["role"] for x in req.body["messages"]],
                         ["user", "assistant", "user", "assistant", "user"])
        merged = req.body["messages"][2]["content"]
        self.assertEqual(merged, [
            {"type": "tool_result", "tool_use_id": "call_1", "content": "full result"},
            {"type": "text", "text": "continue"}])
        self.assertEqual(req.body["messages"][1]["content"][1]["input"],
                         {"path": "目录/a.txt"})
        self.assertEqual(build_request(KIMI_MODEL, messages, [TOOL]).body["messages"],
                         messages)

    def test_cache_aggregate_and_native_retention(self):
        source = claude()
        result = normalize_response(CLAUDE_MODEL, source)
        self.assertEqual(result.usage["prompt_tokens"], 20)
        self.assertEqual(result.usage["total_tokens"], 25)
        self.assertEqual(result.usage["cached_tokens"], 7)
        self.assertEqual(result.usage["cache_creation_tokens"], 3)
        self.assertIsNone(result.usage["reasoning_tokens"])
        self.assertEqual(result.assistant["content"], "firstlast")
        self.assertEqual(result.native_response, source)
        self.assertEqual(result.usage["native"], source["usage"])
        result.native_response["content"][0]["text"] = "mutated"
        self.assertEqual(source["content"][0]["text"], "first")

    def test_chat_usage_and_tools(self):
        for model in (KIMI_MODEL, OPENAI_MODEL):
            result = normalize_response(model, chat(model))
            self.assertEqual(result.assistant["tool_calls"], [CALL])
            self.assertEqual(result.usage["total_tokens"], 25)
            self.assertEqual(result.usage["cached_tokens"], 7)
            self.assertEqual(result.usage["reasoning_tokens"], 0)
            self.assertEqual(result.native_response, chat(model))

    def test_claude_exact_block_replay_after_tool_result(self):
        response = claude()
        assistant = normalize_response(CLAUDE_MODEL, response).assistant
        messages = [{"role": "user", "content": DIRECTORY}, assistant,
                    {"role": "tool", "tool_call_id": "call_1", "content": "result"}]
        request = build_request(CLAUDE_MODEL, messages, [TOOL])
        self.assertEqual(request.body["messages"][1]["content"], response["content"])
        self.assertEqual([b["type"] for b in request.body["messages"][1]["content"]],
                         ["text", "tool_use", "text"])
        self.assertEqual(request.body["messages"][2]["content"],
                         [{"type": "tool_result", "tool_use_id": "call_1",
                           "content": "result"}])
        self.assertNotIn("_anthropic_content", request.body["messages"][1])
        self.assertEqual(assistant["content"], "firstlast")
        equivalent = deepcopy(messages)
        equivalent[1]["tool_calls"][0]["function"]["arguments"] = (
            '{ "path" : "\\u76ee\\u5f55/a.txt" }')
        self.assertEqual(build_request(CLAUDE_MODEL, equivalent, [TOOL]).body,
                         request.body)
        request.body["messages"][1]["content"][0]["text"] = "mutated"
        self.assertEqual(assistant["_anthropic_content"], response["content"])

    def test_claude_metadata_consistency_and_provider_scope(self):
        original = normalize_response(CLAUDE_MODEL, claude()).assistant
        mutations = [
            lambda a: a.update(content="changed"),
            lambda a: a["tool_calls"][0].update(id="changed"),
            lambda a: a["tool_calls"][0]["function"].update(name="changed"),
            lambda a: a["tool_calls"][0]["function"].update(arguments='{"path":"other"}'),
            lambda a: a.update(tool_calls=[]),
            lambda a: a["_anthropic_content"].append({"type": "thinking", "text": "x"}),
            lambda a: a.update(_anthropic_content=[]),
        ]
        for mutate in mutations:
            assistant = deepcopy(original)
            mutate(assistant)
            with self.assertRaises(AdapterError):
                build_request(CLAUDE_MODEL, [
                    {"role": "user", "content": "start"}, assistant,
                    {"role": "tool", "tool_call_id": "call_1", "content": "result"}],
                    [TOOL])
        for model in (OPENAI_MODEL, KIMI_MODEL):
            with self.assertRaises(AdapterError):
                build_request(model, [original], [TOOL])
        for role in ("system", "user", "tool"):
            message = {"role": role, "content": "x", "_anthropic_content": [
                {"type": "text", "text": "x"}]}
            with self.assertRaises(AdapterError):
                build_request(CLAUDE_MODEL, [message], [TOOL])

    def test_text_only_and_optional_usage_not_fabricated(self):
        a = claude()
        a.update(content=[{"type": "text", "text": "done"}], stop_reason="end_turn")
        a["usage"] = {"input_tokens": 10, "output_tokens": 5}
        b = chat()
        b["choices"] = [{"finish_reason": "stop",
                         "message": {"role": "assistant", "content": "done"}}]
        b["usage"] = {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}
        for model, response in ((CLAUDE_MODEL, a), (KIMI_MODEL, b)):
            result = normalize_response(model, response)
            self.assertEqual(result.usage["total_tokens"], 15)
            self.assertIsNone(result.usage["cached_tokens"])
            self.assertEqual(result.assistant["content"], "done")

    def test_missing_invalid_usage(self):
        for model, factory, fields in (
            (CLAUDE_MODEL, claude, ["input_tokens", "output_tokens",
                                  "cache_read_input_tokens", "cache_creation_input_tokens"]),
            (KIMI_MODEL, chat, ["prompt_tokens", "completion_tokens", "total_tokens"])):
            response = factory()
            del response["usage"]
            with self.assertRaises(AdapterError):
                normalize_response(model, response)
            for field in fields:
                for invalid in (None, True, -1, 1.5, "2"):
                    with self.subTest(model=model, field=field, invalid=invalid):
                        response = factory()
                        response["usage"][field] = invalid
                        with self.assertRaises(AdapterError):
                            normalize_response(model, response)
            core = fields[:2] if model == CLAUDE_MODEL else fields
            for field in core:
                response = factory()
                del response["usage"][field]
                with self.assertRaises(AdapterError):
                    normalize_response(model, response)
        response = chat()
        response["usage"]["total_tokens"] = 99
        with self.assertRaises(AdapterError):
            normalize_response(KIMI_MODEL, response)

    def test_usage_detail_validation(self):
        for key, field in (("prompt_tokens_details", "cached_tokens"),
                           ("completion_tokens_details", "reasoning_tokens")):
            for invalid in (True, -1, "2", 99):
                response = chat()
                response["usage"][key][field] = invalid
                with self.assertRaises(AdapterError):
                    normalize_response(KIMI_MODEL, response)
        response = chat()
        del response["usage"]["prompt_tokens_details"]
        response["usage"]["cached_tokens"] = 4
        self.assertEqual(normalize_response(KIMI_MODEL, response).usage["cached_tokens"], 4)
        response["usage"]["prompt_tokens_details"] = {"cached_tokens": 7}
        with self.assertRaises(AdapterError):
            normalize_response(KIMI_MODEL, response)
        response = claude()
        response["usage"]["cache_creation"] = {"ephemeral_5m_input_tokens": True}
        with self.assertRaises(AdapterError):
            normalize_response(CLAUDE_MODEL, response)

    def test_exact_identity_and_api_errors(self):
        for model, factory in ((CLAUDE_MODEL, claude), (KIMI_MODEL, chat)):
            for drift in (None, "", model + "-latest"):
                response = factory()
                response["model"] = drift
                with self.assertRaises(AdapterError):
                    normalize_response(model, response)
            with self.assertRaises(AdapterError):
                normalize_response(model, {"error": {"message": "failed"}})
        with self.assertRaises(AdapterError):
            build_request("kimi-latest", [{"role": "user", "content": "x"}], [])

    def test_multiple_calls_never_silently_dropped(self):
        a = claude()
        a["content"].append({"type": "tool_use", "id": "call_2",
                             "name": "read_file", "input": {}})
        b = chat()
        extra = deepcopy(CALL)
        extra["id"] = "call_2"
        b["choices"][0]["message"]["tool_calls"].append(extra)
        for model, response in ((CLAUDE_MODEL, a), (KIMI_MODEL, b)):
            with self.assertRaisesRegex(AdapterError, "Multiple tool calls"):
                normalize_response(model, response)

    def test_refusal_truncation_and_unsupported_blocks(self):
        for stop in ("max_tokens", "refusal", "pause_turn", "stop_sequence", None):
            response = claude()
            response["stop_reason"] = stop
            with self.assertRaises(AdapterError):
                normalize_response(CLAUDE_MODEL, response)
        for kind in ("thinking", "redacted_thinking", "refusal", "image", "server_tool_use"):
            response = claude()
            response["content"].append({"type": kind, "text": "do not lose"})
            with self.assertRaises(AdapterError):
                normalize_response(CLAUDE_MODEL, response)
        for stop in ("length", "content_filter", None):
            response = chat()
            response["choices"][0]["finish_reason"] = stop
            with self.assertRaises(AdapterError):
                normalize_response(KIMI_MODEL, response)
        for field in ("refusal", "reasoning_content", "audio"):
            response = chat()
            response["choices"][0]["message"][field] = "unexpected"
            with self.assertRaises(AdapterError):
                normalize_response(KIMI_MODEL, response)

    def test_invalid_tool_payload_and_conversation(self):
        for arguments in ("not json", "[]", "null"):
            response = chat()
            response["choices"][0]["message"]["tool_calls"][0]["function"]["arguments"] = arguments
            with self.assertRaises(AdapterError):
                normalize_response(KIMI_MODEL, response)
        for messages in (
            [{"role": "user", "content": "hello"}, {"role": "system", "content": "late"}],
            [{"role": "tool", "tool_call_id": "orphan", "content": "x"}],
            [{"role": "user", "content": "x"},
             {"role": "assistant", "content": None, "tool_calls": [CALL]}],
            [{"role": "user", "content": [{"type": "image"}]}],
        ):
            with self.assertRaises(AdapterError):
                build_request(CLAUDE_MODEL, messages, [TOOL])


if __name__ == "__main__":
    unittest.main()
