As of 2026-11-05: Prepare the RisingWave schema migration record. Save /workspace/deliverable.json with migration_id, downtime_minutes, test_signoff, authorization_ref. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/m-high-db-migration.
OwnCloud: [REDACTED_RUNTIME_ENDPOINT]
RocketChat: [REDACTED_RUNTIME_ENDPOINT]
