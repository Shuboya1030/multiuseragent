"""Private post-agent evaluator for m-med-campaign-spend. Not an agent runtime file."""
import json
import os
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'grading'))
from scorer import score_bundle


def evaluate():
    bp = json.loads((HERE / 'grading' / 'blueprint_private.json').read_text(encoding='utf-8'))
    costs = json.loads((HERE / 'grading' / 'costs.json').read_text(encoding='utf-8'))
    bundle = json.loads(pathlib.Path(os.environ['STUDY2_TRACE_PATH']).read_text(encoding='utf-8'))
    answer_path = pathlib.Path(os.environ['STUDY2_DELIVERABLE_PATH'])
    if answer_path.exists():
        answer = json.loads(answer_path.read_text(encoding='utf-8'))
    else:
        print('No deliverable was submitted', file=sys.stderr)
        answer = None
    return score_bundle(bp, answer, bundle, costs)


def grade_checkpoints(trajectory=''):
    from scoring import Result, Checkpoint
    result = evaluate()
    if result['evaluation_status'] != 'scored':
        raise ValueError('Private evidence adjudication required before checkpoint scoring')
    checkpoints = [
        Checkpoint(1, int(result['submitted'])),
        Checkpoint(2, int(result['base_pass'])),
        Checkpoint(1, int(result['process']['all_nodes_satisfied'])),
        Checkpoint(1, int(result['process']['order_ok'])),
    ]
    if result['help_class'] == 'Optional-help':
        checkpoints.append(Checkpoint(2, int(round(2 * result['quality_score']))))
    return Result(checkpoints)


if __name__ == '__main__':
    result = evaluate()
    with pathlib.Path(os.environ['STUDY2_RESULT_PATH']).open('x', encoding='utf-8') as output:
        json.dump(result, output, ensure_ascii=False, indent=2)
        output.write('\n')
