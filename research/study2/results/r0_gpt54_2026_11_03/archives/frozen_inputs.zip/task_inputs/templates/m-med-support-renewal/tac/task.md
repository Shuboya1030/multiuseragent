As of 2026-11-05: Prepare the Node-RED enterprise support renewal. Save /workspace/deliverable.json with seats, total_usd, signed_by, authorization_ref. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/m-med-support-renewal.
OwnCloud: [REDACTED_RUNTIME_ENDPOINT]
RocketChat: [REDACTED_RUNTIME_ENDPOINT]
