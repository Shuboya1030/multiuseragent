As of 2026-11-05: Prepare the travel request for the AI team attending NeurIPS. Save /workspace/deliverable.json with travelers, total_usd, budget_code, signed_by, authorization_ref. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/m-med-conference-travel.
OwnCloud: [REDACTED_RUNTIME_ENDPOINT]
RocketChat: [REDACTED_RUNTIME_ENDPOINT]
