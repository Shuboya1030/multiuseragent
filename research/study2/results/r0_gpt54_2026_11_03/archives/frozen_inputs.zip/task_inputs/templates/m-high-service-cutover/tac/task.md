Prepare the Atlas cutover record for 2026-11-06. Save /workspace/deliverable.json with allocation_revision, replica_count, window_utc, readiness_reference, mandate_reference and rollback_minutes. Post a short handover summary and its path in #engineering.

Work packet: OwnCloud Documents/Study21V2/m-high-service-cutover.
OwnCloud: [REDACTED_RUNTIME_ENDPOINT]
RocketChat: [REDACTED_RUNTIME_ENDPOINT]
