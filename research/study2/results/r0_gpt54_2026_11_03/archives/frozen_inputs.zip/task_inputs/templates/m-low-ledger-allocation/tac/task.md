Prepare the November allocation entry for invoice INV-841. Save /workspace/deliverable.json with invoice_id, amount_usd, cost_center and ledger_period. Post a short entry summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/m-low-ledger-allocation.
OwnCloud: [REDACTED_RUNTIME_ENDPOINT]
RocketChat: [REDACTED_RUNTIME_ENDPOINT]
