As of 2026-11-05: Prepare the customer release-note header for the November OpenSearch release. Save /workspace/deliverable.json with product, version, release_date, known_issue_id. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/m-low-release-note-header.
OwnCloud: [REDACTED_RUNTIME_ENDPOINT]
RocketChat: [REDACTED_RUNTIME_ENDPOINT]
