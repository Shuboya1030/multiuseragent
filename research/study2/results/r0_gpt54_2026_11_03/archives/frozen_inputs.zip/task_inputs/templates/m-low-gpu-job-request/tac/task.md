As of 2026-11-05: Prepare the GPU job request for experiment E-55. Save /workspace/deliverable.json with experiment, gpu_hours, queue, quota_ref. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/m-low-gpu-job-request.
OwnCloud: [REDACTED_RUNTIME_ENDPOINT]
RocketChat: [REDACTED_RUNTIME_ENDPOINT]
