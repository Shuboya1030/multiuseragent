As of 2026-11-05: Plan the benchmark evaluation of Aurora-7B. Save /workspace/deliverable.json with benchmarks_to_run, gpu_hours, cost_usd. Post a short summary and the file path in #engineering.

Work packet: OwnCloud Documents/Study21V2/o-high-eval-budget.
OwnCloud: [REDACTED_RUNTIME_ENDPOINT]
RocketChat: [REDACTED_RUNTIME_ENDPOINT]
